"""Development launcher for SPIDY.

    python run.py                 # http://127.0.0.1:5000
    python run.py --port 8891
    python run.py --workspace /path/to/project

Environment:
    SPIDY_MODE=local|server   server adds bearer-token auth (see SPIDY_TOKENS)
    SPIDY_SANDBOX=local|container
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))


def main() -> None:
    ap = argparse.ArgumentParser(description="Run SPIDY Supreme AI")
    ap.add_argument("--host", default=os.environ.get("SPIDY_HOST", "127.0.0.1"))
    ap.add_argument("--port", type=int, default=int(os.environ.get("SPIDY_PORT", "5000")))
    ap.add_argument("--workspace", default="", help="workspace root SPIDY may touch")
    ap.add_argument("--reload", action="store_true")
    args = ap.parse_args()

    import uvicorn

    if args.workspace:
        os.environ["SPIDY_WORKSPACE"] = args.workspace

    print(f"  SPIDY Supreme AI  ->  http://{args.host}:{args.port}")
    print(f"  mode={os.environ.get('SPIDY_MODE', 'local')} "
          f"sandbox={os.environ.get('SPIDY_SANDBOX', 'local')}")
    print("  Ctrl-C to stop\n")

    uvicorn.run("spidy.api.server:app", host=args.host, port=args.port,
                log_level="warning", reload=args.reload)


if __name__ == "__main__":
    main()
