# SPIDY Supreme AI

**An offline-first, tool-using agentic AI operating environment.**
Not a chatbot — a reasoning, planning, and execution system that runs on your machine, costs nothing, and works with the network unplugged.

```
python run.py          # → http://127.0.0.1:5000
```

---

## What makes it different

| | |
|---|---|
| **Zero-model floor** | Works with no model running. A deterministic native brain plans, executes, and verifies. You lose prose generation, not function. |
| **Truly offline** | The UI is 3 hand-written files. No npm, no CDN, no webfont, no telemetry. `grep` the source — there are no external references. |
| **$0 to run** | Local inference is optional and free. No API key required for anything. |
| **Honest** | Degraded state is labelled, not hidden. If no model was reachable, it says so instead of pretending to have analysed something. |
| **11 specialists** | Research, engineering, frontend, backend, data, security, DevOps, testing, UI/UX, docs, creative — as declarative entries, run in parallel. |

---

## Quick start

### Requirements
- Python 3.11+
- Nothing else. No Docker, no Node, no model server.

### Install

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### Run

```bash
python run.py                       # default: 127.0.0.1:5000
python run.py --workspace /path/to/your/project
python run.py --port 8080 --host 0.0.0.0
```

Open the URL. You should see the chat screen with an **Offline mode** badge — that's correct with no model installed.

### Optional: add a model

SPIDY routes to the first reachable provider and falls back cleanly.

```bash
# Ollama (free, local, best fit)
ollama serve
ollama pull qwen2.5-coder:7b        # or llama3.1:8b, gemma3:4b

# or llama.cpp's server
./llama-server -m model.gguf --port 8080
```

The badge disappears when a model is reachable. Nothing else changes.

### Bring a cloud key (optional)

Fourteen providers are supported. Set a key and it joins the rotation
automatically — no restart, no config file:

```bash
export OPENAI_API_KEY=sk-...        # gpt-4o, gpt-4o-mini, gpt-4.1, o3-mini
export ANTHROPIC_API_KEY=sk-ant-...  # claude-opus-4-5, claude-sonnet-4-5
export GOOGLE_API_KEY=...           # gemini-2.5-pro, gemini-2.5-flash (AI Studio)
export OPENROUTER_API_KEY=...       # every model, one key
export GROQ_API_KEY=...             # very low latency
```

…or paste them into the **Models** screen in the UI.

| Provider | Env var | Default model |
|---|---|---|
| Ollama / llama.cpp | — | local, free |
| OpenRouter | `OPENROUTER_API_KEY` | `anthropic/claude-sonnet-4.5` |
| OpenAI | `OPENAI_API_KEY` | `gpt-4o` |
| Anthropic | `ANTHROPIC_API_KEY` | `claude-sonnet-4-5` |
| Google AI Studio | `GOOGLE_API_KEY` / `GEMINI_API_KEY` | `gemini-2.5-flash` |
| Groq | `GROQ_API_KEY` | `llama-3.3-70b-versatile` |
| Cerebras | `CEREBRAS_API_KEY` | `llama-3.3-70b` |
| DeepSeek | `DEEPSEEK_API_KEY` | `deepseek-chat` |
| xAI (Grok) | `XAI_API_KEY` | `grok-4` |
| Together AI | `TOGETHER_API_KEY` | `Llama-3.3-70B-Instruct-Turbo` |
| Mistral | `MISTRAL_API_KEY` | `mistral-large-latest` |
| Fireworks AI | `FIREWORKS_API_KEY` | `deepseek-v3` |
| Native engine | — | always available, no model needed |

**Go fully offline:** `export SPIDY_OFFLINE_ONLY=true` forbids every cloud
provider, whatever keys are present.

**Pin a model per provider**
```bash
SPIDY_PROVIDER_MODELS="groq=llama-3.3-70b-versatile,openai=gpt-4o-mini"
```

**Pin per role** — why reasoning goes to Opus and coding goes to a local coder:
```bash
SPIDY_MODEL_REASONING="anthropic:claude-opus-4-5"
SPIDY_MODEL_CODING="ollama:qwen2.5-coder:7b"
```
Pins are provider-scoped. `anthropic:claude-opus-4-5` is never sent to Groq,
and a bare `gemma3:4b` only ever reaches Ollama.

**Any OpenAI-shaped gateway works** — LiteLLM, vLLM, a proxy:
```bash
OPENAI_API_KEY=sk-local OPENAI_BASE_URL=http://127.0.0.1:4000/v1
```


---

## The 7-phase loop

Every request runs the same cycle. This is the LangGraph-compatible shape:

```
UNDERSTAND → CONTEXT → PLAN → APPROVAL → ACT → OBSERVE → REPAIR ⇄ → VERIFY → FINALIZE
```

- **UNDERSTAND** — intent classification, complexity, mutability (deterministic)
- **CONTEXT** — RAG retrieval + episodic/semantic memory
- **PLAN** — smallest useful plan, reversible steps, explicit validation
- **APPROVAL** — gate fires on high/critical risk
- **ACT** — tool execution through the registry
- **OBSERVE** — results recorded as observations, deduplicated
- **REPAIR** — failures are diagnosed and retried, up to `SPIDY_MAX_REPAIR`
- **VERIFY** — checks the result against the plan's success criteria

You can watch all of it live on the **Timeline** screen.

---

## The 11 specialists

Each is a plain dataclass — prompt, tool allowlist, success criteria, risk ceiling, handoffs. Adding a twelfth is appending one entry.

| Slug | Role | Risk ceiling |
|---|---|---|
| `research` | Multi-source investigation, citation, cross-checking | MEDIUM |
| `software_engineering` | Reads, changes, verifies code | MEDIUM |
| `frontend` | UI implementation, components, client state | MEDIUM |
| `backend` | Services, APIs, data models | MEDIUM |
| `data` | Profiling, queries, honest visualization | MEDIUM |
| `security` | Threat modelling, code audit | **LOW** (audit only) |
| `devops` | Build, CI, containers, deployment | MEDIUM |
| `testing` | Reproduce, isolate, regression-test | MEDIUM |
| `uiux` | Structure, hierarchy, interaction | LOW |
| `documentation` | Docs grounded in the code | LOW |
| `creative` | Images and original artifacts | LOW |

Selection is deterministic — keyword scoring plus tool-coverage weighting, no model call:

```python
from spidy.agents.specialists import select_specialists
select_specialists("check this endpoint for SQL injection", limit=2)
# → [Cybersecurity, Backend Development]
```

Run several in parallel:

```python
result = await app.team.run("audit auth for injection risks and fix them")
print(result.ok_steps, result.failed_steps)
print(result.answer)
```

---

## Tools

50 tools, grouped by tag:

| Tag | Tools |
|---|---|
| `fs` (15) | `read_file` `read_many_files` `list_files` `find_files` `search_in_files` `write_file` `edit_file` `apply_patch` `move_file` `copy_file` `delete_file` `file_diff` `file_stats` `file_history` `workspace_summary` |
| `web` (7) | `search_web` `fetch_url` `open_url` `http_request` `browser_navigate` `browser_screenshot` |
| `git` (5) | `git_status` `git_diff` `git_log` `git_add` `git_commit` |
| `shell` (4) | `run_command` `start_process` `read_process_output` `stop_process` |
| `code` (5) | `run_python` `run_node` `run_tests` `run_lint` `run_build` |
| `data` (4) | `inspect_data` `query_data` `generate_chart` `train_model` |
| `image` (2) | `generate_image` `analyze_image` |
| `rag` (3) | `rag_search` `index_workspace` `deep_research` |
| `memory` (2) | `remember` `recall` |

### Honest provider status

The Models screen distinguishes three states that are easy to conflate:

| State | Meaning |
|---|---|
| **reachable** | The endpoint answered. Models listed are callable. |
| **auth rejected (401)** | Key is present but wrong. **No models listed** — nothing there would work. |
| **no key** | Catalog shown as an advertisement of what a key would unlock. |
| **not running** | Local server absent. |

A provider is never shown as usable when it isn't. A 401 is not an HTTP
exception, so a naive health check would call a dead key "reachable" and offer
a model list where every choice fails — that path is explicitly tested
(`test_bad_key_is_reported_as_auth_failure_not_reachable`).

Browse them all with schemas on the **Tools** screen.

---

## Architecture

```
spidy/
├── api/            HTTP surface — thin adapter over the kernel
│   ├── server.py     FastAPI factory, lifespan, static mount
│   ├── routes.py     REST + SSE
│   ├── tenancy.py    the ONLY place mode branches
│   └── schemas.py    wire DTOs, decoupled from core types
├── agents/
│   ├── runtime.py    the 7-phase loop
│   ├── specialists.py  11 declarative agent definitions
│   └── team.py       parallel DAG orchestration
├── brain/
│   ├── native.py     deterministic brain — the zero-model floor
│   ├── router.py     per-role model selection, health, degradation
│   └── providers.py  Ollama / llama.cpp / OpenAI-compatible
├── tools/           50 tools behind one registry
├── rag/             chunking, embeddings, hybrid retriever
├── cag/             semantic cache with polarity guard
├── research/        decomposition → search → cross-check → synthesis
├── security/        guard, SSRF, policy, redaction
├── core/            config, schemas, events, store, token budget
├── sandbox.py       LocalSandbox / ContainerSandbox seam
└── ui/              3 files, no build step
```

The API never imports from `tools/` or `brain/`. It talks to the `Spidy` container, so the transport is replaceable — a CLI or bot reuses the same logic.

---

## Security

| Layer | What it does |
|---|---|
| **Prompt guard** | Scores untrusted text for injection intent; fences it as non-overridable context |
| **SSRF policy** | Resolves DNS *before* deciding, closing the rebinding hole. Blocks private ranges, link-local, localhost |
| **Command policy** | Every command is classified; hard blocks, confirm tiers, risk ceilings per agent |
| **Filesystem policy** | Everything confined to the workspace root, with symlink resolution |
| **Redaction** | API keys, tokens, JWTs, private keys scrubbed from output *and* from the child env |
| **Sandbox** | `LocalSandbox` applies rlimits, scrubs env, confines cwd, kills the process group on timeout |
| **Audit** | Every tool call, decision, and denial is logged |

### About the sandbox — read this

`LocalSandbox` is **advisory, not a security boundary.** It shares a kernel, filesystem, and process table with SPIDY. It stops runaway commands and accidents. It does not stop a determined attacker.

- **Local mode** (default): appropriate. One trusted user, one machine.
- **Server mode**: shell tools **fail closed** until a container sandbox is configured. This is enforced in `spidy/api/tenancy.py` and tested.

Multi-tenant deployment requires `ContainerSandbox` (spec 4). The interface is already fixed, so enabling it is a config change, not a refactor.

---

## Deployment

### Single user (default)

```bash
python run.py
```

### Multi-user / server

```bash
export SPIDY_MODE=server
export SPIDY_TOKENS="tok_alice:alice,tok_bob:bob"
export SPIDY_SANDBOX=container          # required for shell tools
export SPIDY_RATE_LIMIT=60
uvicorn spidy.api.server:app --host 0.0.0.0 --port 8000 --workers 1
```

**Use `--workers 1`.** SSE state lives in process memory; multiple workers would send a client's events to whichever worker isn't holding that connection. Horizontal scaling needs a Redis pub/sub fanout first.

Put it behind TLS and terminate auth at the proxy too — `SPIDY_TOKENS` is a shared-secret scheme, not an identity provider.

### Docker

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY spidy/ spidy/
COPY run.py .
ENV SPIDY_HOME=/data SPIDY_WORKSPACE=/workspace
EXPOSE 5000
CMD ["python", "run.py", "--host", "0.0.0.0"]
```

---

## Configuration

Everything is env-driven. The important ones:

| Variable | Default | Meaning |
|---|---|---|
| `SPIDY_HOME` | `~/.spidy` | Database and state |
| `SPIDY_WORKSPACE` | cwd | Root SPIDY may read and write |
| `SPIDY_MODE` | `local` | `local` or `server` |
| `SPIDY_TOKENS` | — | `token:tenant,...` (server mode) |
| `SPIDY_SANDBOX` | `local` | `local` or `container` |
| `SPIDY_PERMISSION` | `BALANCED` | `SAFE` `BALANCED` `FULL` |
| `SPIDY_OFFLINE_ONLY` | `false` | Never contact a remote provider |
| `SPIDY_TASK_TOKEN_BUDGET` | `240000` | Per-task ceiling |
| `SPIDY_MAX_REPAIR` | `3` | Repair rounds per failed step |
| `SPIDY_ALLOW_CLOUD` | `true` | `false` forbids every cloud provider |
| `SPIDY_PROVIDER_MODELS` | — | `openai=gpt-4o,groq=llama-3.3-70b` |
| `SPIDY_MODEL_REASONING` | `ollama:gemma3:4b` | provider-scoped role pin |
| `SPIDY_MODEL_CODING` | `ollama:gemma3:4b` | provider-scoped role pin |
| `OLLAMA_ENDPOINT` | `127.0.0.1:11434` | Ollama |
| `LLAMACPP_BASE_URL` | `127.0.0.1:8080` | llama.cpp server |
| `*_API_KEY` | — | One per cloud provider (see table above) |
| `*_BASE_URL` | catalog default | Override for any OpenAI-shaped gateway |

---

## API

Full contract in [`docs/superpowers/specs/`](docs/superpowers/specs/).

| Method | Path | |
|---|---|---|
| GET | `/api/health` | truthful provider probe + offline flag |
| GET | `/api/tools` | registry with schemas |
| GET | `/api/models` | 14 providers with live reachability + honest errors |
| GET | `/api/providers` | the static catalog, no connectivity needed |
| POST | `/api/chat` | start a task → `{task_id}` |
| GET | `/api/tasks/{id}` | full state incl. observations |
| GET | `/api/events/stream` | **SSE** — live agent activity |
| GET | `/api/specialists` | the 11-agent roster |
| POST | `/api/team/run` | parallel multi-agent run |
| GET/PUT | `/api/files`, `/api/files/content` | browse and edit |
| GET | `/api/projects` | indexed workspaces |
| GET/PATCH | `/api/settings` | secrets redacted |
| GET | `/api/audit` | decision log |

Errors are `{"error": {"code", "message", "detail"}}` with real status codes. A failing *task* is never an HTTP 500.

---

## Tests

```bash
pytest tests/ -q          # 119 tests
```

Covers the registry, native brain, event bus, RAG, CAG, security policy, sandbox, every route, tenancy/auth/fail-closed, SSE ordering and replay, the UI's offline guarantee, and the specialist system.

The most valuable ones:

- `test_every_allowed_tool_exists_in_the_real_registry` — catches a typo'd tool name, which is otherwise a silent production failure
- `test_health_reports_truthfully_with_no_models` — catches a provider claiming reachable when nothing is listening
- `test_event_bus_delivers_each_subscriber_exactly_once` — catches double-dispatch
- `test_ui_has_no_external_references` — enforces the offline promise
- `test_bad_key_is_reported_as_auth_failure_not_reachable` — catches the
  false-green health check that would offer uncallable models
- `test_no_provider_key_ever_leaks_from_settings` — all 11 key fields, redacted

---

## Screens

`#chat` `#timeline` `#tools` `#files` `#models` `#projects` `#settings`

The **Models** screen manages every provider: paste a key, pick a model, see
live reachability. Keys are write-only — the API never returns them.
The **Files** screen is a real editor with save. The **Timeline** shows the 7-phase DAG live, including repair loops. **Settings** is read-only in this version; the PATCH route exists and is tested.

---

## Design notes

**Why no React?** The transcript is an append-only list and the timeline is a bounded array — both are under 100 lines of targeted DOM updates. A framework would have added a build step, a dependency that rots, and a CDN that breaks the offline promise. The one thing React would have bought is state management, and that's ~150 lines here.

**Why SQLite with WAL?** One connection shared by RAG vectors and the CAG cache, so the index and the cache are consistent inside a transaction. Checkpoint every 3 steps means a crash loses at most two steps of work.

**Why a deterministic brain?** Because "no model running" must not mean "no product." Planning, tool selection, argument inference, and verification are all rule-based and work fine. What genuinely needs a model is generating a code patch or drafting prose — and the system says exactly that instead of bluffing.

---

## Known limits

Stated plainly, because a system that hides these isn't trustworthy:

- **Local sandbox is advisory** — fine single-user, not a multi-tenant boundary
- **SSE is single-process** — `--workers 1` until a Redis fanout lands
- **No token-level streaming from the native brain** — SSE streams *events*, not tokens. With a real model, provider tokens stream.
- **`generate_image` tier 3 is procedural** — with no model and no diffusers, it draws a deterministic PNG from the prompt rather than a real image
- **Settings UI is read-only** in this version
- **The 25 skills from the original zip are not yet mounted** — the tool surface supersedes most of them

## License

MIT
