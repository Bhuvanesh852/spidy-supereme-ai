"""SPIDY Supreme AI — offline-first, agentic, tool-using AI operating environment."""
__version__ = "1.0.0"
