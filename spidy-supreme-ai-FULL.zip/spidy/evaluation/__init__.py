"""Evaluation harness."""
