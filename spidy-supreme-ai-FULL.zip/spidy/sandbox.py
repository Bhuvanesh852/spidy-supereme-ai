"""Execution sandboxes.

The tool layer must not care *how* a command runs, only that it ran under a
declared limit set. This module is that seam.

    LocalSandbox     — rlimits + jail policy + cwd confinement. The default.
    ContainerSandbox — Docker, no network, read-only root. Not yet implemented.

Why this is an interface and not a flag: local limits are *advisory*. They stop
accidents, not a determined attacker, and in server mode a hostile tenant handed
`run_command` gets real Python and reads the other tenants' memories. Hardening
must therefore be a config change, never a refactor of the tool layer.

`SPIDY_SANDBOX=local|container` selects the implementation. In server mode the
API refuses shell tools unless a real sandbox is configured — see
`spidy.api.tenancy.assert_shell_allowed`.
"""
from __future__ import annotations

import asyncio
import os
import resource
import shutil
import signal
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol, runtime_checkable


@dataclass
class Limits:
    """Resource ceilings for one execution. Defaults are deliberately tight."""

    wall_timeout: int = 120
    memory_bytes: int = 2 * 1024 * 1024 * 1024      # 2 GB address space
    cpu_seconds: int = 120
    max_output_bytes: int = 200_000
    open_files: int = 256
    max_processes: int = 64
    env: dict[str, str] = field(default_factory=lambda: {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "HOME": "/tmp",
        "LANG": "C.UTF-8",
        "PYTHONUNBUFFERED": "1",
    })


@dataclass
class ExecResult:
    returncode: int
    stdout: str
    stderr: str
    duration_ms: int
    timed_out: bool = False
    sandbox: str = "local"
    workdir: str = ""

    @property
    def ok(self) -> bool:
        return self.returncode == 0 and not self.timed_out


@runtime_checkable
class Sandbox(Protocol):
    """What the tool layer depends on. Deliberately tiny.

    `cmd` accepts an argv list (preferred — no shell expansion) or a shell
    command string (the tool layer already speaks in command strings, and
    `CommandPolicy` has matched against that string, so re-parsing here would
    create a second, divergent view of what is about to run).
    """

    kind: str

    async def run(self, cmd: list[str] | str, cwd: Path,
                  limits: Limits | None = None,
                  env: dict[str, str] | None = None) -> ExecResult:
        ...


class LocalSandbox:
    """Best-effort isolation via POSIX rlimits and a scrubbed environment.

    Honest scope: this raises the cost of a runaway command. It does not stop a
    program that intends to escape, because it shares a kernel, a filesystem and
    a process table with SPIDY itself. Single-user local use: appropriate.
    Multi-tenant: not a security boundary — use ContainerSandbox.
    """

    kind = "local"

    def __init__(self, workspace_root: Path | None = None) -> None:
        self.workspace_root = Path(workspace_root or Path.cwd()).resolve()

    # -- confinement -------------------------------------------------- #
    def _confine(self, cwd: Path) -> Path:
        """Resolve cwd and refuse anything outside the workspace root."""
        target = (self.workspace_root / cwd).resolve() if not Path(cwd).is_absolute() \
            else Path(cwd).resolve()
        try:
            target.relative_to(self.workspace_root)
        except ValueError:
            raise PermissionError(
                f"sandbox: cwd {target} is outside the workspace root "
                f"{self.workspace_root}")
        return target

    @staticmethod
    def _preexec(limits: Limits):
        """Applied in the child between fork and exec."""
        def _apply() -> None:  # pragma: no cover - runs in the child process
            os.setsid()
            mem = limits.memory_bytes
            cpu = limits.cpu_seconds
            for res, val in (
                (resource.RLIMIT_AS, mem),
                (resource.RLIMIT_DATA, mem),
                (resource.RLIMIT_CPU, cpu),
                (resource.RLIMIT_FSIZE, limits.max_output_bytes),
                (resource.RLIMIT_NOFILE, limits.open_files),
                (resource.RLIMIT_NPROC, limits.max_processes),
            ):
                try:
                    resource.setrlimit(res, (val, val))
                except (ValueError, OSError):
                    # A limit the kernel refuses (e.g. NPROC as root) must not
                    # take down the command — fail open on the limit, not the run.
                    pass
            try:
                resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
            except (ValueError, OSError):
                pass
        return _apply

    async def run(self, cmd: list[str] | str, cwd: Path,
                  limits: Limits | None = None,
                  env: dict[str, str] | None = None) -> ExecResult:
        import time

        lim = limits or Limits()
        run_env = env if env is not None else lim.env
        work = self._confine(cwd)
        work.mkdir(parents=True, exist_ok=True)
        started = time.perf_counter()
        use_shell = isinstance(cmd, str)
        preexec = self._preexec(lim) if os.name == "posix" else None

        try:
            if use_shell:
                proc = await asyncio.create_subprocess_shell(
                    cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    stdin=asyncio.subprocess.DEVNULL,
                    cwd=str(work), env=run_env, preexec_fn=preexec,
                )
                argv0 = cmd[:80]
            else:
                proc = await asyncio.create_subprocess_exec(
                    *cmd,
                    cwd=str(work), env=run_env,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    stdin=asyncio.subprocess.DEVNULL,
                    preexec_fn=preexec,
                )
                argv0 = cmd[0] if cmd else ""
        except FileNotFoundError:
            return ExecResult(127, "", f"command not found: {argv0}",
                              0, sandbox=self.kind, workdir=str(work))
        except OSError as exc:
            return ExecResult(126, "", f"spawn failed: {exc}", 0,
                              sandbox=self.kind, workdir=str(work))

        try:
            out_b, err_b = await asyncio.wait_for(
                proc.communicate(), timeout=lim.wall_timeout)
            timed_out = False
        except asyncio.TimeoutError:
            timed_out = True
            with _suppress():
                # Kill the whole process group: the child called setsid(), so
                # killing only the direct child would orphan its descendants.
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            with _suppress():
                proc.kill()
            out_b, err_b = await proc.communicate()

        ms = int((time.perf_counter() - started) * 1000)
        out = _truncate(out_b or b"", lim.max_output_bytes)
        err = _truncate(err_b or b"", lim.max_output_bytes)
        return ExecResult(
            returncode=proc.returncode if proc.returncode is not None else -1,
            stdout=out, stderr=err, duration_ms=ms,
            timed_out=timed_out, sandbox=self.kind, workdir=str(work),
        )


class ContainerSandbox:
    """Docker-backed isolation. Reserved for spec 4.

    The contract is fixed now so the tool layer never has to change: same
    `run()` signature, same ExecResult. Only the guarantees differ.
    """

    kind = "container"

    def __init__(self, image: str = "python:3.11-slim",
                 network: str = "none", memory: str = "2g",
                 cpus: str = "2") -> None:
        self.image = image
        self.network = network
        self.memory = memory
        self.cpus = cpus

    def available(self) -> bool:
        return shutil.which("docker") is not None

    async def run(self, cmd: list[str], cwd: Path,
                  limits: Limits | None = None) -> ExecResult:
        raise NotImplementedError(
            "ContainerSandbox is not implemented yet (spec 4). Until then, use "
            "SPIDY_SANDBOX=local for single-user operation, or do not expose "
            "shell tools in server mode."
        )


# --------------------------------------------------------------------------- #
# selection
# --------------------------------------------------------------------------- #

_SANDBOXES: dict[str, type] = {
    "local": LocalSandbox,
    "container": ContainerSandbox,
}


def get_sandbox(workspace_root: Path | str | None = None) -> Sandbox:
    """Build the configured sandbox. Defaults to LocalSandbox."""
    kind = os.environ.get("SPIDY_SANDBOX", "local").strip().lower()
    cls = _SANDBOXES.get(kind)
    if cls is None:
        raise ValueError(
            f"unknown SPIDY_SANDBOX={kind!r}; expected one of "
            f"{sorted(_SANDBOXES)}")
    if cls is ContainerSandbox:
        return cls()  # type: ignore[return-value]
    return cls(Path(workspace_root) if workspace_root else None)  # type: ignore[return-value]


def sandbox_kind() -> str:
    """Configured sandbox name, without instantiating it."""
    kind = os.environ.get("SPIDY_SANDBOX", "local").strip().lower()
    return kind if kind in _SANDBOXES else "local"


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #


class _suppress:
    """Tiny contextlib.suppress stand-in that keeps imports lean."""

    def __enter__(self) -> None:
        return None

    def __exit__(self, exc_type, exc, tb) -> bool:
        return exc_type is not None and issubclass(exc_type, Exception)


def _truncate(blob: bytes, limit: int) -> str:
    text = blob.decode("utf-8", "replace")
    if len(text) > limit:
        return text[:limit] + f"\n... [{len(text) - limit} bytes elided by sandbox]"
    return text
