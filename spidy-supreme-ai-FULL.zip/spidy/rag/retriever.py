"""Hybrid retriever + reranker.

Retrieval is a weighted blend of four signals:

  semantic   dense cosine over the vector store
  lexical    BM25 over the same corpus
  structural exact token/identifier overlap
  metadata   source, recency, and heading match

Then a cross-feature reranker promotes chunks that match the query's *intent*
(not just its words) and demotes ones that merely look similar. Pure vector
search is the usual failure mode; the blend is what makes grounded answers
reliable.
"""
from __future__ import annotations

import math
import re
import sqlite3
import struct
import time
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Iterable

import numpy as np

from ..core.schemas import new_id
from ..core.token_budget import TokenBudget, estimate_tokens
from .embeddings import BaseEmbedder, get_embedder, split_identifiers

_STOP = {
    "the", "a", "an", "and", "or", "of", "to", "in", "is", "are", "for", "on", "with",
    "as", "by", "at", "from", "it", "this", "that", "be", "was", "were", "will",
    "what", "how", "do", "does", "did", "can", "should", "i", "you", "we", "me",
    "my", "your", "our", "about", "into", "than", "then", "there", "their",
}


def terms(text: str) -> list[str]:
    return [t for t in split_identifiers(text.lower()) if t not in _STOP and len(t) > 1]


# --------------------------------------------------------------------------- #


@dataclass
class ScoredChunk:
    chunk_id: str
    text: str
    score: float
    source: str = ""
    uri: str = ""
    doc_id: str = ""
    ord: int = 0
    meta: dict[str, Any] = field(default_factory=dict)
    signals: dict[str, float] = field(default_factory=dict)

    def citation(self) -> str:
        label = self.source or self.uri or self.doc_id
        loc = f"#{self.ord + 1}" if self.ord else ""
        return f"{label}{loc}"


class VectorStore:
    """Vectors in a float32 BLOB column. At SPIDY's scale (hundreds of thousands
    of chunks) an in-process numpy scan is faster than an index server and has
    zero operational cost."""

    def __init__(self, db: sqlite3.Connection) -> None:
        self.db = db

    @staticmethod
    def pack(vec: np.ndarray) -> bytes:
        return struct.pack(f"<{vec.shape[0]}f", *[float(x) for x in vec])

    @staticmethod
    def unpack(blob: bytes) -> np.ndarray:
        n = len(blob) // 4
        return np.frombuffer(blob, dtype=np.float32, count=n)

    def search(self, query_vec: np.ndarray, limit: int = 50,
               doc_ids: set[str] | None = None) -> list[tuple[str, float]]:
        rows = self.db.execute(
            "SELECT c.chunk_id, c.text, d.source, d.uri FROM chunks c "
            "JOIN docs d ON d.doc_id = c.doc_id"
        ).fetchall()
        if not rows:
            return []
        ids = [r[0] for r in rows]
        matrix = np.vstack([self.unpack(r[1]) for r in self._blobbed(rows)])
        sims = matrix @ query_vec
        order = np.argsort(-sims)[: limit * 4]
        out: list[tuple[str, float]] = []
        for i in order:
            cid = ids[int(i)]
            if doc_ids and self._doc_of(cid) not in doc_ids:
                continue
            out.append((cid, float(sims[int(i)])))
            if len(out) >= limit:
                break
        return out

    def _blobbed(self, rows) -> list[tuple]:
        blobs = self.db.execute(
            "SELECT chunk_id, vec FROM vectors WHERE chunk_id IS NOT NULL").fetchall()
        m = {b[0]: b[1] for b in blobs}
        return [(r[0], m.get(r[0], b"")) for r in rows]

    def _doc_of(self, chunk_id: str) -> str:
        r = self.db.execute("SELECT doc_id FROM chunks WHERE chunk_id=?", (chunk_id,)).fetchone()
        return r[0] if r else ""

    def upsert(self, chunk_id: str, vec: np.ndarray) -> None:
        self.db.execute(
            "INSERT OR REPLACE INTO vectors(chunk_id, vec) VALUES(?,?)",
            (chunk_id, self.pack(vec.astype(np.float32))))


class Retriever:
    def __init__(self, db, settings, embedder: BaseEmbedder | None = None) -> None:
        self.db = db
        self.settings = settings
        self.embedder = embedder or get_embedder(settings)
        self._bm25: Any = None
        self._bm25_key: tuple | None = None

    # ------------------------------------------------------------------ #
    def _ensure_vector_table(self) -> None:
        self.db.execute("CREATE TABLE IF NOT EXISTS vectors ("
                        "chunk_id TEXT PRIMARY KEY, vec BLOB NOT NULL)")
        self.db.commit()

    def search(
        self,
        query: str,
        top_k: int = 8,
        candidates: int = 40,
        project: str = "",
        source_filter: str = "",
        budget: TokenBudget | None = None,
    ) -> list[ScoredChunk]:
        self._ensure_vector_table()
        q = (query or "").strip()
        if not q:
            return []

        rows = self.db.execute(
            "SELECT c.chunk_id, c.text, c.ord, c.doc_id, c.meta, d.source, d.uri "
            "FROM chunks c JOIN docs d ON d.doc_id=c.doc_id"
        ).fetchall()
        if not rows:
            return []

        if project:
            rows = [r for r in rows if not r[6] or _meta(r[4]).get("project") in ("", project)]
        if source_filter:
            rows = [r for r in rows if source_filter.lower() in (r[5] or "").lower()]

        pool = rows[: max(candidates * 12, 400)]
        texts = {r[0]: r[1] for r in pool}
        metas = {r[0]: _meta(r[4]) for r in pool}

        # --- signal 1: dense semantic --------------------------------- #
        qvec = self.embedder.embed_one(q)
        blob_map = {b[0]: b[1] for b in self.db.execute(
            "SELECT chunk_id, vec FROM vectors").fetchall()}
        sem: dict[str, float] = {}
        for r in pool:
            blob = blob_map.get(r[0])
            if not blob:
                continue
            v = VectorStore.unpack(blob)
            if v.shape[0] == qvec.shape[0]:
                sem[r[0]] = self.embedder.cosine(qvec, v)

        # --- signal 2: BM25 lexical ----------------------------------- #
        lex = self._bm25_scores(q, texts)

        # --- signal 3: structural overlap ------------------------------ #
        qt = set(terms(q))
        struct: dict[str, float] = {}
        for cid, txt in texts.items():
            ct = set(terms(txt))
            if not ct:
                continue
            inter = len(qt & ct)
            struct[cid] = inter / math.sqrt(len(ct)) if inter else 0.0

        # --- signal 4: metadata / heading ----------------------------- #
        meta: dict[str, float] = {}
        for cid, m in metas.items():
            s = 0.0
            if q.lower() in (m.get("header", "") or "").lower():
                s += 0.5
            if m.get("project") and project and m["project"] == project:
                s += 0.1
            if m.get("kind") in ("code", "definition"):
                s += 0.05
            meta[cid] = s

        # --- blend ------------------------------------------------------ #
        w_sem, w_lex, w_str, w_meta = 0.42, 0.32, 0.20, 0.06
        raw: dict[str, dict[str, float]] = {}
        for cid in texts:
            s1 = sem.get(cid, 0.0)
            s2 = lex.get(cid, 0.0)
            s3 = struct.get(cid, 0.0)
            s4 = meta.get(cid, 0.0)
            raw[cid] = {"semantic": s1, "lexical": s2, "structural": s3, "meta": s4}
            texts.setdefault(cid, "")

        combined = {
            cid: (w_sem * max(0.0, s["semantic"])
                  + w_lex * min(1.0, s["lexical"] / 8.0)
                  + w_str * min(1.0, s["structural"] * 2.2)
                  + w_meta * s["meta"])
            for cid, s in raw.items()
        }
        top = sorted(combined.items(), key=lambda kv: kv[1], reverse=True)[: max(top_k * 4, 32)]
        reranked = self.rerank(q, top, texts, metas)

        out: list[ScoredChunk] = []
        used = 0
        cap = budget.remaining_for("rag") if budget else 10**9
        for cid, base in reranked:
            r = next(x for x in rows if x[0] == cid)
            t = estimate_tokens(r[1])
            if budget and used + t > cap:
                break
            used += t
            out.append(ScoredChunk(
                chunk_id=cid, text=r[1], score=round(base, 4), source=r[5] or "",
                uri=r[6] or "", doc_id=r[3], ord=r[2], meta=metas.get(cid, {}),
                signals={k: round(v, 4) for k, v in raw.get(cid, {}).items()},
            ))
        return out[:top_k]

    # ------------------------------------------------------------------ #
    def _bm25_scores(self, query: str, texts: dict[str, str]) -> dict[str, float]:
        qt = terms(query)
        if not qt:
            return {}
        docs = {k: Counter(terms(v)) for k, v in texts.items()}
        n = len(docs) or 1
        avgdl = (sum(sum(c.values()) for c in docs.values()) / n) or 1.0
        df: Counter = Counter()
        for c in docs.values():
            df.update(c.keys())
        k1, b = 1.5, 0.75
        out: dict[str, float] = {}
        for cid, tf in docs.items():
            dl = sum(tf.values()) or 1
            s = 0.0
            for t in qt:
                if t not in tf:
                    continue
                idf = math.log(1 + (n - df[t] + 0.5) / (df[t] + 0.5))
                s += idf * (tf[t] * (k1 + 1)) / (tf[t] + k1 * (1 - b + b * dl / avgdl))
            out[cid] = s
        return out

    def rerank(self, query: str, ranked: list[tuple[str, float]],
               texts: dict[str, str], metas: dict[str, dict]) -> list[tuple[str, float]]:
        """Second pass. Rewards intent match, penalizes boilerplate, and gives a
        small boost to chunks that answer rather than merely mention."""
        qt = set(terms(query))
        q_low = query.lower()
        question = q_low.startswith(("what", "how", "why", "when", "who", "where")) \
            or "?" in q_low
        out: list[tuple[str, float]] = []
        for cid, base in ranked:
            txt = texts.get(cid, "")
            tl = txt.lower()
            bonus = 0.0

            # Direct phrase hit is a strong signal.
            if len(q_low) > 6 and q_low in tl:
                bonus += 0.28
            # Definition-bearing chunks answer questions better than prose that
            # happens to contain the words.
            if question and re.search(
                    r"(?:^\s*(?:def|class|#+\s|\w+\s*(?:is|are|means|refers to))|"
                    r"\bis\s+a\b|\bare\s+a\b|\bmeans\b|\brefers\s+to\b)", txt, re.M):
                bonus += 0.16
            if metas.get(cid, {}).get("kind") in ("code", "definition") and question:
                bonus += 0.10
            # Numeric/structured content is usually the actual answer.
            if question and re.search(r"\d+(?:\.\d+)?\s*(?:%|ms|s|kb|mb|gb|usd|\$)", tl):
                bonus += 0.08
            # Boilerplate: very long chunks with low term density are mostly noise.
            ct = set(terms(txt))
            if len(txt) > 3000 and len(qt & ct) / max(1, len(ct)) < 0.02:
                bonus -= 0.18
            # Chunks that are mostly punctuation/imports answer nothing.
            if re.search(r"^\s*(?:import |from \w+ import|<\?php|package \w+;)", txt, re.M) \
                    and question:
                bonus -= 0.12

            out.append((cid, base + bonus))
        out.sort(key=lambda kv: kv[1], reverse=True)
        return out

    # ------------------------------------------------------------------ #
    def index_document(self, text: str, source: str, uri: str = "",
                       project: str = "", meta: dict[str, Any] | None = None,
                       chunk_size: int = 900, overlap: int = 140) -> dict[str, Any]:
        """Chunk, embed, and store. Re-indexing an unchanged source is a no-op."""
        import hashlib
        import json
        import sqlite3 as _s

        self._ensure_vector_table()
        sha = hashlib.sha256((text or "").encode("utf-8", errors="replace")).hexdigest()
        existing = self.db.execute(
            "SELECT doc_id, chunk_count FROM docs WHERE sha256=? AND source=?",
            (sha, source)).fetchone()
        if existing:
            return {"doc_id": existing[0], "chunks": existing[1], "skipped": True}

        doc_id = new_id("doc_")
        base_meta = {"project": project, **(meta or {})}
        try:
            _s.register_adapter("numpy.ndarray", lambda v: v.tobytes())
        except Exception:
            pass

        from .chunking import chunk_text
        chunks = chunk_text(text, chunk_size, overlap, doc_id, base_meta)
        if not chunks:
            return {"doc_id": "", "chunks": 0, "skipped": True}

        vecs = self.embedder.embed([c.text for c in chunks])
        for c, v in zip(chunks, vecs):
            self.db.execute(
                "INSERT OR REPLACE INTO chunks(chunk_id,doc_id,ord,text,tokens,meta)"
                " VALUES(?,?,?,?,?,?)",
                (c.id, doc_id, c.ord, c.text, c.tokens, json.dumps(c.meta, default=str)))
            self.db.execute(
                "INSERT OR REPLACE INTO vectors(chunk_id,vec) VALUES(?,?)",
                (c.id, VectorStore.pack(v.astype(np.float32))))
        self.db.execute(
            "INSERT OR REPLACE INTO docs(doc_id,source,uri,project,sha256,chunk_count,"
            "indexed_at,meta) VALUES(?,?,?,?,?,?,?,?)",
            (doc_id, source, uri, project, sha, len(chunks), time.time(),
             json.dumps(base_meta, default=str)))
        self.db.commit()
        self._bm25 = None
        self._bm25_key = None
        return {"doc_id": doc_id, "chunks": len(chunks), "skipped": False}

    def delete_document(self, doc_id: str) -> int:
        self._ensure_vector_table()
        ids = [r[0] for r in self.db.execute(
            "SELECT chunk_id FROM chunks WHERE doc_id=?", (doc_id,))]
        for cid in ids:
            self.db.execute("DELETE FROM vectors WHERE chunk_id=?", (cid,))
        self.db.execute("DELETE FROM chunks WHERE doc_id=?", (doc_id,))
        self.db.execute("DELETE FROM docs WHERE doc_id=?", (doc_id,))
        self.db.commit()
        return len(ids)

    def stats(self) -> dict[str, Any]:
        self._ensure_vector_table()
        docs = self.db.execute("SELECT COUNT(*) FROM docs").fetchone()[0]
        chunks = self.db.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
        vecs = self.db.execute("SELECT COUNT(*) FROM vectors").fetchone()[0]
        by_source = self.db.execute(
            "SELECT source, COUNT(*) c FROM docs GROUP BY source ORDER BY c DESC LIMIT 15"
        ).fetchall()
        return {
            "documents": docs, "chunks": chunks, "vectors": vecs,
            "embedder": self.embedder.name, "dim": self.embedder.dim,
            "by_source": [{"source": s, "documents": c} for s, c in by_source],
            "size_bytes": self.db.execute(
                "SELECT COALESCE(SUM(LENGTH(vec)),0) FROM vectors").fetchone()[0],
        }


def _meta(raw: Any) -> dict[str, Any]:
    import json
    if isinstance(raw, dict):
        return raw
    try:
        return json.loads(raw or "{}")
    except (json.JSONDecodeError, TypeError, ValueError):
        return {}


def format_context(hits: Iterable[ScoredChunk], max_tokens: int = 3000) -> str:
    """Render retrieved chunks as a citation-carrying context block."""
    parts: list[str] = []
    used = 0
    for h in hits:
        block = f"[{h.citation()}] {h.text}"
        t = estimate_tokens(block)
        if used + t > max_tokens:
            break
        used += t
        parts.append(block)
    return "\n\n".join(parts)
