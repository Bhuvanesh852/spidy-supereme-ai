"""Chunking.

Structure-aware when it can be (markdown headings, code definitions, classes),
semantic paragraph grouping otherwise. Every chunk keeps an overlap so a fact
sitting on a boundary is never cut away from its context.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from ..core.schemas import new_id
from ..core.token_budget import estimate_tokens

# Code constructs worth never splitting across.
_CODE_SPLIT_RE = re.compile(
    r"^(?:"
    r"(?:class|def|async def|function|const|let|var|type|interface|struct|enum|impl|trait)\s+"
    r"\w+"
    r"|\s*(?:@|#\[|//|/\*|#\s)"
    r")",
    re.M,
)
_MD_HEADING_RE = re.compile(r"^(#{1,6})\s+(.+)$", re.M)


@dataclass
class Chunk:
    id: str = field(default_factory=lambda: new_id("chk_"))
    text: str = ""
    ord: int = 0
    doc_id: str = ""
    tokens: int = 0
    meta: dict[str, Any] = field(default_factory=dict)

    def to_row(self) -> dict[str, Any]:
        return {"chunk_id": self.id, "text": self.text, "ord": self.ord,
                "tokens": self.tokens, "meta": self.meta}


def chunk_text(
    text: str,
    max_tokens: int = 900,
    overlap_tokens: int = 140,
    doc_id: str = "",
    meta: dict[str, Any] | None = None,
) -> list[Chunk]:
    """Split text into overlapping, retrievable chunks."""
    text = (text or "").strip()
    if not text:
        return []
    base_meta = dict(meta or {})

    if len(text) < max_tokens * 3:
        return [Chunk(text=text, ord=0, doc_id=doc_id,
                      tokens=estimate_tokens(text), meta=base_meta)]

    # Markdown: keep each heading with its body, split only oversized sections.
    if re.search(r"^#{1,6}\s+", text, re.M):
        return _chunk_markdown(text, max_tokens, overlap_tokens, doc_id, base_meta)

    # Code: split on top-level definitions.
    if re.search(r"^\s*(?:def|class|function|const|let|var|impl|struct|enum|type)\s+",
                 text, re.M):
        return _chunk_code(text, max_tokens, overlap_tokens, doc_id, base_meta)

    return _chunk_prose(text, max_tokens, overlap_tokens, doc_id, base_meta)


# --------------------------------------------------------------------------- #


def _chunk_markdown(text, max_tokens, overlap, doc_id, meta) -> list[Chunk]:
    matches = list(_MD_HEADING_RE.finditer(text))
    if not matches:
        return _chunk_prose(text, max_tokens, overlap, doc_id, meta)

    sections: list[tuple[str, str]] = []
    for i, m in enumerate(matches):
        start = m.start()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        sections.append((m.group(0).strip(), text[start:end].strip()))

    chunks: list[Chunk] = []
    buffer: list[str] = []
    header = ""
    tok = 0

    def flush() -> None:
        nonlocal buffer, tok, header
        if not buffer:
            return
        body = "\n\n".join(buffer).strip()
        if body:
            cm = dict(meta)
            cm["header"] = header
            chunks.append(Chunk(text=body, ord=len(chunks), doc_id=doc_id,
                                tokens=estimate_tokens(body), meta=cm))
        buffer, tok = [], 0

    for head, body in sections:
        btok = estimate_tokens(body)
        if btok > max_tokens:
            flush()
            header = head
            for sub in _split_oversized(body, max_tokens, overlap):
                cm = dict(meta)
                cm["header"] = head
                chunks.append(Chunk(text=sub, ord=len(chunks), doc_id=doc_id,
                                    tokens=estimate_tokens(sub), meta=cm))
            continue
        if tok + btok > max_tokens:
            flush()
            header = head
        if not buffer:
            header = head
        buffer.append(body)
        tok += btok
    flush()
    return chunks


def _chunk_code(text, max_tokens, overlap, doc_id, meta) -> list[Chunk]:
    lines = text.splitlines()
    blocks: list[str] = []
    current: list[str] = []
    in_doc = False
    doc_re = re.compile(r'("""|\'\'\')')

    for ln in lines:
        if doc_re.match(ln.strip()):
            in_doc = not in_doc
        starts_block = bool(re.match(
            r"^(def |class |async def |function |const |let |var |type |interface |"
            r"struct |enum |impl |trait |public |private |export |@|\s{0,4}def )", ln))
        if starts_block and current and not in_doc:
            blocks.append("\n".join(current))
            current = [ln]
        else:
            current.append(ln)
    if current:
        blocks.append("\n".join(current))

    chunks: list[Chunk] = []
    buf: list[str] = []
    tok = 0
    for b in blocks:
        bt = estimate_tokens(b)
        if bt > max_tokens * 2:
            if buf:
                chunks.append(_mk("\n\n".join(buf), len(chunks), doc_id, meta))
                buf, tok = [], 0
            for sub in _split_oversized(b, max_tokens, overlap):
                cm = dict(meta)
                cm["kind"] = "code_fragment"
                chunks.append(_mk(sub, len(chunks), doc_id, cm))
            continue
        if tok + bt > max_tokens:
            chunks.append(_mk("\n\n".join(buf), len(chunks), doc_id, meta))
            buf, tok = [], 0
        buf.append(b)
        tok += bt
    if buf:
        chunks.append(_mk("\n\n".join(buf), len(chunks), doc_id, meta))
    return chunks


def _chunk_prose(text, max_tokens, overlap, doc_id, meta) -> list[Chunk]:
    paras = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    if not paras:
        return []
    chunks: list[Chunk] = []
    buf: list[str] = []
    tok = 0
    for p in paras:
        pt = estimate_tokens(p)
        if pt > max_tokens:
            if buf:
                chunks.append(_mk("\n\n".join(buf), len(chunks), doc_id, meta))
                buf, tok = [], 0
            for sub in _split_oversized(p, max_tokens, overlap):
                chunks.append(_mk(sub, len(chunks), doc_id, meta))
            continue
        if tok + pt > max_tokens:
            body = "\n\n".join(buf)
            chunks.append(_mk(body, len(chunks), doc_id, meta))
            # Carry the tail forward so a fact spanning the cut survives.
            tail = _tail_tokens(body, overlap)
            buf = [tail] if tail else []
            tok = estimate_tokens(tail) if tail else 0
        buf.append(p)
        tok += pt
    if buf:
        chunks.append(_mk("\n\n".join(buf), len(chunks), doc_id, meta))
    return chunks


def _split_oversized(text: str, max_tokens: int, overlap: int) -> list[str]:
    words = text.split()
    if not words:
        return []
    out: list[str] = []
    step = max(1, max_tokens - overlap)
    for i in range(0, len(words), step):
        piece = " ".join(words[i:i + max_tokens])
        if piece.strip():
            out.append(piece)
        if i + max_tokens >= len(words):
            break
    return out


def _tail_tokens(text: str, n: int) -> str:
    words = text.split()
    if not words:
        return ""
    out: list[str] = []
    used = 0
    for w in reversed(words):
        t = estimate_tokens(w) + 1
        if used + t > n:
            break
        out.insert(0, w)
        used += t
    return " ".join(out)


def _mk(text: str, ord_: int, doc_id: str, meta: dict[str, Any]) -> Chunk:
    return Chunk(text=text, ord=ord_, doc_id=doc_id, tokens=estimate_tokens(text),
                 meta=dict(meta))
