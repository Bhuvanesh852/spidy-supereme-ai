"""Embeddings.

Priority order:
1. A real embedding model via Ollama (`nomic-embed-text`, `mxbai-embed-large`).
2. `sentence-transformers` if the user installed it.
3. The built-in hashed n-gram encoder — always available, zero download, and
   genuinely useful for retrieval. It is a character/word n-gram hashing
   projection with IDF weighting, which behaves like a lexical-semantic
   embedding and is far better than random vectors for this job.
"""
from __future__ import annotations

import hashlib
import math
import re
import struct
from collections import Counter
from typing import Any, Iterable

import numpy as np

from ..core.config import Settings

_WORD_RE = re.compile(r"[a-z0-9_]+")
_CAMEL_RE = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")


def split_identifiers(text: str) -> list[str]:
    """`getUserName` -> get user name. Small win, real retrieval gain."""
    out: list[str] = []
    for w in _WORD_RE.findall(text):
        parts = [p.lower() for p in _CAMEL_RE.split(w) if p]
        out.extend(parts if len(parts) > 1 else [w.lower()])
    return out


class BaseEmbedder:
    name = "base"
    dim = 384

    def embed(self, texts: list[str]) -> np.ndarray:
        raise NotImplementedError

    def embed_one(self, text: str) -> np.ndarray:
        return self.embed([text])[0]

    @staticmethod
    def cosine(a: np.ndarray, b: np.ndarray) -> float:
        na, nb = np.linalg.norm(a), np.linalg.norm(b)
        if na == 0 or nb == 0:
            return 0.0
        return float(np.dot(a, b) / (na * nb))


class HashingEmbedder(BaseEmbedder):
    """Deterministic hashed n-gram encoder with sublinear TF and L2 norm.

    No dependencies beyond numpy, no download, and stable across processes —
    which matters because the index must stay consistent on disk.
    """

    name = "spidy-hash-ngram-384"

    def __init__(self, dim: int = 384) -> None:
        self.dim = dim

    def _features(self, text: str) -> Counter:
        feats: Counter = Counter()
        low = text.lower()
        words = split_identifiers(low)
        for w in words:
            feats[f"w:{w}"] += 1
            if len(w) > 5:
                feats[f"p:{w[:5]}"] += 1
        # Word bigrams give a little word-order signal.
        for a, b in zip(words, words[1:]):
            feats[f"b:{a}_{b}"] += 1
        # Char 4-grams give robustness to typos and morphology.
        compact = "".join(words)
        for i in range(max(0, len(compact) - 3)):
            feats[f"c:{compact[i:i + 4]}"] += 1
        return feats

    def embed(self, texts: list[str]) -> np.ndarray:
        out = np.zeros((len(texts), self.dim), dtype=np.float32)
        for i, t in enumerate(texts):
            feats = self._features(t or "")
            if not feats:
                continue
            acc = np.zeros(self.dim, dtype=np.float32)
            for feat, count in feats.items():
                h = hashlib.blake2b(feat.encode("utf-8"), digest_size=8).digest()
                idx = struct.unpack("<Q", h)[0] % self.dim
                sign = 1.0 if (h[0] & 1) else -1.0
                # Sublinear TF damps repeated boilerplate.
                acc[idx] += sign * (1.0 + math.log(count))
            n = np.linalg.norm(acc)
            if n > 0:
                acc /= n
            out[i] = acc
        return out

    def embed_tokens(self, text: str) -> set[str]:
        return set(self._features(text).keys())


class OllamaEmbedder(BaseEmbedder):
    name = "ollama-embed"

    def __init__(self, settings: Settings, model: str = "nomic-embed-text") -> None:
        import httpx
        self._httpx = httpx
        self.endpoint = settings.ollama_endpoint.rstrip("/")
        self.model = model
        self.dim = 768

    def embed(self, texts: list[str]) -> np.ndarray:
        import asyncio
        return asyncio.get_event_loop().run_until_complete(self._aembed(texts))

    async def _aembed(self, texts: list[str]) -> np.ndarray:
        import asyncio
        out: list[list[float]] = []
        sem = asyncio.Semaphore(6)

        async with self._httpx.AsyncClient(timeout=60) as client:
            async def one(t: str) -> list[float]:
                async with sem:
                    try:
                        r = await client.post(
                            f"{self.endpoint}/api/embeddings",
                            json={"model": self.model, "prompt": t})
                        r.raise_for_status()
                        return r.json().get("embedding", [])
                    except Exception:
                        return []

            for vec in await asyncio.gather(*(one(t) for t in texts)):
                out.append(vec)
        if not out or not any(out):
            raise RuntimeError("ollama embeddings unavailable")
        width = max(len(v) for v in out if v)
        padded = [v + [0.0] * (width - len(v)) for v in out]
        return np.asarray(padded, dtype=np.float32)


class SentenceTransformerEmbedder(BaseEmbedder):
    name = "sentence-transformers"

    def __init__(self, model_name: str = "all-MiniLM-L6-v2") -> None:
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model_name)
        self.dim = int(self.model.get_sentence_embedding_dimension())

    def embed(self, texts: list[str]) -> np.ndarray:
        return np.asarray(
            self.model.encode(texts, convert_to_numpy=True, show_progress_bar=False,
                              normalize_embeddings=True),
            dtype=np.float32,
        )


# --------------------------------------------------------------------------- #


_EMBEDDER: BaseEmbedder | None = None


def get_embedder(settings: Settings | None = None) -> BaseEmbedder:
    """Resolve the best available embedder, caching the choice."""
    global _EMBEDDER
    if _EMBEDDER is not None:
        return _EMBEDDER

    if settings is None:
        from ..core.config import get_settings
        settings = get_settings()

    choice = (settings.embedding_model or "").lower()

    if "hash" in choice or not choice:
        _EMBEDDER = HashingEmbedder(settings.embedding_dim)
        return _EMBEDDER

    if "ollama" in choice:
        try:
            _EMBEDDER = OllamaEmbedder(settings, settings.model_roles.get("embedding", ""))
            return _EMBEDDER
        except Exception:
            pass

    if "st" in choice or "minilm" in choice or "sentence" in choice:
        try:
            _EMBEDDER = SentenceTransformerEmbedder(choice)
            return _EMBEDDER
        except Exception:
            pass

    # Unknown or unavailable → the built-in encoder, which always works.
    _EMBEDDER = HashingEmbedder(settings.embedding_dim)
    return _EMBEDDER


def reset_embedder() -> None:
    global _EMBEDDER
    _EMBEDDER = None
