"""Research tools: the deep-research pipeline exposed as agent tools.

Exposes RAG search, project understanding, and the multi-stage research
orchestrator so the runtime can invoke them like any other capability.
"""
from __future__ import annotations

import json
import re
import time
from pathlib import Path
from typing import Any

from ..core.schemas import RiskLevel, ToolResult, ToolSpec
from .base import ToolContext, ToolRegistry, deny, fail, ok

MANIFEST_FILES = {
    "package.json": "npm/node", "pyproject.toml": "python", "setup.py": "python",
    "requirements.txt": "python", "Cargo.toml": "rust", "go.mod": "go",
    "pom.xml": "java/maven", "build.gradle": "java/gradle", "Gemfile": "ruby",
    "composer.json": "php", "pubspec.yaml": "dart/flutter", "CMakeLists.txt": "c/c++",
    "Makefile": "make", "Dockerfile": "docker", "docker-compose.yml": "docker",
}
TEST_DIRS = ("tests", "test", "__tests__", "spec")


def build(registry: ToolRegistry) -> None:
    S = ToolSpec

    @registry.register(S(
        name="rag_search",
        description="Search the indexed knowledge base (files, docs, notes). "
                    "Hybrid semantic + lexical retrieval with reranking. "
                    "Use before answering anything about this user's own data.",
        input_schema={"type": "object", "properties": {
            "query": {"type": "string"},
            "top_k": {"type": "integer"},
            "project": {"type": "string"}}, "required": ["query"]},
        risk_level=RiskLevel.READ, timeout_seconds=60, idempotent=True,
        tags=["rag", "research", "read"],
    ))
    async def rag_search(query: str, ctx: ToolContext, top_k: int = 8,
                         project: str = "") -> ToolResult:
        from ..rag.retriever import Retriever
        if ctx.extra.get("retriever") is None:
            return fail("rag_search", "retriever not initialised", "not_available")
        r: Retriever = ctx.extra["retriever"]
        hits = r.search(query, top_k=top_k, budget=ctx.budget,
                        project=project or Path(ctx.workspace_root or ".").name)
        if not hits:
            return ok("rag_search", query=query, results=[], count=0,
                      message="no indexed documents matched — answer from general "
                              "knowledge and say the index was empty")
        return ok("rag_search", query=query, count=len(hits),
                  results=[{"text": h.text[:1500], "source": h.source, "uri": h.uri,
                            "score": h.score, "signals": h.signals,
                            "citation": h.citation()} for h in hits])

    @registry.register(S(
        name="index_workspace",
        description="Index project files into the knowledge base so future "
                    "questions can be answered from the user's own code and docs.",
        input_schema={"type": "object", "properties": {
            "path": {"type": "string"}, "extensions": {"type": "array",
            "items": {"type": "string"}}, "max_files": {"type": "integer"}},
            "required": []},
        risk_level=RiskLevel.READ, timeout_seconds=600, tags=["rag", "index"],
    ))
    async def index_workspace(ctx: ToolContext, path: str = ".",
                              extensions: list[str] | None = None,
                              max_files: int = 2000) -> ToolResult:
        from ..rag.retriever import Retriever
        if ctx.extra.get("retriever") is None:
            return fail("index_workspace", "retriever not initialised", "not_available")
        r: Retriever = ctx.extra["retriever"]
        root = ctx.policy.check(path, "read")
        if not root.allowed:
            return deny("index_workspace", root.reason)
        exts = {e.lower() if e.startswith(".") else "." + e.lower()
                for e in (extensions or [".md", ".txt", ".rst", ".py", ".js", ".ts",
                                         ".tsx", ".jsx", ".json", ".yaml", ".yml",
                                         ".html", ".css", ".java", ".go", ".rs",
                                         ".sql", ".sh", ".toml"])}
        indexed, skipped, total_chunks = 0, 0, 0
        project = Path(root.path).name
        from ..security.policy import DEFAULT_IGNORED_DIRS
        for f in sorted(root.path.rglob("*")):
            if indexed >= max_files:
                break
            if not f.is_file() or f.suffix.lower() not in exts:
                continue
            if any(p in DEFAULT_IGNORED_DIRS for p in f.parts):
                continue
            if f.stat().st_size > 1_500_000:
                skipped += 1
                continue
            try:
                text = f.read_text(encoding="utf-8", errors="replace")
            except OSError:
                skipped += 1
                continue
            if len(text.strip()) < 30:
                skipped += 1
                continue
            res = r.index_document(text, source=str(f), uri=str(f), project=project,
                                   meta={"kind": _kind_of(f), "project": project})
            total_chunks += res.get("chunks", 0)
            indexed += 1
        stats = r.stats()
        return ok("index_workspace", indexed=indexed, skipped=skipped,
                  chunks=total_chunks, total_documents=stats["documents"],
                  total_chunks_indexed=stats["chunks"], embedder=stats["embedder"])

    @registry.register(S(
        name="deep_research",
        description="Run the full research pipeline: decompose the question, "
                    "search in parallel, fetch and cross-check sources, detect "
                    "conflicts, then synthesize with citations and a confidence "
                    "rating. This is the deep-research path — prefer it over "
                    "manual searching for any non-trivial question.",
        input_schema={"type": "object", "properties": {
            "question": {"type": "string"},
            "depth": {"type": "string", "description": "quick|standard|thorough"},
            "max_sources": {"type": "integer"}}, "required": ["question"]},
        risk_level=RiskLevel.LOW, timeout_seconds=600, idempotent=True,
        tags=["research", "web"],
    ))
    async def deep_research(question: str, ctx: ToolContext, depth: str = "standard",
                            max_sources: int = 6) -> ToolResult:
        from ..research.pipeline import run_research
        if not ctx.allow_network:
            return deny("deep_research", "network access is disabled")
        report = await run_research(
            question, ctx, depth=depth, max_sources=max_sources,
            emit=ctx.extra.get("emit"))
        if ctx.db:
            ctx.db.record_artifact(
                json.dumps(report, indent=2)[:200], "research", ctx.task_id,
                meta={"question": question})
        return ok("deep_research", **report)

    @registry.register(S(
        name="understand_project",
        description="Detect the language, framework, package manager, test runner, "
                    "entry points, and structure of a project. Run this first for "
                    "any unfamiliar codebase.",
        input_schema={"type": "object", "properties": {"path": {"type": "string"}}},
        risk_level=RiskLevel.READ, timeout_seconds=60, idempotent=True,
        tags=["project", "read"],
    ))
    async def understand_project(ctx: ToolContext, path: str = ".") -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("understand_project", d.reason)
        root = d.path
        from ..security.policy import DEFAULT_IGNORED_DIRS

        found: dict[str, str] = {}
        for m, kind in MANIFEST_FILES.items():
            if (root / m).exists():
                found[kind] = m

        languages: dict[str, int] = {}
        entrypoints: list[str] = []
        test_runner = ""
        for f in root.rglob("*"):
            if not f.is_file():
                continue
            if any(p in DEFAULT_IGNORED_DIRS for p in f.relative_to(root).parts):
                continue
            ext = f.suffix.lower()
            if ext in (".py", ".js", ".jsx", ".ts", ".tsx", ".java", ".go", ".rs",
                       ".rb", ".php", ".c", ".cpp", ".cs", ".swift", ".kt"):
                languages[ext] = languages.get(ext, 0) + 1
            rel = str(f.relative_to(root))
            if ext == ".py" and rel in ("main.py", "app.py", "__main__.py", "manage.py"):
                entrypoints.append(rel)
            if ext in ("main.py", "app.py", "index.js", "index.ts", "server.py",
                       "cli.py", "main.go", "main.rs") and len(entrypoints) < 20:
                if rel.count(os.sep) <= 2:
                    entrypoints.append(rel)
            if (root / "conftest.py").exists() or "tests" in rel.split(os.sep):
                test_runner = test_runner or "pytest"
            if (root / "jest.config.js").exists() or (root / "vitest.config.ts").exists():
                test_runner = "jest/vitest"

        pm = ""
        lock = (root / "package-lock.json").exists() or (root / "yarn.lock").exists() \
            or (root / "pnpm-lock.yaml").exists()
        if "package.json" in found.values():
            pm = "npm/pnpm/yarn" if lock else "npm"

        py = (root / "pyproject.toml").read_text(encoding="utf-8", errors="replace") \
            if (root / "pyproject.toml").exists() else ""
        framework = ""
        for pat, name in ((r"fastapi", "FastAPI"), (r"flask", "Flask"),
                          (r"django", "Django"), (r"^\s*streamlit", "Streamlit"),
                          (r"langgraph", "LangGraph"), (r"crewai", "CrewAI"),
                          (r"transformers", "Transformers"), (r"torch", "PyTorch")):
            if re.search(pat, py, re.M | re.I):
                framework = name
                break
        if not framework and (root / "package.json").exists():
            try:
                pkg = json.loads((root / "package.json").read_text(encoding="utf-8"))
                deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
                for name, dep in (("React", "react"), ("Next.js", "next"),
                                  ("Vue", "vue"), ("Express", "express"),
                                  ("Vite", "vite")):
                    if dep in deps:
                        framework = name
                        break
            except (json.JSONDecodeError, OSError):
                pass

        main_lang = max(languages, key=lambda k: languages[k]) if languages else ""
        return ok("understand_project", root=str(root), languages=dict(
            sorted(languages.items(), key=lambda kv: -kv[1])[:10]),
            primary_language=main_lang, frameworks=found, framework=framework,
            package_manager=pm, test_runner=test_runner or "none detected",
            entrypoints=sorted(set(entrypoints))[:15],
            has_git=(root / ".git").exists(), has_docker=(root / "Dockerfile").exists(),
            has_ci=(root / ".github" / "workflows").is_dir(),
            total_files=sum(languages.values()))

    @registry.register(S(
        name="list_projects",
        description="List indexed documents and their source locations.",
        input_schema={"type": "object", "properties": {"project": {"type": "string"}}},
        risk_level=RiskLevel.READ, timeout_seconds=30, idempotent=True, tags=["rag", "read"],
    ))
    async def list_projects(ctx: ToolContext, project: str = "") -> ToolResult:
        rows = ctx.db.query(
            "SELECT source, COUNT(*) c, SUM(chunk_count) k FROM docs "
            "WHERE (?='' OR project=?) GROUP BY source ORDER BY c DESC LIMIT 100",
            (project, project))
        return ok("list_projects", projects=[{"source": r["source"], "documents": r["c"],
                                              "chunks": r["k"]} for r in rows],
                  count=len(rows))

    @registry.register(S(
        name="remember", description="Store a durable fact, lesson, or preference "
                                     "for future sessions.",
        input_schema={"type": "object", "properties": {
            "content": {"type": "string"},
            "scope": {"type": "string", "description": "semantic|episodic|preference"},
            "importance": {"type": "number"}}, "required": ["content"]},
        risk_level=RiskLevel.LOW, timeout_seconds=15, tags=["memory"],
    ))
    async def remember(content: str, ctx: ToolContext, scope: str = "semantic",
                       importance: float = 0.5) -> ToolResult:
        scope = scope if scope in ("semantic", "episodic", "preference") else "semantic"
        mid = ctx.db.remember(scope, content, project=Path(ctx.workspace_root or ".").name,
                              importance=max(0.0, min(1.0, importance)))
        return ok("remember", id=mid, scope=scope)

    @registry.register(S(
        name="recall", description="Retrieve stored memories relevant to a query.",
        input_schema={"type": "object", "properties": {
            "query": {"type": "string"}, "scope": {"type": "string"},
            "limit": {"type": "integer"}}, "required": ["query"]},
        risk_level=RiskLevel.READ, timeout_seconds=15, idempotent=True,
        tags=["memory", "read"],
    ))
    async def recall(query: str, ctx: ToolContext, scope: str = "", limit: int = 10) -> ToolResult:
        rows = ctx.db.recall(scope=scope or "", project=Path(ctx.workspace_root or ".").name,
                             limit=limit, query=query[:120])
        return ok("recall", memories=[{"scope": r["scope"], "content": r["content"],
                                        "importance": r["importance"]} for r in rows],
                  count=len(rows))


def _kind_of(f: Path) -> str:
    if f.suffix in (".md", ".rst", ".txt"):
        return "document"
    if f.suffix in (".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".go", ".rs"):
        return "code"
    return "data"


import os  # noqa: E402
