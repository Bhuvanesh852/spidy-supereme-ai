"""Filesystem tools.

Every path goes through FilesystemPolicy, and every write is snapshot first so
the repair loop can roll back.
"""
from __future__ import annotations

import ast
import difflib
import fnmatch
import hashlib
import json
import os
import re
import shutil
from pathlib import Path
from typing import Any

from ..core.schemas import RiskLevel, ToolResult, ToolSpec, ToolStatus
from ..security.policy import DEFAULT_IGNORED_DIRS
from .base import ToolContext, ToolRegistry, deny, fail, ok

BINARY_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".ico", ".pdf", ".zip", ".gz",
    ".tar", ".bz2", ".xz", ".7z", ".exe", ".dll", ".so", ".dylib", ".class", ".jar",
    ".pyc", ".pyo", ".woff", ".woff2", ".ttf", ".eot", ".mp3", ".mp4", ".mov", ".webm",
    ".sqlite", ".db", ".bin", ".dat", ".o", ".a", ".wasm",
}
TEXT_EXTENSIONS = {
    ".py", ".js", ".jsx", ".ts", ".tsx", ".java", ".c", ".h", ".cpp", ".hpp", ".cs",
    ".go", ".rs", ".rb", ".php", ".swift", ".kt", ".scala", ".sh", ".bash", ".zsh",
    ".sql", ".html", ".css", ".scss", ".json", ".yaml", ".yml", ".toml", ".ini",
    ".cfg", ".md", ".markdown", ".rst", ".txt", ".xml", ".env", ".gitignore", ".lock",
    ".vue", ".svelte", ".ex", ".exs", ".lua", ".r", ".jl", ".dart",
}
LANG_BY_EXT = {
    ".py": "python", ".js": "javascript", ".jsx": "javascript", ".ts": "typescript",
    ".tsx": "typescript", ".java": "java", ".c": "c", ".h": "c", ".cpp": "cpp",
    ".go": "go", ".rs": "rust", ".rb": "ruby", ".php": "php", ".sh": "bash",
    ".sql": "sql", ".html": "html", ".css": "css", ".json": "json", ".yaml": "yaml",
    ".yml": "yaml", ".md": "markdown", ".toml": "toml",
}


def _is_ignored(name: str) -> bool:
    if name in DEFAULT_IGNORED_DIRS:
        return True
    return any(fnmatch.fnmatch(name, pat) for pat in DEFAULT_IGNORED_DIRS)


def _guess_language(path: Path) -> str:
    return LANG_BY_EXT.get(path.suffix.lower(), "text")


def _walk(root: Path, max_files: int = 20000, include_hidden: bool = False):
    count = 0
    stack = [root]
    while stack and count < max_files:
        d = stack.pop()
        try:
            entries = list(d.iterdir())
        except (PermissionError, OSError):
            continue
        for e in entries:
            if _is_ignored(e.name):
                continue
            if not include_hidden and e.name.startswith("."):
                continue
            if e.is_dir():
                stack.append(e)
            elif e.is_file():
                count += 1
                yield e
                if count >= max_files:
                    return


# --------------------------------------------------------------------------- #


def build(registry: ToolRegistry) -> None:
    S = ToolSpec

    # ---- read -------------------------------------------------------- #
    @registry.register(S(
        name="read_file",
        description="Read a text file. Returns numbered lines; large files are "
                    "auto-windowed around the requested region.",
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path, relative to workspace root"},
                "start_line": {"type": "integer", "description": "1-based first line"},
                "end_line": {"type": "integer", "description": "1-based last line (inclusive)"},
            },
            "required": ["path"],
        },
        risk_level=RiskLevel.READ, timeout_seconds=30, idempotent=True, tags=["fs", "read"],
    ))
    async def read_file(path: str, ctx: ToolContext, start_line: int = 1,
                        end_line: int = 0) -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("read_file", d.reason)
        p = d.path
        if not p.exists():
            return fail("read_file", f"no such file: {p}", "not_found")
        if p.is_dir():
            return fail("read_file", f"{p} is a directory — use list_files", "is_directory")
        if p.suffix.lower() in BINARY_EXTENSIONS or p.stat().st_size > 12_000_000:
            return ok("read_file", path=str(p), binary=True, size=p.stat().st_size,
                      hint="binary file — use run_python to inspect bytes")

        text = p.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()
        total = len(lines)
        end = end_line or (start_line + 900)
        window = lines[max(0, start_line - 1): end]
        numbered = "\n".join(f"{i:>5} | {ln}" for i, ln in enumerate(window, start=start_line))
        header = f"# {p} (lines {start_line}-{start_line + len(window) - 1} of {total}, " \
                 f"{_guess_language(p)})\n"
        return ok("read_file", path=str(p), content=header + numbered,
                  total_lines=total, lines_returned=len(window),
                  language=_guess_language(p), size=p.stat().st_size)

    @registry.register(S(
        name="read_many_files",
        description="Read several files at once. More token-efficient than "
                    "separate read_file calls when you need breadth.",
        input_schema={
            "type": "object",
            "properties": {
                "paths": {"type": "array", "items": {"type": "string"}},
                "max_total_chars": {"type": "integer"},
            },
            "required": ["paths"],
        },
        risk_level=RiskLevel.READ, timeout_seconds=60, idempotent=True, tags=["fs", "read"],
    ))
    async def read_many_files(paths: list[str], ctx: ToolContext,
                              max_total_chars: int = 60_000) -> ToolResult:
        if not isinstance(paths, list) or not paths:
            return fail("read_many_files", "paths must be a non-empty array", "invalid_arguments")
        out: list[str] = []
        total = 0
        errors: list[str] = []
        for raw in paths[:60]:
            d = ctx.policy.check(raw, "read")
            if not d.allowed:
                errors.append(f"{raw}: {d.reason}")
                continue
            p = d.path
            if not p.exists() or not p.is_file():
                errors.append(f"{raw}: not found")
                continue
            if p.stat().st_size > 2_000_000:
                errors.append(f"{raw}: too large")
                continue
            try:
                body = p.read_text(encoding="utf-8", errors="replace")
            except OSError as exc:
                errors.append(f"{raw}: {exc}")
                continue
            if total + len(body) > max_total_chars:
                body = body[: max(0, max_total_chars - total)]
            total += len(body)
            out.append(f"===== {p} =====\n{body}")
            if total >= max_total_chars:
                break
        return ok("read_many_files", files="\n\n".join(out), count=len(out),
                  errors=errors, chars=total)

    # ---- discover ------------------------------------------------------ #
    @registry.register(S(
        name="list_files",
        description="List directory contents as a tree. Skips vendor/build dirs.",
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "depth": {"type": "integer", "description": "Max depth, default 3"},
                "max_entries": {"type": "integer", "description": "Default 400"},
            },
        },
        risk_level=RiskLevel.READ, timeout_seconds=45, idempotent=True, tags=["fs", "read"],
    ))
    async def list_files(ctx: ToolContext, path: str = ".", depth: int = 3,
                         max_entries: int = 400) -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("list_files", d.reason)
        root = d.path
        if not root.exists():
            return fail("list_files", f"no such directory: {root}", "not_found")
        if root.is_file():
            return ok("list_files", tree=str(root), entries=1)

        lines: list[str] = [str(root)]
        count = 0
        try:
            for dirpath, dirnames, filenames in os.walk(root):
                dirnames[:] = [x for x in dirnames if not _is_ignored(x) and not x.startswith(".")]
                rel = Path(dirpath).relative_to(root)
                level = len(rel.parts)
                if level >= depth:
                    dirnames[:] = []
                for f in sorted(filenames):
                    if f.startswith("."):
                        continue
                    lines.append("  " * (level + 1) + f)
                    count += 1
                    if count >= max_entries:
                        lines.append("  ... (truncated)")
                        return ok("list_files", tree="\n".join(lines), entries=count,
                                  truncated=True)
        except OSError as exc:
            return fail("list_files", str(exc), "io_error")
        return ok("list_files", tree="\n".join(lines), entries=count)

    @registry.register(S(
        name="find_files",
        description="Find files by glob or content regex. Respects ignore rules.",
        input_schema={
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Glob like **/*.py or *.ts"},
                "content_regex": {"type": "string", "description": "Search file contents"},
                "path": {"type": "string"},
                "max_results": {"type": "integer", "description": "Default 100"},
            },
        },
        risk_level=RiskLevel.READ, timeout_seconds=60, idempotent=True, tags=["fs", "read"],
    ))
    async def find_files(ctx: ToolContext, pattern: str = "", content_regex: str = "",
                         path: str = ".", max_results: int = 100) -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("find_files", d.reason)
        root = d.path
        if not root.exists():
            return fail("find_files", f"no such directory: {root}", "not_found")

        if content_regex:
            try:
                rx = re.compile(content_regex)
            except re.error as exc:
                return fail("find_files", f"invalid regex: {exc}", "invalid_arguments")

        hits: list[dict[str, Any]] = []
        globber = pattern.strip() if pattern else ""
        for f in _walk(root, max_files=40000):
            if len(hits) >= max_results:
                break
            if globber and not (fnmatch.fnmatch(f.name, globber) or f.match(globber)):
                continue
            if content_regex:
                if f.suffix.lower() in BINARY_EXTENSIONS:
                    continue
                try:
                    text = f.read_text(encoding="utf-8", errors="replace")
                except OSError:
                    continue
                for i, line in enumerate(text.splitlines(), 1):
                    if rx.search(line):
                        hits.append({
                            "path": str(f), "line": i,
                            "text": line.strip()[:240],
                        })
                        if len(hits) >= max_results:
                            break
            else:
                hits.append({"path": str(f), "size": f.stat().st_size,
                             "language": _guess_language(f)})
        return ok("find_files", matches=hits, count=len(hits))

    @registry.register(S(
        name="search_in_files",
        description="Regex content search with context lines. Faster and more "
                    "precise than find_files+content_regex for code search.",
        input_schema={
            "type": "object",
            "properties": {
                "regex": {"type": "string"},
                "path": {"type": "string"},
                "glob": {"type": "string", "description": "Restrict to e.g. *.py"},
                "context_lines": {"type": "integer", "description": "Default 1"},
                "max_results": {"type": "integer", "description": "Default 60"},
            },
            "required": ["regex"],
        },
        risk_level=RiskLevel.READ, timeout_seconds=60, idempotent=True, tags=["fs", "read"],
    ))
    async def search_in_files(regex: str, ctx: ToolContext, path: str = ".",
                              glob: str = "", context_lines: int = 1,
                              max_results: int = 60) -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("search_in_files", d.reason)
        try:
            rx = re.compile(regex, re.MULTILINE)
        except re.error as exc:
            return fail("search_in_files", f"invalid regex: {exc}", "invalid_arguments")

        root = d.path
        ctxl = max(0, min(context_lines, 3))
        matches: list[str] = []
        files_hit: set[str] = set()
        truncated = False
        for f in _walk(root):
            if f.suffix.lower() in BINARY_EXTENSIONS:
                continue
            if glob and not fnmatch.fnmatch(f.name, glob):
                continue
            try:
                lines = f.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            for i, line in enumerate(lines):
                if not rx.search(line):
                    continue
                files_hit.add(str(f))
                lo, hi = max(0, i - ctxl), min(len(lines), i + ctxl + 1)
                block = "\n".join(
                    ("> " if j == i else "  ") + lines[j][:240] for j in range(lo, hi))
                matches.append(f"{f}:{i + 1}\n{block}")
                if len(matches) >= max_results:
                    truncated = True
                    break
            if truncated:
                break
        return ok("search_in_files", output="\n\n".join(matches), count=len(matches),
                  files=len(files_hit), truncated=truncated)

    # ---- write --------------------------------------------------------- #
    def _snapshot(p: Path, task_id: str) -> str:
        """Save the pre-edit content to the task's checkpoint dir so a bad
        edit is reversible during the repair loop."""
        if not p.exists() or p.stat().st_size > 5_000_000:
            return ""
        content = p.read_text(encoding="utf-8", errors="replace")
        try:
            from ..core.config import get_settings
            snap_dir = get_settings().checkpoint_dir / "snapshots" / (task_id or "adhoc")
            snap_dir.mkdir(parents=True, exist_ok=True)
            key = hashlib.sha256(str(p).encode()).hexdigest()[:16]
            (snap_dir / f"{key}.snap").write_text(
                json.dumps({"path": str(p), "content": content}), encoding="utf-8")
        except OSError:
            pass
        return content

    @registry.register(S(
        name="write_file",
        description="Create a file or overwrite it entirely. Prefer edit_file for "
                    "changes to existing files.",
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "content": {"type": "string"},
                "overwrite": {"type": "boolean", "description": "Default true"},
            },
            "required": ["path", "content"],
        },
        risk_level=RiskLevel.MEDIUM, timeout_seconds=30, tags=["fs", "write"],
    ))
    async def write_file(path: str, content: str, ctx: ToolContext,
                         overwrite: bool = True) -> ToolResult:
        d = ctx.policy.check(path, "write")
        if not d.allowed:
            return deny("write_file", d.reason)
        p = d.path
        existed = p.exists()
        if existed and not overwrite:
            return fail("write_file", f"{p} exists and overwrite=false", "exists")
        if existed:
            _snapshot(p, ctx.task_id)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return ok("write_file", path=str(p), created=not existed, bytes=len(content.encode()),
                  action="created" if not existed else "overwrote")

    @registry.register(S(
        name="edit_file",
        description="Make a targeted replacement in a file. old_text must be "
                    "unique — the tool refuses ambiguous matches. This is the "
                    "preferred way to change code.",
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "old_text": {"type": "string", "description": "Exact existing text to replace"},
                "new_text": {"type": "string"},
                "replace_all": {"type": "boolean", "description": "Default false"},
            },
            "required": ["path", "old_text", "new_text"],
        },
        risk_level=RiskLevel.MEDIUM, timeout_seconds=30, tags=["fs", "write"],
    ))
    async def edit_file(path: str, old_text: str, new_text: str, ctx: ToolContext,
                        replace_all: bool = False) -> ToolResult:
        d = ctx.policy.check(path, "write")
        if not d.allowed:
            return deny("edit_file", d.reason)
        p = d.path
        if not p.exists():
            return fail("edit_file", f"no such file: {p}", "not_found")
        original = p.read_text(encoding="utf-8", errors="replace")
        if old_text not in original:
            # Offer a near-match so the agent can self-correct in one step.
            close = difflib.get_close_matches(
                old_text[:200], [ln for ln in original.splitlines() if len(ln) > 8][:400],
                n=3, cutoff=0.72)
            return fail("edit_file",
                        "old_text not found in file. Re-read the file and use exact text.",
                        "no_match", suggestions=close)
        count = original.count(old_text)
        if count > 1 and not replace_all:
            return fail("edit_file",
                        f"old_text appears {count} times — add surrounding context to "
                        "make it unique, or set replace_all=true",
                        "ambiguous_match", occurrences=count)
        updated = original.replace(old_text, new_text) if replace_all \
            else original.replace(old_text, new_text, 1)
        if updated == original:
            return fail("edit_file", "replacement produced no change", "no_change")
        _snapshot(p, ctx.task_id)
        p.write_text(updated, encoding="utf-8")
        diff = list(difflib.unified_diff(
            original.splitlines(), updated.splitlines(),
            fromfile=f"a/{p.name}", tofile=f"b/{p.name}", lineterm="", n=2))
        return ok("edit_file", path=str(p), action="edited", replacements=count,
                  diff="\n".join(diff[:60]),
                  added=len(updated.splitlines()) - len(original.splitlines()))

    @registry.register(S(
        name="apply_patch",
        description="Apply a unified diff. Validates the patch applies cleanly "
                    "before touching disk.",
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "patch": {"type": "string", "description": "Unified diff content"},
            },
            "required": ["path", "patch"],
        },
        risk_level=RiskLevel.MEDIUM, timeout_seconds=30, tags=["fs", "write"],
    ))
    async def apply_patch(path: str, patch: str, ctx: ToolContext) -> ToolResult:
        import subprocess
        d = ctx.policy.check(path, "write")
        if not d.allowed:
            return deny("apply_patch", d.reason)
        p = d.path
        if not p.exists():
            return fail("apply_patch", f"no such file: {p}", "not_found")
        if ctx.command_policy is not None:
            cd = ctx.command_policy.evaluate("patch --dry-run")
            if not cd.allowed:
                return deny("apply_patch", cd.reason)
        _snapshot(p, ctx.task_id)
        original = p.read_text(encoding="utf-8", errors="replace")
        try:
            proc = subprocess.run(
                ["patch", "-p0", "--forward", "--batch", str(p)],
                input=patch, capture_output=True, text=True, timeout=30,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
            return fail("apply_patch", f"patch unavailable: {exc}", "patch_error")
        if proc.returncode != 0:
            p.write_text(original, encoding="utf-8")  # rollback
            return fail("apply_patch", f"patch failed: {proc.stderr.strip()[:400]}", "patch_error")
        return ok("apply_patch", path=str(p), action="patched", output=proc.stdout.strip()[:500])

    @registry.register(S(
        name="move_file", description="Move or rename a file or directory.",
        input_schema={"type": "object", "properties": {
            "source": {"type": "string"}, "destination": {"type": "string"},
            "overwrite": {"type": "boolean"}}, "required": ["source", "destination"]},
        risk_level=RiskLevel.MEDIUM, timeout_seconds=30, tags=["fs", "write"],
    ))
    async def move_file(source: str, destination: str, ctx: ToolContext,
                        overwrite: bool = False) -> ToolResult:
        s = ctx.policy.check(source, "write")
        if not s.allowed:
            return deny("move_file", s.reason)
        t = ctx.policy.check(destination, "write")
        if not t.allowed:
            return deny("move_file", t.reason)
        if not s.path.exists():
            return fail("move_file", f"source not found: {s.path}", "not_found")
        if t.path.exists() and not overwrite:
            return fail("move_file", f"destination exists: {t.path}", "exists")
        t.path.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(s.path), str(t.path))
        return ok("move_file", source=str(s.path), destination=str(t.path), action="moved")

    @registry.register(S(
        name="copy_file", description="Copy a file or directory tree.",
        input_schema={"type": "object", "properties": {
            "source": {"type": "string"}, "destination": {"type": "string"}},
            "required": ["source", "destination"]},
        risk_level=RiskLevel.MEDIUM, timeout_seconds=60, tags=["fs", "write"],
    ))
    async def copy_file(source: str, destination: str, ctx: ToolContext) -> ToolResult:
        s = ctx.policy.check(source, "read")
        if not s.allowed:
            return deny("copy_file", s.reason)
        t = ctx.policy.check(destination, "write")
        if not t.allowed:
            return deny("copy_file", t.reason)
        if not s.path.exists():
            return fail("copy_file", f"source not found: {s.path}", "not_found")
        t.path.parent.mkdir(parents=True, exist_ok=True)
        if s.path.is_dir():
            shutil.copytree(str(s.path), str(t.path), dirs_exist_ok=True)
        else:
            shutil.copy2(str(s.path), str(t.path))
        return ok("copy_file", source=str(s.path), destination=str(t.path), action="copied")

    @registry.register(S(
        name="delete_file", description="Delete a file. Directories require "
                                       "recursive=true and hit DESTRUCTIVE risk.",
        input_schema={"type": "object", "properties": {
            "path": {"type": "string"}, "recursive": {"type": "boolean"}},
            "required": ["path"]},
        risk_level=RiskLevel.HIGH, timeout_seconds=60, tags=["fs", "write", "destructive"],
    ))
    async def delete_file(path: str, ctx: ToolContext, recursive: bool = False) -> ToolResult:
        d = ctx.policy.check(path, "write")
        if not d.allowed:
            return deny("delete_file", d.reason)
        p = d.path
        if not p.exists():
            return ok("delete_file", path=str(p), action="noop", note="already absent")
        if p.is_dir():
            if not recursive:
                return fail("delete_file", f"{p} is a directory — set recursive=true",
                            "is_directory")
            shutil.rmtree(p)
            return ok("delete_file", path=str(p), action="deleted_dir")
        _snapshot(p, ctx.task_id)
        p.unlink()
        return ok("delete_file", path=str(p), action="deleted")

    # ---- analysis ------------------------------------------------------ #
    @registry.register(S(
        name="file_diff", description="Compare two files, or show git diff for one.",
        input_schema={"type": "object", "properties": {
            "left": {"type": "string"}, "right": {"type": "string"},
            "context_lines": {"type": "integer"}}, "required": ["left", "right"]},
        risk_level=RiskLevel.READ, timeout_seconds=30, idempotent=True, tags=["fs", "read"],
    ))
    async def file_diff(left: str, right: str, ctx: ToolContext,
                        context_lines: int = 3) -> ToolResult:
        l = ctx.policy.check(left, "read")
        r = ctx.policy.check(right, "read")
        if not (l.allowed and r.allowed):
            return deny("file_diff", l.reason or r.reason)
        if not (l.path.exists() and r.path.exists()):
            return fail("file_diff", "one or both files missing", "not_found")
        a = l.path.read_text(encoding="utf-8", errors="replace").splitlines()
        b = r.path.read_text(encoding="utf-8", errors="replace").splitlines()
        diff = list(difflib.unified_diff(
            a, b, fromfile=left, tofile=right, lineterm="", n=max(0, context_lines)))
        return ok("file_diff", diff="\n".join(diff) or "(identical)",
                  changed=len([x for x in diff if x.startswith(("+", "-"))
                               and not x.startswith(("+++", "---"))]))

    @registry.register(S(
        name="file_stats", description="Line counts, language, and structure summary.",
        input_schema={"type": "object", "properties": {"path": {"type": "string"}},
                      "required": ["path"]},
        risk_level=RiskLevel.READ, timeout_seconds=30, idempotent=True, tags=["fs", "read"],
    ))
    async def file_stats(path: str, ctx: ToolContext) -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("file_stats", d.reason)
        p = d.path
        if not p.is_file():
            return fail("file_stats", f"not a file: {p}", "not_found")
        text = p.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()
        code = sum(1 for ln in lines if ln.strip() and not ln.strip().startswith("#"))
        comments = sum(1 for ln in lines if ln.strip().startswith(("#", "//", "*", "/*")))
        blanks = sum(1 for ln in lines if not ln.strip())
        funcs: list[str] = []
        if p.suffix == ".py":
            try:
                tree = ast.parse(text)
                funcs = [n.name for n in ast.walk(tree)
                         if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
                classes = [n.name for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]
            except SyntaxError as exc:
                return fail("file_stats", f"python syntax error at line {exc.lineno}: {exc.msg}",
                            "syntax_error", line=exc.lineno)
        else:
            classes = re.findall(r"^\s*(?:export\s+)?(?:class|struct|interface|enum)\s+(\w+)",
                                 text, re.M)
            funcs = re.findall(r"^\s*(?:export\s+)?(?:async\s+)?def\s+(\w+)", text, re.M) + \
                re.findall(r"(?:function|const|let|var)\s+(\w+)\s*[=(]", text)
        return ok("file_stats", path=str(p), language=_guess_language(p), total_lines=len(lines),
                  code_lines=code, comment_lines=comments, blank_lines=blanks,
                  classes=classes[:60], functions=funcs[:120],
                  bytes=len(text.encode()), sha256=hashlib.sha256(text.encode()).hexdigest()[:16])

    @registry.register(S(
        name="file_history", description="Recent modifications under a path, newest first.",
        input_schema={"type": "object", "properties": {
            "path": {"type": "string"}, "limit": {"type": "integer"}}},
        risk_level=RiskLevel.READ, timeout_seconds=45, idempotent=True, tags=["fs", "read"],
    ))
    async def file_history(ctx: ToolContext, path: str = ".", limit: int = 40) -> ToolResult:
        import time
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("file_history", d.reason)
        rows: list[dict[str, Any]] = []
        for f in _walk(d.path, max_files=20000):
            try:
                st = f.stat()
            except OSError:
                continue
            rows.append({"path": str(f), "mtime": st.st_mtime, "size": st.st_size})
        rows.sort(key=lambda r: r["mtime"], reverse=True)
        now = time.time()
        for r in rows[:limit]:
            r["age_hours"] = round((now - r["mtime"]) / 3600, 1)
        return ok("file_history", files=rows[:limit], count=len(rows[:limit]))

    @registry.register(S(
        name="workspace_summary", description="Compact map of the workspace: "
                                             "counts, sizes, and top-level structure. "
                                             "Cheaper than list_files on a large repo.",
        input_schema={"type": "object", "properties": {
            "path": {"type": "string"}, "sample": {"type": "integer"}}},
        risk_level=RiskLevel.READ, timeout_seconds=60, idempotent=True, tags=["fs", "read"],
    ))
    async def workspace_summary(ctx: ToolContext, path: str = ".",
                                sample: int = 120) -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("workspace_summary", d.reason)
        root = d.path
        by_ext: dict[str, int] = {}
        total = 0
        size = 0
        top: list[dict[str, Any]] = []
        for f in _walk(root, max_files=30000):
            total += 1
            ext = f.suffix.lower() or "(none)"
            by_ext[ext] = by_ext.get(ext, 0) + 1
            try:
                size += f.stat().st_size
            except OSError:
                pass
            if len(top) < sample:
                top.append(str(f.relative_to(root)))
        by_ext_sorted = dict(sorted(by_ext.items(), key=lambda kv: -kv[1])[:25])
        return ok("workspace_summary", root=str(root), total_files=total,
                  total_bytes=size, by_extension=by_ext_sorted,
                  sample_files=top,
                  has_git=(root / ".git").exists(),
                  manifests=[m for m in ("package.json", "pyproject.toml", "requirements.txt",
                                          "Cargo.toml", "go.mod", "pom.xml", "build.gradle",
                                          "Makefile", "Dockerfile", "docker-compose.yml")
                             if (root / m).exists()])
