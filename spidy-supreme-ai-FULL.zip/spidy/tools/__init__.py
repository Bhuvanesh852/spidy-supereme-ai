"""Tool registry assembly.

One place that decides which tools exist, so `registry.names()` is the single
source of truth for what the agent can do.
"""
from __future__ import annotations

from .base import ToolContext, ToolRegistry, ToolResult, ToolSpec
from .cag_compat import register_risk
from . import filesystem, shell, web, data, media, research as research_tools


def build_registry() -> ToolRegistry:
    registry = ToolRegistry()
    filesystem.build(registry)
    shell.build(registry)
    shell.build_git(registry)
    web.build(registry)
    data.build(registry)
    media.build(registry)
    research_tools.build(registry)

    # Let CAG know which tools are safe to serve from cache.
    for t in registry.specs():
        register_risk(t.name, t.risk_level)
    return registry


_REGISTRY: ToolRegistry | None = None


def get_registry() -> ToolRegistry:
    global _REGISTRY
    if _REGISTRY is None:
        _REGISTRY = build_registry()
    return _REGISTRY


def reset_registry() -> None:
    global _REGISTRY
    _REGISTRY = None
