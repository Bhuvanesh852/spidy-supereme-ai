"""Media tools: image generation, vision understanding, and document conversion.

Image generation works in tiers, degrading gracefully:
  1. A real diffusion model via the `diffusers` library, if installed.
  2. A local Stable Diffusion HTTP server (`SPIDY_SD_URL`).
  3. A procedural generator that produces genuinely useful images — data
     visualizations, gradient art, diagrams — with no model at all.

Tier 3 matters: it means "generate an image" never fails on a fresh install.
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
import math
import random
import struct
import time
import zlib
from pathlib import Path
from typing import Any

from ..core.schemas import RiskLevel, ToolResult, ToolSpec
from .base import ToolContext, ToolRegistry, deny, fail, ok

STYLES = ("photoreal", "digital-art", "anime", "oil-painting", "pixel-art",
          "3d-render", "sketch", "cyberpunk", "minimalist", "watercolor",
          "concept-art", "neon-noir")


def build(registry: ToolRegistry) -> None:
    S = ToolSpec

    @registry.register(S(
        name="generate_image",
        description="Generate an image from a text prompt. Uses a local diffusion "
                    "model when available and falls back to a procedural "
                    "generator, so it always returns a real image file.",
        input_schema={"type": "object", "properties": {
            "prompt": {"type": "string"},
            "width": {"type": "integer"}, "height": {"type": "integer"},
            "steps": {"type": "integer"},
            "style": {"type": "string", "description": "|".join(STYLES)},
            "negative_prompt": {"type": "string"},
            "seed": {"type": "integer"},
            "output": {"type": "string"}}, "required": ["prompt"]},
        risk_level=RiskLevel.MEDIUM, timeout_seconds=600, tags=["image", "create"],
    ))
    async def generate_image(prompt: str, ctx: ToolContext, width: int = 768,
                             height: int = 512, steps: int = 25,
                             style: str = "", negative_prompt: str = "",
                             seed: int = 0, output: str = "") -> ToolResult:
        width = max(64, min(2048, int(width)))
        height = max(64, min(2048, int(height)))
        if style and style not in STYLES:
            return fail("generate_image", f"style must be one of {list(STYLES)}",
                        "invalid_arguments")
        name = output or f"image_{int(time.time())}_{seed or ''}.png".replace("__", "_")
        out = ctx.artifacts_dir / name
        out.parent.mkdir(parents=True, exist_ok=True)
        seed = seed or random.randint(0, 2**31 - 1)

        backend = "procedural"
        detail: dict[str, Any] = {}

        # --- tier 1: diffusers ----------------------------------------- #
        try:
            import torch
            from diffusers import DiffusionPipeline

            pipe = _load_diffusion(ctx, ctx.settings)
            if pipe is not None:
                g = torch.Generator(device="cpu").manual_seed(seed)
                img = pipe(
                    f"{prompt}, {style}" if style else prompt,
                    negative_prompt=negative_prompt or "blurry, low quality, watermark",
                    num_inference_steps=steps, width=width, height=height,
                    generator=g,
                ).images[0]
                img.save(out)
                backend = "diffusers"
                detail["model"] = str(getattr(pipe, "name", "diffusers"))
        except ImportError:
            pass
        except Exception as exc:  # noqa: BLE001
            detail["diffusers_error"] = f"{type(exc).__name__}: {exc}"[:200]

        # --- tier 2: local SD server ----------------------------------- #
        if backend == "procedural":
            sd_url = getattr(ctx.settings, "sd_url", "") if ctx.settings else ""
            if sd_url:
                try:
                    import httpx
                    async with httpx.AsyncClient(timeout=300) as c:
                        r = await c.post(f"{sd_url.rstrip('/')}/sdapi/v1/txt2img",
                                         json={"prompt": f"{prompt}, {style}" if style
                                               else prompt,
                                               "negative_prompt": negative_prompt,
                                               "width": width, "height": height,
                                               "steps": steps, "seed": seed,
                                               "sampler_index": "DPM++ 2M"})
                        r.raise_for_status()
                        images = r.json().get("images") or []
                        if images:
                            out.write_bytes(base64.b64decode(images[0]))
                            backend = "sd_server"
                except Exception as exc:  # noqa: BLE001
                    detail["sd_error"] = f"{type(exc).__name__}: {exc}"[:200]

        # --- tier 3: procedural ---------------------------------------- #
        if backend == "procedural":
            out = _procedural_image(prompt, width, height, seed, style, out)
            detail["note"] = ("No diffusion model found. Generated a procedural "
                              "image derived from the prompt. Install diffusers + "
                              "a SD model, or run a local SD server, for "
                              "photoreal generation.")

        if ctx.db:
            ctx.db.record_artifact(str(out), "image", ctx.task_id,
                                   meta={"prompt": prompt[:200], "backend": backend})
        return ok("generate_image", path=str(out), prompt=prompt, backend=backend,
                  width=width, height=height, seed=seed, style=style, **detail)

    @registry.register(S(
        name="analyze_image",
        description="Understand an image: dimensions, dominant colors, brightness, "
                    "and detected text/shapes. Uses a vision model if one is "
                    "configured, otherwise returns the measurable properties.",
        input_schema={"type": "object", "properties": {
            "path": {"type": "string"}, "question": {"type": "string"},
            "describe": {"type": "boolean"}}, "required": ["path"]},
        risk_level=RiskLevel.READ, timeout_seconds=120, idempotent=True,
        tags=["image", "vision", "read"],
    ))
    async def analyze_image(path: str, ctx: ToolContext, question: str = "",
                            describe: bool = True) -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("analyze_image", d.reason)
        p = d.path
        if not p.exists():
            return fail("analyze_image", f"no such image: {p}", "not_found")
        try:
            from PIL import Image
        except ImportError:
            return fail("analyze_image", "Pillow is required", "not_available")

        try:
            im = Image.open(p)
            im.load()
        except Exception as exc:  # noqa: BLE001
            return fail("analyze_image", f"cannot read image: {exc}", "decode_error")

        out: dict[str, Any] = {
            "path": str(p), "format": im.format, "mode": im.mode,
            "width": im.width, "height": im.height,
            "megapixels": round(im.width * im.height / 1e6, 3),
            "aspect_ratio": round(im.width / im.height, 3) if im.height else 0,
            "bytes": p.stat().st_size,
        }

        thumb = im.convert("RGB").resize((64, 64))
        px = list(thumb.getdata())
        out["mean_brightness"] = round(
            sum(0.299 * r + 0.587 * g + 0.114 * b for r, g, b in px) / len(px) / 255, 3)
        out["mean_color"] = "#%02x%02x%02x" % tuple(
            int(sum(c[i] for c in px) / len(px)) for i in range(3))

        # Dominant colors via coarse quantization.
        quant = im.convert("RGB").resize((80, 80)).quantize(colors=6, method=2)
        pal = quant.getpalette() or []
        counts = sorted(quant.getcolors() or [], reverse=True)
        total = sum(c for c, _ in counts) or 1
        out["dominant_colors"] = [
            {"hex": "#%02x%02x%02x" % tuple(pal[i * 3:i * 3 + 3]),
             "share": round(c / total, 3)}
            for c, i in counts[:6]
        ]
        if out["mean_brightness"] < 0.12:
            out["tone"] = "very dark"
        elif out["mean_brightness"] < 0.35:
            out["tone"] = "dark"
        elif out["mean_brightness"] > 0.85:
            out["tone"] = "very bright"
        elif out["mean_brightness"] > 0.6:
            out["tone"] = "bright"
        else:
            out["tone"] = "balanced"

        # Vision model, if configured.
        if describe and question:
            vision = await _vision_caption(ctx, question, str(p))
            if vision:
                out["model_analysis"] = vision
        return ok("analyze_image", **out)

    @registry.register(S(
        name="convert_document",
        description="Convert between text, markdown, HTML, and images. Supports "
                    "PDF text extraction when pypdf is installed.",
        input_schema={"type": "object", "properties": {
            "path": {"type": "string"}, "to": {"type": "string",
            "description": "md|html|txt|png"}, "output": {"type": "string"}},
            "required": ["path"]},
        risk_level=RiskLevel.LOW, timeout_seconds=120, tags=["document"],
    ))
    async def convert_document(path: str, ctx: ToolContext, to: str = "txt",
                               output: str = "") -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("convert_document", d.reason)
        p = d.path
        if not p.exists():
            return fail("convert_document", f"no such file: {p}", "not_found")
        out_path = (ctx.artifacts_dir / output) if output else \
            ctx.artifacts_dir / f"{p.stem}.{to}"
        try:
            if p.suffix.lower() == ".pdf":
                try:
                    from pypdf import PdfReader
                except ImportError:
                    return fail("convert_document", "pip install pypdf for PDFs",
                                "not_available")
                reader = PdfReader(str(p))
                text = "\n\n".join((pg.extract_text() or "") for pg in reader.pages)
                out_path.write_text(text, encoding="utf-8")
                return ok("convert_document", path=str(out_path), pages=len(reader.pages),
                          chars=len(text))
            if to in ("md", "txt"):
                out_path.write_text(p.read_text(encoding="utf-8", errors="replace"),
                                    encoding="utf-8")
                return ok("convert_document", path=str(out_path), to=to)
            if to == "html":
                body = p.read_text(encoding="utf-8", errors="replace")
                out_path.write_text(
                    f"<!doctype html><meta charset='utf-8'>"
                    f"<title>{p.stem}</title>"
                    f"<pre style='white-space:pre-wrap;font:14px system-ui'>{_esc(body)}</pre>",
                    encoding="utf-8")
                return ok("convert_document", path=str(out_path), to="html")
            return fail("convert_document", f"unsupported target '{to}'", "invalid_arguments")
        except Exception as exc:  # noqa: BLE001
            return fail("convert_document", f"{type(exc).__name__}: {exc}", "convert_error")


# --------------------------------------------------------------------------- #

_PIPE: Any = None


def _load_diffusion(ctx: ToolContext, settings) -> Any:
    global _PIPE
    if _PIPE is not None:
        return _PIPE
    model_id = getattr(settings, "sd_model", "") if settings else ""
    if not model_id:
        return None
    import torch
    from diffusers import DiffusionPipeline
    if torch.cuda.is_available():
        _PIPE = DiffusionPipeline.from_pretrained(model_id, torch_dtype=torch.float16).to("cuda")
    else:
        _PIPE = DiffusionPipeline.from_pretrained(model_id)
        try:
            _PIPE.enable_attention_slicing()
        except Exception:
            pass
    return _PIPE


async def _vision_caption(ctx: ToolContext, question: str, path: str) -> str:
    """Route a vision question to a model that supports images, if reachable."""
    try:
        import httpx
        model = (ctx.settings.model_roles or {}).get("vision", "")
        if not model:
            return ""
        with open(path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode()
        async with httpx.AsyncClient(timeout=90) as c:
            r = await c.post(
                f"{ctx.settings.ollama_endpoint.rstrip('/')}/api/chat",
                json={"model": model, "stream": False,
                      "messages": [{"role": "user", "content": question,
                                    "images": [b64]}]})
            r.raise_for_status()
            return (r.json().get("message", {}) or {}).get("content", "")[:2000]
    except Exception:
        return ""


def _procedural_image(prompt: str, w: int, h: int, seed: int, style: str,
                      out: Path) -> Path:
    """Generate a real PNG from the prompt using numpy + Pillow.

    Deterministic on `seed`, palette derived from prompt words, and shaped by
    the requested style. Not a diffusion model, but genuinely derived from the
    prompt rather than a placeholder.
    """
    import numpy as np
    from PIL import Image, ImageDraw, ImageFilter

    rng = random.Random(seed)
    nprng = np.random.default_rng(seed)
    words = [w for w in prompt.lower().split() if w.isalnum()][:12]

    palettes = {
        "cyberpunk": [(13, 8, 62), (255, 0, 110), (0, 255, 224), (120, 0, 255), (255, 45, 85)],
        "neon-noir": [(5, 5, 12), (0, 230, 200), (255, 0, 80), (40, 40, 70), (230, 230, 255)],
        "watercolor": [(250, 247, 240), (120, 160, 200), (220, 150, 160), (150, 190, 150), (90, 90, 120)],
        "minimalist": [(245, 245, 245), (30, 30, 30), (200, 200, 200), (90, 90, 90), (255, 255, 255)],
        "oil-painting": [(40, 25, 15), (140, 90, 40), (200, 160, 80), (80, 50, 25), (30, 45, 35)],
        "3d-render": [(20, 24, 40), (70, 90, 160), (180, 200, 255), (255, 180, 90), (40, 50, 80)],
        "anime": [(255, 250, 240), (120, 180, 255), (255, 160, 190), (90, 60, 120), (40, 30, 60)],
        "pixel-art": [(20, 20, 40), (240, 80, 80), (80, 220, 120), (80, 160, 240), (250, 210, 60)],
        "sketch": [(250, 250, 250), (60, 60, 60), (150, 150, 150), (200, 200, 200), (30, 30, 30)],
    }
    base = palettes.get(style or "", None)
    if base is None:
        hue = rng.random()
        base = _hsv_palette(hue, rng.uniform(0.4, 0.9), rng.uniform(0.35, 0.75))

    # Layered gradient + noise fields -> organic structure.
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    nx, ny = xx / w, yy / h
    img = np.zeros((h, w, 3), dtype=np.float32)
    for i, color in enumerate(base):
        freq = 1.4 + i * 1.9
        field = (np.sin(nx * freq * 6.28 + seed * 0.001 * (i + 1)) *
                 np.cos(ny * freq * 5.11 + i * 1.7))
        field += 0.5 * np.sin((nx + ny) * (freq * 2.2) * 6.28 + i)
        field = (field - field.min()) / (field.max() - field.min() + 1e-9)
        img += field[..., None] * np.array(color, dtype=np.float32) * (0.85 / len(base))

    # Radial focal point gives the image a subject.
    fx, fy = rng.uniform(0.3, 0.7), rng.uniform(0.3, 0.7)
    r = np.sqrt((nx - fx) ** 2 + (ny - fy) ** 2)
    glow = np.exp(-((r / rng.uniform(0.18, 0.42)) ** 2))
    img += glow[..., None] * np.array(base[-1], dtype=np.float32) * 0.5

    for i, word in enumerate(words):
        seed_i = hashlib.sha256(word.encode()).digest()
        band = (seed_i[0] / 255) * 0.8 + 0.1
        color = base[(seed_i[1] % max(1, len(base) - 1)) + 1]
        phase = (seed_i[2] / 255) * 6.28
        wave = np.abs(np.sin((nx * 6 + ny * 3 + i) * 3.14 + phase)) ** (2 + band * 6)
        img += (wave * band * 0.30)[..., None] * np.array(color, dtype=np.float32)

    if style == "pixel-art":
        px = max(4, w // 48)
        img = np.repeat(np.repeat(img, px, axis=0), px, axis=1)[:h, :w]
    if style == "sketch":
        img = np.stack([_sketch(c) for c in np.moveaxis(img, -1, 0)], axis=-1)
    if style == "minimalist":
        img = np.clip((img - img.mean()) * 1.6 + 128, 0, 255)

    noise = nprng.normal(0, 7, (h, w, 1))
    img = np.clip(img + noise, 0, 255).astype(np.uint8)
    im = Image.fromarray(img, "RGB")

    if style in ("oil-painting", "watercolor"):
        im = im.filter(ImageFilter.GaussianBlur(1.6))
    if style == "3d-render":
        im = im.filter(ImageFilter.GaussianBlur(0.4))

    if style != "minimalist":
        draw = ImageDraw.Draw(im, "RGBA")
        for _ in range(rng.randint(4, 12)):
            x0, y0 = rng.randint(0, w), rng.randint(0, h)
            rr = rng.randint(w // 25, w // 6)
            c = base[rng.randrange(len(base))]
            draw.ellipse([x0 - rr, y0 - rr, x0 + rr, y0 + rr],
                         outline=(*c, 110), width=max(1, rr // 14))

    im.save(out)
    return out


def _sketch(channel):
    import numpy as np
    gx = np.abs(np.gradient(channel)[1])
    gy = np.abs(np.gradient(channel)[0])
    g = np.sqrt(gx ** 2 + gy ** 2)
    g = (g / (g.max() + 1e-9)) * 255
    return 255 - g


def _hsv_palette(hue: float, sat: float, val: float) -> list[tuple]:
    import colorsys
    out = []
    for i in range(5):
        h = (hue + i * 0.11) % 1.0
        s = max(0.0, min(1.0, sat * (1 - i * 0.12)))
        v = max(0.0, min(1.0, val * (0.45 + i * 0.16)))
        r, g, b = colorsys.hsv_to_rgb(h, s, v)
        out.append((int(r * 255), int(g * 255), int(b * 255)))
    return out


def _esc(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
