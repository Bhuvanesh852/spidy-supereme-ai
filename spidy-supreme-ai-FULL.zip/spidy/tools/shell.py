"""Shell, process, and git tools.

Commands are parsed, policy-checked, run with a scrubbed environment under
resource limits, and normalized into the standard ToolResult envelope.
"""
from __future__ import annotations

import asyncio
import os
import shlex
import signal
import subprocess
from typing import Any

from ..core.schemas import RiskLevel, ToolResult, ToolSpec, ToolStatus
from ..sandbox import Limits, get_sandbox, sandbox_kind
from ..security.policy import CommandPolicy
from ..security.redaction import scrub_env
from .base import ToolContext, ToolRegistry, deny, fail, ok

# POSIX resource caps. Absence of the `resource` module (Windows) is tolerated.
try:  # pragma: no cover - platform dependent
    import resource
    _HAS_RESOURCE = True
except ImportError:  # pragma: no cover
    resource = None  # type: ignore[assignment]
    _HAS_RESOURCE = False

_RUNNING: dict[str, subprocess.Popen] = {}
_SANDBOX_CACHE: dict[str, Any] = {}


def _sandbox(ctx: ToolContext):
    """The one executor call site. Everything shell-related routes through it.

    Cached per workspace root because the sandbox carries confinement state, and
    re-deriving it per command would be pure overhead.
    """
    root = str(getattr(ctx, "workspace_root", "") or "")
    if root not in _SANDBOX_CACHE:
        _SANDBOX_CACHE[root] = get_sandbox(root or None)
    return _SANDBOX_CACHE[root]


def current_sandbox_kind() -> str:
    """Which sandbox is configured. The API reads this to fail closed."""
    return sandbox_kind()


def _limits(cpu_seconds: int, mem_mb: int, nproc: int = 64, fsize_mb: int = 512):
    if not _HAS_RESOURCE:
        return None

    def _set() -> None:  # pragma: no cover - runs in child
        os.setsid()
        resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds))
        resource.setrlimit(resource.RLIMIT_AS, (mem_mb * 1024 * 1024,) * 2)
        resource.setrlimit(resource.RLIMIT_NPROC, (nproc, nproc))
        resource.setrlimit(resource.RLIMIT_FSIZE, (fsize_mb * 1024 * 1024,) * 2)
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

    return _set


def _truncate(data: bytes, max_bytes: int) -> tuple[str, bool]:
    if len(data) <= max_bytes:
        return data.decode("utf-8", errors="replace"), False
    head = int(max_bytes * 0.7)
    return (
        data[:head].decode("utf-8", errors="replace")
        + f"\n...[{len(data) - max_bytes} bytes elided]...\n"
        + data[-(max_bytes - head):].decode("utf-8", errors="replace"),
        True,
    )


def build(registry: ToolRegistry) -> None:
    S = ToolSpec

    # ---- run_command --------------------------------------------------- #
    @registry.register(S(
        name="run_command",
        description="Run a shell command in the workspace. Policy-checked, "
                    "sandboxed, with a scrubbed environment and time limit. "
                    "Captures stdout, stderr and exit code.",
        input_schema={
            "type": "object",
            "properties": {
                "command": {"type": "string"},
                "cwd": {"type": "string", "description": "Working dir, relative to workspace root"},
                "timeout": {"type": "integer", "description": "Seconds, default 120"},
                "background": {"type": "boolean", "description": "Start and return immediately"},
            },
            "required": ["command"],
        },
        risk_level=RiskLevel.MEDIUM, timeout_seconds=300, tags=["shell"],
    ))
    async def run_command(command: str, ctx: ToolContext, cwd: str = "",
                         timeout: int = 0, background: bool = False) -> ToolResult:
        if ctx.command_policy is None:
            ctx.command_policy = CommandPolicy(ctx.permission_mode)
        decision = ctx.command_policy.evaluate(command)
        if not decision.allowed:
            return deny("run_command", decision.reason)
        if decision.needs_approval and not ctx.extra.get("approval_granted"):
            return ToolResult(
                tool="run_command", status=ToolStatus.NEEDS_APPROVAL,
                error_type="approval_required",
                message=f"command needs approval ({decision.reason}): {command}",
                data={"command": command, "risk": decision.risk.value},
                metadata={"matched": decision.matched},
            )

        wd = ctx.workspace_root
        if cwd:
            d = ctx.policy.check(cwd, "read")
            if not d.allowed:
                return deny("run_command", d.reason)
            wd = d.path

        timeout = timeout or ctx.settings.command_timeout if ctx.settings else (timeout or 120)
        max_bytes = ctx.settings.max_output_bytes if ctx.settings else 200_000

        env = scrub_env(dict(os.environ))
        env.update({
            "PYTHONUNBUFFERED": "1", "PYTHONDONTWRITEBYTECODE": "1",
            "NO_COLOR": "1", "TERM": "dumb", "CI": "1", "GIT_TERMINAL_PROMPT": "0",
        })

        try:
            if background:
                proc = subprocess.Popen(
                    command, shell=True, cwd=str(wd), env=env,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    start_new_session=True,
                )
                _RUNNING[proc.pid] = proc
                return ok("run_command", command=command, pid=proc.pid,
                          background=True, cwd=str(wd),
                          hint=f"read output with read_process_output(pid={proc.pid})")

            result = await _sandbox(ctx).run(
                command, wd,
                limits=Limits(
                    wall_timeout=timeout,
                    memory_bytes=2048 * 1024 * 1024,
                    cpu_seconds=max(5, timeout),
                    max_output_bytes=max_bytes,
                ),
                env=env,
            )
            proc = result  # ExecResult exposes returncode directly

            stdout, cut1 = _truncate(result.stdout.encode("utf-8"), max_bytes)
            stderr, cut2 = _truncate(result.stderr.encode("utf-8"), max_bytes)
            duration = result.duration_ms

            if result.timed_out:
                return ToolResult(
                    tool="run_command", status=ToolStatus.TIMEOUT,
                    exit_code=result.returncode, stdout=stdout, stderr=stderr,
                    error_type="timeout", message=f"command exceeded {timeout}s",
                    retryable=True, duration_ms=duration, truncated=cut1 or cut2,
                    data={"command": command, "cwd": str(wd)},
                )
            return ToolResult(
                tool="run_command",
                status=ToolStatus.SUCCESS if result.returncode == 0 else ToolStatus.ERROR,
                exit_code=result.returncode, stdout=stdout, stderr=stderr,
                error_type=None if result.returncode == 0 else "nonzero_exit",
                message="" if result.returncode == 0 else f"exit code {result.returncode}",
                retryable=False, duration_ms=duration, truncated=cut1 or cut2,
                data={"command": command, "cwd": str(wd), "risk": decision.risk.value,
                      "sandbox": result.sandbox},
            )
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            return fail("run_command", f"{type(exc).__name__}: {exc}", "spawn_failed")

    @registry.register(S(
        name="run_python",
        description="Execute Python code in a subprocess and return its output. "
                    "Use for data analysis, scripting, and ML work.",
        input_schema={"type": "object", "properties": {
            "code": {"type": "string"},
            "timeout": {"type": "integer"}}, "required": ["code"]},
        risk_level=RiskLevel.MEDIUM, timeout_seconds=300, tags=["code", "python"],
    ))
    async def run_python(code: str, ctx: ToolContext, timeout: int = 120) -> ToolResult:
        if len(code) > 200_000:
            return fail("run_python", "code exceeds 200KB", "too_large")
        script = (
            "import sys, json, traceback\n"
            "def __main():\n"
            + "\n".join("    " + ln for ln in code.splitlines())
            + "\n__main()\n"
        )
        cmd = f"{shlex.quote(sys_executable())} -c {shlex.quote(script)}"
        return await run_command(cmd, ctx, timeout=timeout)

    @registry.register(S(
        name="run_node", description="Execute JavaScript/TypeScript with node.",
        input_schema={"type": "object", "properties": {
            "code": {"type": "string"}, "timeout": {"type": "integer"}}, "required": ["code"]},
        risk_level=RiskLevel.MEDIUM, timeout_seconds=180, tags=["code", "javascript"],
    ))
    async def run_node(code: str, ctx: ToolContext, timeout: int = 120) -> ToolResult:
        if not _which("node"):
            return fail("run_node", "node is not installed on this system", "not_available")
        return await run_command(
            f"node -e {shlex.quote(code)}", ctx, timeout=timeout)

    # ---- process management -------------------------------------------- #
    @registry.register(S(
        name="start_process", description="Start a long-running process in the background.",
        input_schema={"type": "object", "properties": {
            "command": {"type": "string"}, "cwd": {"type": "string"}},
            "required": ["command"]},
        risk_level=RiskLevel.MEDIUM, timeout_seconds=30, tags=["shell", "process"],
    ))
    async def start_process(command: str, ctx: ToolContext, cwd: str = "") -> ToolResult:
        return await run_command(command, ctx, cwd=cwd, background=True)

    @registry.register(S(
        name="read_process_output",
        description="Check a background process started with start_process.",
        input_schema={"type": "object", "properties": {
            "pid": {"type": "integer"}, "timeout": {"type": "integer"}},
            "required": ["pid"]},
        risk_level=RiskLevel.READ, timeout_seconds=30, idempotent=True,
        tags=["shell", "process"],
    ))
    async def read_process_output(pid: int, ctx: ToolContext, timeout: int = 5) -> ToolResult:
        proc = _RUNNING.get(pid)
        if proc is None:
            return fail("read_process_output", f"no tracked process {pid}", "not_found")
        if proc.poll() is None:
            try:
                out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            except asyncio.TimeoutError:
                return ok("read_process_output", pid=pid, status="running",
                          hint="process still running — call again later")
        else:
            out, err = proc.communicate()
            _RUNNING.pop(pid, None)
        so, c1 = _truncate(out or b"", 50_000)
        se, c2 = _truncate(err or b"", 50_000)
        return ok("read_process_output", pid=pid, status="exited", exit_code=proc.returncode,
                  stdout=so, stderr=se, truncated=c1 or c2)

    @registry.register(S(
        name="stop_process", description="Terminate a tracked background process.",
        input_schema={"type": "object", "properties": {
            "pid": {"type": "integer"}, "force": {"type": "boolean"}},
            "required": ["pid"]},
        risk_level=RiskLevel.HIGH, timeout_seconds=15, tags=["shell", "process"],
    ))
    async def stop_process(pid: int, ctx: ToolContext, force: bool = False) -> ToolResult:
        proc = _RUNNING.get(pid)
        if proc is None:
            return fail("stop_process", f"no tracked process {pid}", "not_found")
        if proc.poll() is not None:
            _RUNNING.pop(pid, None)
            return ok("stop_process", pid=pid, action="already_exited")
        try:
            os.killpg(os.getpgid(pid), signal.SIGKILL if force else signal.SIGTERM)
        except (ProcessLookupError, PermissionError, OSError):
            proc.kill()
        _RUNNING.pop(pid, None)
        return ok("stop_process", pid=pid, action="terminated", forced=force)

    # ---- tests & builds -------------------------------------------------- #
    @registry.register(S(
        name="run_tests", description="Detect and run the project's test suite. "
                                      "Returns a structured pass/fail summary.",
        input_schema={"type": "object", "properties": {
            "path": {"type": "string"}, "extra_args": {"type": "string"},
            "timeout": {"type": "integer"}}},
        risk_level=RiskLevel.MEDIUM, timeout_seconds=300, tags=["code", "test"],
    ))
    async def run_tests(ctx: ToolContext, path: str = ".", extra_args: str = "",
                        timeout: int = 240) -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("run_tests", d.reason)
        root = d.path
        runners: list[tuple[str, list[str]]] = []
        if (root / "pyproject.toml").exists() or (root / "pytest.ini").exists() \
                or (root / "tests").is_dir() or (root / "test").is_dir():
            runners.append(("pytest", ["python", "-m", "pytest", "-q", "--no-header"]))
        if (root / "package.json").exists():
            runners.append(("npm", ["npm", "test", "--silent"]))
        if not runners:
            return ok("run_tests", status="no_test_suite",
                      message="no recognized test runner in this project")
        name, cmd = runners[0]
        full = " ".join(shlex.quote(c) for c in cmd) + (f" {extra_args}" if extra_args else "")
        res = await run_command(full, ctx, cwd=path, timeout=timeout)
        summary = _parse_test_output(res.stdout + "\n" + res.stderr)
        return ToolResult(
            tool="run_tests", status=res.status, exit_code=res.exit_code,
            stdout=res.stdout, stderr=res.stderr, duration_ms=res.duration_ms,
            error_type=res.error_type, message=res.message, retryable=res.retryable,
            data={"runner": name, **summary}, truncated=res.truncated,
        )

    @registry.register(S(
        name="run_lint", description="Run the project's linter / type checker if present.",
        input_schema={"type": "object", "properties": {
            "path": {"type": "string"}, "tool": {"type": "string",
            "description": "auto|ruff|flake8|mypy|eslint|tsc"}}},
        risk_level=RiskLevel.LOW, timeout_seconds=180, idempotent=True,
        tags=["code", "quality"],
    ))
    async def run_lint(ctx: ToolContext, path: str = ".", tool: str = "auto") -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("run_lint", d.reason)
        root = d.path
        candidates: list[tuple[str, list[str]]] = []
        if (root / "pyproject.toml").exists() or (root / "setup.py").exists() \
                or (root / "requirements.txt").exists():
            if _which("ruff"):
                candidates.append(("ruff", ["ruff", "check", "."]))
            if _which("flake8"):
                candidates.append(("flake8", ["flake8", "."]))
            if _which("mypy"):
                candidates.append(("mypy", ["mypy", ".", "--ignore-missing-imports"]))
        if (root / "package.json").exists():
            if (root / "tsconfig.json").exists() and _which("tsc"):
                candidates.append(("tsc", ["tsc", "--noEmit"]))
            if (root / ".eslintrc").exists() or (root / "eslint.config.js").exists():
                candidates.append(("eslint", ["npx", "eslint", ".", "--quiet"]))
        if not candidates:
            return ok("run_lint", status="no_linter",
                      message="no linter configured or installed")
        picked = next((c for c in candidates if tool == "auto" or c[0] == tool), candidates[0])
        res = await run_command(" ".join(shlex.quote(c) for c in picked[1]), ctx, cwd=path)
        issues = _parse_lint_output(res.stdout + "\n" + res.stderr)
        return ToolResult(
            tool="run_lint", status=res.status, stdout=res.stdout, stderr=res.stderr,
            exit_code=res.exit_code, duration_ms=res.duration_ms, data={
                "linter": picked[0], **issues},
        )

    @registry.register(S(
        name="run_build", description="Run the project's build command if one is configured.",
        input_schema={"type": "object", "properties": {
            "path": {"type": "string"}, "timeout": {"type": "integer"}}},
        risk_level=RiskLevel.MEDIUM, timeout_seconds=420, tags=["code", "build"],
    ))
    async def run_build(ctx: ToolContext, path: str = ".", timeout: int = 300) -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("run_build", d.reason)
        root = d.path
        if (root / "package.json").exists():
            return await run_command("npm run build", ctx, cwd=path, timeout=timeout)
        if (root / "pyproject.toml").exists():
            return await run_command(
                f"{shlex.quote(sys_executable())} -m build", ctx, cwd=path, timeout=timeout)
        if (root / "Cargo.toml").exists():
            return await run_command("cargo build --release", ctx, cwd=path, timeout=timeout)
        if (root / "Makefile").exists():
            return await run_command("make", ctx, cwd=path, timeout=timeout)
        return ok("run_build", status="no_build", message="no recognized build system")


# --------------------------------------------------------------------------- #
# git
# --------------------------------------------------------------------------- #


def build_git(registry: ToolRegistry) -> None:
    S = ToolSpec

    def _git(ctx: ToolContext, args: str, timeout: int = 60) -> ToolResult:
        r = asyncio.run(_run_git(ctx, args, timeout))
        return r

    @registry.register(S(
        name="git_status", description="Show working tree status, current branch, and recent commits.",
        input_schema={"type": "object", "properties": {"path": {"type": "string"}}},
        risk_level=RiskLevel.READ, timeout_seconds=30, idempotent=True, tags=["git"],
    ))
    async def git_status(ctx: ToolContext, path: str = ".") -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("git_status", d.reason)
        if not (d.path / ".git").exists():
            return ok("git_status", is_repo=False, message="not a git repository")
        res = await _run_git(ctx, "status --porcelain=v1 -b", cwd=path)
        branch, files, untracked = "", [], 0
        for line in (res.stdout or "").splitlines():
            if line.startswith("##"):
                branch = line[2:].split("...")[0].strip()
            elif line.strip():
                files.append(line)
                if line.startswith("??"):
                    untracked += 1
        modified = [f for f in files if not f.startswith("??")]
        return ok("git_status", is_repo=True, branch=branch, clean=not files,
                  modified=len(modified), untracked=untracked,
                  changes=files[:60], porcelain=res.stdout[:4000])

    @registry.register(S(
        name="git_diff", description="Show the diff of staged, unstaged, or HEAD changes.",
        input_schema={"type": "object", "properties": {
            "path": {"type": "string"}, "staged": {"type": "boolean"},
            "ref": {"type": "string"}, "max_lines": {"type": "integer"}},
            "required": []},
        risk_level=RiskLevel.READ, timeout_seconds=45, idempotent=True, tags=["git"],
    ))
    async def git_diff(ctx: ToolContext, path: str = ".", staged: bool = False,
                       ref: str = "", max_lines: int = 400) -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("git_diff", d.reason)
        if not (d.path / ".git").exists():
            return ok("git_diff", is_repo=False)
        args = "diff --no-color"
        if staged:
            args += " --staged"
        if ref:
            args += f" {shlex.quote(ref)}"
        res = await _run_git(ctx, args, cwd=path)
        text = res.stdout or ""
        lines = text.splitlines()
        stat = await _run_git(ctx, ("diff --stat --no-color" + (" --staged" if staged else "") +
                                    (f" {shlex.quote(ref)}" if ref else "")), cwd=path)
        files_changed = [ln.split("|")[0].strip() for ln in (stat.stdout or "").splitlines()
                         if "|" in ln]
        return ok("git_diff", is_repo=True, diff="\n".join(lines[:max_lines]),
                  stat=(stat.stdout or "")[:3000], files_changed=files_changed[:40],
                  truncated=len(lines) > max_lines)

    @registry.register(S(
        name="git_log", description="Recent commit history with one-line summaries.",
        input_schema={"type": "object", "properties": {
            "path": {"type": "string"}, "count": {"type": "integer"}, "ref": {"type": "string"}}},
        risk_level=RiskLevel.READ, timeout_seconds=30, idempotent=True, tags=["git"],
    ))
    async def git_log(ctx: ToolContext, path: str = ".", count: int = 20,
                      ref: str = "HEAD") -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("git_log", d.reason)
        if not (d.path / ".git").exists():
            return ok("git_log", is_repo=False)
        res = await _run_git(
            ctx, f"log --no-color --pretty=format:%h|%an|%ad|%s --date=short -n {int(count)} "
                 f"{shlex.quote(ref)}", cwd=path)
        commits = []
        for ln in (res.stdout or "").splitlines():
            parts = ln.split("|", 3)
            if len(parts) == 4:
                commits.append({"hash": parts[0], "author": parts[1],
                                "date": parts[2], "subject": parts[3]})
        return ok("git_log", is_repo=True, commits=commits, count=len(commits))

    @registry.register(S(
        name="git_add", description="Stage files for commit.",
        input_schema={"type": "object", "properties": {
            "path": {"type": "string"}, "files": {"type": "array", "items": {"type": "string"}}},
            "required": ["files"]},
        risk_level=RiskLevel.MEDIUM, timeout_seconds=30, tags=["git", "write"],
    ))
    async def git_add(ctx: ToolContext, files: list[str], path: str = ".") -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("git_add", d.reason)
        for f in files:
            fd = ctx.policy.check(f, "write")
            if not fd.allowed:
                return deny("git_add", fd.reason)
        args = "add -- " + " ".join(shlex.quote(f) for f in files[:200])
        res = await _run_git(ctx, args, cwd=path)
        if res.exit_code != 0:
            return fail("git_add", res.stderr or "git add failed", "git_error")
        return ok("git_add", staged=files, count=len(files))

    @registry.register(S(
        name="git_commit", description="Create a commit. Requires user approval in "
                                       "SAFE and BALANCED modes.",
        input_schema={"type": "object", "properties": {
            "message": {"type": "string"}, "path": {"type": "string"},
            "approve": {"type": "boolean"}}, "required": ["message"]},
        risk_level=RiskLevel.HIGH, timeout_seconds=60, tags=["git", "write"],
    ))
    async def git_commit(ctx: ToolContext, message: str, path: str = ".",
                         approve: bool = False) -> ToolResult:
        if not approve and (ctx.permission_mode or "").upper() in ("SAFE", "BALANCED"):
            return ToolResult(
                tool="git_commit", status=ToolStatus.NEEDS_APPROVAL,
                error_type="approval_required",
                message="committing requires approval — re-run with approve=true",
                data={"message": message})
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("git_commit", d.reason)
        res = await _run_git(ctx, f"commit -m {shlex.quote(message)}", cwd=path)
        if res.exit_code != 0:
            return fail("git_commit", res.stderr or "commit failed", "git_error")
        sha = (res.stdout or "").strip().split("\n")[-1] if res.stdout else ""
        return ok("git_commit", message=message, output=(res.stdout or "")[:500], sha=sha)


async def _run_git(ctx: ToolContext, args: str, cwd: str = ".", timeout: int = 60) -> ToolResult:
    policy = ctx.command_policy or CommandPolicy(ctx.permission_mode)
    d = ctx.policy.check(cwd, "read")
    workdir = d.path if d.allowed else ctx.workspace_root
    full = f"git --no-pager {args}"
    dec = policy.evaluate(full)
    if not dec.allowed:
        return deny("git", dec.reason)
    env = scrub_env(dict(os.environ), denylist={"GIT_ASKPASS", "GIT_TOKEN"})
    env["GIT_TERMINAL_PROMPT"] = "0"
    try:
        proc = await asyncio.create_subprocess_shell(
            full, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            cwd=str(workdir), env=env)
        out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return ToolResult(
            tool="git", exit_code=proc.returncode,
            stdout=(out or b"").decode("utf-8", errors="replace"),
            stderr=(err or b"").decode("utf-8", errors="replace"),
            data={"args": args})
    except asyncio.TimeoutError:
        return ToolResult(tool="git", status=ToolStatus.TIMEOUT, error_type="timeout",
                          message=f"git {args} exceeded {timeout}s", retryable=True)
    except Exception as exc:  # noqa: BLE001
        return fail("git", str(exc), "git_error")


# --------------------------------------------------------------------------- #


def sys_executable() -> str:
    import sys
    return sys.executable or "python3"


def _which(binary: str) -> str | None:
    import shutil
    return shutil.which(binary)


def _parse_test_output(text: str) -> dict[str, Any]:
    """Extract the counts a verifier needs without shipping the full log."""
    import re
    summary: dict[str, Any] = {}
    m = re.search(r"(\d+)\s+passed", text)
    if m:
        summary["passed"] = int(m.group(1))
    m = re.search(r"(\d+)\s+failed", text)
    if m:
        summary["failed"] = int(m.group(1))
    m = re.search(r"(\d+)\s+error", text)
    if m:
        summary["errors"] = int(m.group(1))
    m = re.search(r"(\d+)\s+skipped", text)
    if m:
        summary["skipped"] = int(m.group(1))
    m = re.search(r"=+\s*(.*?)\s*=+", text, re.S)
    if m:
        summary["line"] = m.group(1).strip()[:200]
    failures: list[str] = []
    for block in re.findall(r"_{5,} (.+?) _{5,}\n(.*?)(?=\n_{5,}|\n={5,}|\Z)", text, re.S):
        name, body = block
        first = next((ln for ln in body.splitlines() if ln.strip() and "___" not in ln), "")
        failures.append(f"{name.strip()}: {first.strip()[:180]}")
    if failures:
        summary["failures"] = failures[:15]
    return summary


def _parse_lint_output(text: str) -> dict[str, Any]:
    import re
    issues = re.findall(r"^(.+?):(\d+):(\d+):\s+(.+)$", text, re.M)
    return {
        "issue_count": len(issues) or text.count("error") + text.count("warning"),
        "issues": [{"file": a, "line": int(b), "col": int(c), "message": d[:160]}
                   for a, b, c, d in issues[:40]],
    }
