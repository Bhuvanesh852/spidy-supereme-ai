"""Tool base + registry.

A tool is a pure function of (arguments, context) -> ToolResult, declared with a
strict schema. The registry owns dispatch, validation, permission checks,
timeouts, redaction, and token metering so no individual tool has to.
"""
from __future__ import annotations

import asyncio
import inspect
import time
import traceback
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

from ..core.schemas import (
    LLMResponse, RiskLevel, ToolResult, ToolSpec, ToolStatus, new_id,
)
from ..core.token_budget import TokenBudget, estimate_tokens
from ..security.guard import validate_tool_arguments
from ..security.redaction import redact_obj


@dataclass
class ToolContext:
    """Everything a tool may legitimately need. Passed explicitly so tools
    cannot reach into global state."""

    workspace_root: Any
    permission_mode: str = "BALANCED"
    task_id: str = ""
    session_id: str = ""
    budget: TokenBudget | None = None
    db: Any = None
    settings: Any = None
    policy: Any = None            # FilesystemPolicy
    command_policy: Any = None    # CommandPolicy
    network_policy: Any = None    # SSRFPolicy
    artifacts_dir: Any = None
    allow_network: bool = True
    extra: dict[str, Any] = field(default_factory=dict)


ToolFn = Callable[..., Any] | Callable[..., Awaitable[Any]]


class Tool:
    def __init__(self, spec: ToolSpec, fn: ToolFn) -> None:
        self.spec = spec
        self.fn = fn
        self._lock = asyncio.Lock()
        self.call_count = 0
        self.total_ms = 0

    @staticmethod
    def _elapsed(start: float) -> int:
        return int((time.perf_counter() - start) * 1000)

    async def __call__(self, arguments: dict[str, Any], ctx: ToolContext) -> ToolResult:
        start = time.perf_counter()
        self.call_count += 1
        try:
            # A non-idempotent tool (writes, shell, git) is serialized to stop
            # two agent steps from racing on the same resource.
            if self.spec.idempotent:
                result = await self._invoke(arguments, ctx)
            else:
                async with self._lock:
                    result = await self._invoke(arguments, ctx)
        except asyncio.TimeoutError:
            return ToolResult(
                tool=self.spec.name, status=ToolStatus.TIMEOUT,
                error_type="timeout",
                message=f"tool exceeded {self.spec.timeout_seconds}s",
                retryable=True, duration_ms=self._elapsed(start),
            )
        except PermissionError as exc:
            return ToolResult(
                tool=self.spec.name, status=ToolStatus.DENIED,
                error_type="permission_denied", message=str(exc),
                retryable=False, duration_ms=self._elapsed(start),
            )
        except FileNotFoundError as exc:
            return ToolResult(
                tool=self.spec.name, status=ToolStatus.ERROR,
                error_type="not_found", message=str(exc), retryable=False,
                duration_ms=self._elapsed(start),
            )
        except Exception as exc:  # noqa: BLE001 - tool boundary
            return ToolResult(
                tool=self.spec.name, status=ToolStatus.ERROR,
                error_type=type(exc).__name__, message=str(exc)[:2000],
                retryable=False, duration_ms=self._elapsed(start),
                metadata={"traceback": traceback.format_exc()[-1500:]},
            )
        finally:
            self.total_ms += self._elapsed(start)

        result.duration_ms = result.duration_ms or self._elapsed(start)
        # Redaction happens here, once, for every tool in the system.
        if ctx.settings is None or getattr(ctx.settings, "redact_secrets", True):
            result.stdout = redact_obj(result.stdout) if isinstance(result.stdout, str) else result.stdout
            result.stderr = redact_obj(result.stderr) if isinstance(result.stderr, str) else result.stderr
            result.data = redact_obj(result.data)
        if ctx.budget is not None and result.ok:
            ctx.budget.spend("tool", estimate_tokens(result.render(2000)), self.spec.name)
        return result

    async def _invoke(self, arguments: dict[str, Any], ctx: ToolContext) -> ToolResult:
        target = inspect.signature(self.fn).parameters
        kwargs = dict(arguments)
        if "ctx" in target:
            kwargs["ctx"] = ctx
        out = self.fn(**kwargs)
        if inspect.isawaitable(out):
            out = await out
        if isinstance(out, ToolResult):
            return out
        if isinstance(out, str):
            return ToolResult(tool=self.spec.name, stdout=out)
        if isinstance(out, dict):
            return ToolResult(tool=self.spec.name, data=out)
        return ToolResult(tool=self.spec.name, stdout=str(out))


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    # ------------------------------------------------------------------ #
    def register(self, spec: ToolSpec, fn: ToolFn | None = None):
        """Register a tool. Usable as `register(spec, fn)` or as a decorator:
        `@registry.register(spec)`."""
        if fn is None:
            def deco(f: ToolFn) -> ToolFn:
                self.register(spec, f)
                return f
            return deco
        t = Tool(spec, fn)
        self._tools[spec.name] = t
        return t

    def tool(self, name: str, description: str, risk: RiskLevel = RiskLevel.LOW,
             schema: dict[str, Any] | None = None, timeout: int = 120,
             idempotent: bool = False, tags: list[str] | None = None,
             supports_dry_run: bool = False):
        """Decorator form."""
        def deco(fn: ToolFn) -> ToolFn:
            self.register(
                ToolSpec(
                    name=name, description=description,
                    input_schema=schema or {"type": "object", "properties": {}},
                    risk_level=risk, timeout_seconds=timeout,
                    idempotent=idempotent, tags=tags or [],
                    supports_dry_run=supports_dry_run,
                ),
                fn,
            )
            return fn
        return deco

    # ------------------------------------------------------------------ #
    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def has(self, name: str) -> bool:
        return name in self._tools

    def names(self) -> list[str]:
        return sorted(self._tools)

    def specs(self) -> list[ToolSpec]:
        return [t.spec for t in self._tools.values()]

    def schemas_for_model(self, tags: list[str] | None = None) -> list[dict[str, Any]]:
        out = []
        for t in self._tools.values():
            if tags and not (set(tags) & set(t.spec.tags)):
                continue
            out.append(t.spec.to_model_schema())
        return out

    def tools_by_risk(self, max_risk: RiskLevel) -> list[Tool]:
        from ..core.schemas import RISK_ORDER
        return [t for t in self._tools.values() if RISK_ORDER[t.spec.risk_level] <= RISK_ORDER[max_risk]]

    def stats(self) -> list[dict[str, Any]]:
        return [
            {"name": t.spec.name, "calls": t.call_count, "total_ms": t.total_ms,
             "risk": t.spec.risk_level.value}
            for t in sorted(self._tools.values(), key=lambda x: -x.call_count)
        ]

    # ------------------------------------------------------------------ #
    async def execute(self, name: str, arguments: dict[str, Any],
                      ctx: ToolContext) -> ToolResult:
        """Full pipeline: resolve -> validate -> permission -> run -> normalize."""
        t = self._tools.get(name)
        if t is None:
            near = _closest(name, self._tools)
            msg = f"unknown tool '{name}'"
            if near:
                msg += f" — did you mean '{near}'?"
            return ToolResult(tool=name, status=ToolStatus.ERROR,
                              error_type="unknown_tool", message=msg, retryable=False)

        ok, err, cleaned = validate_tool_arguments(name, arguments, t.spec.input_schema)
        if not ok:
            return ToolResult(tool=name, status=ToolStatus.ERROR,
                              error_type="invalid_arguments", message=err, retryable=False)

        decision = check_permission(t.spec, ctx)
        if not decision["allowed"]:
            return ToolResult(
                tool=name, status=ToolStatus.DENIED,
                error_type="policy_denied", message=decision["reason"],
                retryable=False, metadata={"risk": t.spec.risk_level.value},
            )

        try:
            return await asyncio.wait_for(t(cleaned, ctx), timeout=t.spec.timeout_seconds)
        except asyncio.TimeoutError:
            return ToolResult(tool=name, status=ToolStatus.TIMEOUT,
                              error_type="timeout",
                              message=f"'{name}' exceeded {t.spec.timeout_seconds}s",
                              retryable=True)

    async def execute_call(self, call: dict[str, Any], ctx: ToolContext) -> ToolResult:
        return await self.execute(
            str(call.get("name", "")), call.get("arguments") or {}, ctx
        )


def check_permission(spec: ToolSpec, ctx: ToolContext) -> dict[str, Any]:
    from ..core.schemas import RISK_ORDER

    mode = (ctx.permission_mode or "BALANCED").upper()
    risk = spec.risk_level
    if mode == "LOCKED" and risk is not RiskLevel.READ:
        return {"allowed": False, "reason": f"LOCKED mode forbids {risk.value} tools"}
    if mode == "SAFE" and risk in (RiskLevel.HIGH, RiskLevel.DESTRUCTIVE):
        return {"allowed": False, "reason": f"SAFE mode requires approval for {risk.value}"}
    return {"allowed": True, "reason": ""}


def _closest(name: str, pool: dict[str, Tool]) -> str | None:
    import difflib
    matches = difflib.get_close_matches(name, list(pool), n=1, cutoff=0.6)
    return matches[0] if matches else None


def ok(tool: str, **data: Any) -> ToolResult:
    return ToolResult(tool=tool, status=ToolStatus.SUCCESS, data=data)


def fail(tool: str, message: str, error_type: str = "error",
         retryable: bool = False, **data: Any) -> ToolResult:
    return ToolResult(tool=tool, status=ToolStatus.ERROR, error_type=error_type,
                      message=message, retryable=retryable, data=data)


def deny(tool: str, message: str) -> ToolResult:
    return ToolResult(tool=tool, status=ToolStatus.DENIED, error_type="policy_denied",
                      message=message)
