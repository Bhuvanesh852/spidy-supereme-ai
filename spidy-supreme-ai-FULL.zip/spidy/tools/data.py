"""Data tools: CSV/JSON profiling, SQL, charts, and the ML trainer."""
from __future__ import annotations

import json
import sqlite3
import statistics
from pathlib import Path
from typing import Any

from ..core.schemas import RiskLevel, ToolResult, ToolSpec
from .base import ToolContext, ToolRegistry, deny, fail, ok

_CHART_TYPES = ("line", "bar", "scatter", "histogram", "pie", "box", "heatmap")


def _load_table(path: str, ctx: ToolContext) -> tuple[list[str], list[list[Any]], str]:
    """Return (columns, rows, kind). Uses the stdlib first so this works with
    zero third-party packages."""
    p = Path(path)
    if not p.exists():
        for cand in Path(ctx.workspace_root).rglob(p.name):
            if cand.is_file():
                p = cand
                break
    if not p.exists():
        raise FileNotFoundError(f"no such data file: {path}")

    if p.suffix.lower() in (".json", ".jsonl", ".ndjson"):
        raw = p.read_text(encoding="utf-8", errors="replace")
        if p.suffix.lower() == ".json":
            data = json.loads(raw)
            if isinstance(data, dict):
                for v in data.values():
                    if isinstance(v, list) and v and isinstance(v[0], dict):
                        data = v
                        break
            records = data if isinstance(data, list) else [data]
        else:
            records = [json.loads(ln) for ln in raw.splitlines() if ln.strip()]
        if records and isinstance(records[0], dict):
            cols = list({k for r in records[:200] for k in r})
            return cols, [[r.get(c) for c in cols] for r in records], "json"
        raise ValueError("JSON must be a list of objects")

    if p.suffix.lower() in (".tsv", ".tab"):
        import csv
        with p.open(encoding="utf-8", errors="replace", newline="") as f:
            rd = list(csv.reader(f, delimiter="\t"))
        return _finish_csv(rd, "tsv")

    import csv
    delim = ","
    sample = p.read_text(encoding="utf-8", errors="replace")[:8000]
    for cand in ("\t", ";", "|"):
        if sample.count(cand) > sample.count(delim):
            delim = cand
    with p.open(encoding="utf-8", errors="replace", newline="") as f:
        rd = list(csv.reader(f, delimiter=delim))
    return _finish_csv(rd, f"csv({delim!r})")


def _finish_csv(rows: list[list[str]], kind: str):
    if not rows:
        raise ValueError("empty file")
    header = [h.strip() for h in rows[0]]
    body = [r for r in rows[1:] if any(str(c).strip() for c in r)]
    return header, body, kind


def _infer(col: list[Any]) -> str:
    non_null = [c for c in col if c is not None and str(c).strip() != ""]
    if not non_null:
        return "empty"
    if all(isinstance(c, (int, float)) and not isinstance(c, bool) for c in non_null):
        return "numeric"
    if all(isinstance(c, bool) for c in non_null):
        return "boolean"
    parsed = 0
    for c in non_null[:200]:
        try:
            float(str(c).replace(",", ""))
            parsed += 1
        except (TypeError, ValueError):
            pass
    if parsed / len(non_null[:200]) > 0.85:
        return "numeric"
    uniq = len({str(c) for c in non_null})
    return "categorical" if uniq <= max(20, len(non_null) * 0.5) else "text"


def build(registry: ToolRegistry) -> None:
    S = ToolSpec

    @registry.register(S(
        name="inspect_data",
        description="Load a CSV/TSV/JSON/JSONL file and return a column profile: "
                    "type, nulls, distinct count, range, sample values, and a "
                    "small preview. Start here for any data question.",
        input_schema={"type": "object", "properties": {
            "path": {"type": "string"}, "rows": {"type": "integer", "description": "Preview rows"}},
            "required": ["path"]},
        risk_level=RiskLevel.READ, timeout_seconds=60, idempotent=True,
        tags=["data", "read"],
    ))
    async def inspect_data(path: str, ctx: ToolContext, rows: int = 8) -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("inspect_data", d.reason)
        try:
            cols, body, kind = _load_table(str(d.path), ctx)
        except Exception as exc:  # noqa: BLE001
            return fail("inspect_data", f"{type(exc).__name__}: {exc}", "parse_error")

        profile: list[dict[str, Any]] = []
        for i, c in enumerate(cols):
            col = [r[i] if i < len(r) else None for r in body]
            typ = _infer(col)
            non_null = [x for x in col if x is not None and str(x).strip() != ""]
            entry: dict[str, Any] = {
                "column": c, "type": typ, "rows": len(col),
                "nulls": len(col) - len(non_null),
                "distinct": len({str(x) for x in non_null}),
            }
            if typ == "numeric":
                nums = []
                for x in non_null:
                    try:
                        nums.append(float(str(x).replace(",", "")))
                    except (TypeError, ValueError):
                        pass
                if nums:
                    entry.update({
                        "min": min(nums), "max": max(nums),
                        "mean": round(statistics.fmean(nums), 4),
                        "median": round(statistics.median(nums), 4),
                        "stdev": round(statistics.pstdev(nums), 4) if len(nums) > 1 else 0.0,
                    })
            else:
                counts: dict[str, int] = {}
                for x in non_null:
                    k = str(x)[:60]
                    counts[k] = counts.get(k, 0) + 1
                top = sorted(counts.items(), key=lambda kv: -kv[1])[:5]
                entry["top_values"] = [{"value": k, "count": v} for k, v in top]
            profile.append(entry)

        # Correlations between numeric columns — cheap, high-signal.
        nums = [p for p in profile if p["type"] == "numeric"]
        correlations: list[dict[str, Any]] = []
        if len(nums) >= 2:
            series: dict[str, list[float]] = {}
            for p in nums:
                vals = []
                for r in body:
                    idx = cols.index(p["column"])
                    try:
                        vals.append(float(str(r[idx]).replace(",", "")) if idx < len(r) and
                                     r[idx] is not None else float("nan"))
                    except (TypeError, ValueError):
                        vals.append(float("nan"))
                series[p["column"]] = vals
            names = list(series)
            for i in range(len(names)):
                for j in range(i + 1, len(names)):
                    r = _pearson(series[names[i]], series[names[j]])
                    if r is not None:
                        correlations.append({"a": names[i], "b": names[j],
                                             "r": round(r, 3)})
            correlations.sort(key=lambda c: -abs(c["r"]))

        preview = [dict(zip(cols, r)) for r in body[:max(1, rows)]]
        return ok("inspect_data", path=str(d.path), format=kind, rows=len(body),
                  columns=cols, profile=profile, correlations=correlations[:15],
                  preview=preview)

    @registry.register(S(
        name="query_data",
        description="Run a SQL query over a CSV/TSV/JSON file. The file is loaded "
                    "into an in-memory SQLite table named 'data'.",
        input_schema={"type": "object", "properties": {
            "path": {"type": "string"}, "sql": {"type": "string"},
            "limit": {"type": "integer"}}, "required": ["path", "sql"]},
        risk_level=RiskLevel.READ, timeout_seconds=60, idempotent=True, tags=["data"],
    ))
    async def query_data(path: str, sql: str, ctx: ToolContext,
                         limit: int = 200) -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("query_data", d.reason)
        if re.search(r"(?i)\b(attach|pragma\s+\w+_key|insert|update|delete|drop|alter)\b", sql) \
                and not re.search(r"(?i)^\s*select", sql):
            return deny("query_data", "only SELECT statements are permitted")
        try:
            cols, body, _ = _load_table(str(d.path), ctx)
        except Exception as exc:  # noqa: BLE001
            return fail("query_data", f"{type(exc).__name__}: {exc}", "parse_error")

        conn = sqlite3.connect(":memory:")
        safe_cols = [re.sub(r"\W", "_", c) or f"col{i}" for i, c in enumerate(cols)]
        conn.execute(f"CREATE TABLE data ({','.join(f'{c} TEXT' for c in safe_cols)})")
        conn.executemany(
            f"INSERT INTO data VALUES ({','.join('?' * len(safe_cols))})",
            [[str(v) for v in r[:len(safe_cols)]] for r in body])
        try:
            cur = conn.execute(sql)
            names = [c[0] for c in cur.description or []]
            rows = cur.fetchmany(limit)
            total = len(rows)
        except sqlite3.Error as exc:
            conn.close()
            return fail("query_data", f"SQL error: {exc}", "sql_error",
                        available_columns=safe_cols)
        conn.close()
        return ok("query_data", columns=names, rows=[list(r) for r in rows],
                  returned=total, truncated=total >= limit)

    @registry.register(S(
        name="generate_chart",
        description="Create a chart from a data file or explicit data and save it "
                    "as PNG. Uses matplotlib if available, otherwise renders SVG.",
        input_schema={"type": "object", "properties": {
            "path": {"type": "string"}, "chart_type": {"type": "string"},
            "x": {"type": "string"}, "y": {"type": "string"}, "title": {"type": "string"},
            "output": {"type": "string"}}, "required": ["chart_type"]},
        risk_level=RiskLevel.MEDIUM, timeout_seconds=90, tags=["data", "image"],
    ))
    async def generate_chart(ctx: ToolContext, chart_type: str = "bar", path: str = "",
                             x: str = "", y: str = "", title: str = "",
                             output: str = "") -> ToolResult:
        if chart_type not in _CHART_TYPES:
            return fail("generate_chart",
                        f"chart_type must be one of {list(_CHART_TYPES)}", "invalid_arguments")
        if not path:
            return fail("generate_chart", "path to a data file is required",
                        "invalid_arguments")
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("generate_chart", d.reason)
        try:
            cols, body, _ = _load_table(str(d.path), ctx)
        except Exception as exc:  # noqa: BLE001
            return fail("generate_chart", f"{type(exc).__name__}: {exc}", "parse_error")

        if not x or not y:
            numeric = [c for c in cols if _infer([r[cols.index(c)] for r in body]) == "numeric"]
            if not numeric:
                return fail("generate_chart", "no numeric column found", "no_numeric_column")
            y = y or numeric[0]
            x = x or next((c for c in cols if c != y), "index")

        def series(col: str) -> list[float]:
            i = cols.index(col)
            out = []
            for r in body:
                try:
                    out.append(float(str(r[i]).replace(",", "")) if i < len(r) else 0.0)
                except (TypeError, ValueError):
                    out.append(0.0)
            return out

        ys = series(y)
        xs = [str(r[cols.index(x)])[:24] if cols.index(x) < len(r) else ""
              for r in body] if x in cols else [str(i) for i in range(len(body))]

        name = output or f"chart_{chart_type}_{int(__import__('time').time())}.png"
        out_path = ctx.artifacts_dir / name

        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt

            fig, ax = plt.subplots(figsize=(9, 5.5))
            if chart_type == "line":
                ax.plot(xs, ys, marker="o", linewidth=2)
            elif chart_type == "bar":
                ax.bar(xs, ys, color="#4f7cff")
            elif chart_type == "scatter":
                vals = series(next((c for c in cols if c != y and
                                    _infer([r[cols.index(c)] for r in body]) == "numeric"), y))
                ax.scatter(vals, ys, alpha=0.65, color="#4f7cff")
            elif chart_type == "histogram":
                ax.hist(ys, bins=min(40, max(8, len(ys) // 4)), color="#4f7cff")
            elif chart_type == "pie":
                head = [n for _, n in sorted(zip(ys, xs), reverse=True)[:8]]
                labels = xs[:8]
                ax.pie([abs(v) or 1 for v in ys[:8]], labels=labels, autopct="%1.1f%%")
            elif chart_type == "box":
                ax.boxplot([ys])
            else:
                ax.bar(xs[:40], ys[:40], color="#4f7cff")
            ax.set_title(title or f"{y} by {x}")
            if chart_type not in ("pie", "histogram", "box") and len(xs) > 20:
                ax.set_xticks(range(len(xs)))
                ax.set_xticklabels(xs, rotation=45, ha="right", fontsize=8)
            ax.grid(alpha=0.25)
            fig.tight_layout()
            fig.savefig(out_path, dpi=130)
            plt.close(fig)
            fmt = "png"
        except ImportError:
            fmt = "svg"
            out_path = out_path.with_suffix(".svg")
            out_path.write_text(_svg_chart(chart_type, xs, ys, title or f"{y} by {x}"))
        except Exception as exc:  # noqa: BLE001
            return fail("generate_chart", f"{type(exc).__name__}: {exc}", "render_error")

        if ctx.db:
            ctx.db.record_artifact(str(out_path), "image", ctx.task_id)
        return ok("generate_chart", path=str(out_path), format=fmt, chart_type=chart_type,
                  x=x, y=y, points=len(ys), title=title)

    @registry.register(S(
        name="train_model",
        description="Train a real machine-learning model on a local dataset. "
                    "Algorithms: logistic_regression, random_forest, gradient_"
                    "boosting, linear_regression, ridge, kmeans, naive_bayes, svm. "
                    "Reports accuracy/F1 on a held-out split and saves the model.",
        input_schema={"type": "object", "properties": {
            "path": {"type": "string"},
            "target": {"type": "string", "description": "Label column to predict"},
            "algorithm": {"type": "string"},
            "test_size": {"type": "number"},
            "feature_columns": {"type": "array", "items": {"type": "string"}},
            "model_name": {"type": "string", "description": "Save name"}},
            "required": ["path", "target"]},
        risk_level=RiskLevel.MEDIUM, timeout_seconds=300, tags=["ml", "data", "train"],
    ))
    async def train_model(path: str, target: str, ctx: ToolContext,
                          algorithm: str = "auto", test_size: float = 0.2,
                          feature_columns: list[str] | None = None,
                          model_name: str = "") -> ToolResult:
        d = ctx.policy.check(path, "read")
        if not d.allowed:
            return deny("train_model", d.reason)
        try:
            import numpy as np
        except ImportError:
            return fail("train_model", "numpy is required for training", "not_available")
        try:
            from sklearn.model_selection import train_test_split, cross_val_score
            from sklearn.metrics import (accuracy_score, f1_score, mean_squared_error,
                                         r1_score, silhouette_score)
            from sklearn.preprocessing import LabelEncoder, StandardScaler
            from sklearn.pipeline import Pipeline
        except ImportError:
            return fail("train_model", "scikit-learn is not installed. Run: "
                                       "pip install scikit-learn", "not_available")

        try:
            cols, body, fmt = _load_table(str(d.path), ctx)
        except Exception as exc:  # noqa: BLE001
            return fail("train_model", f"{type(exc).__name__}: {exc}", "parse_error")
        if target not in cols:
            return fail("train_model", f"target '{target}' not in columns",
                        "invalid_arguments", columns=cols)

        features = feature_columns or [c for c in cols if c != target]
        ti = cols.index(target)
        X, y, dropped = [], [], []
        for c in features:
            i = cols.index(c)
            if _infer([r[i] if i < len(r) else None for r in body]) in ("numeric", "empty"):
                X.append([_num(r[i] if i < len(r) else None) for r in body])
            else:
                idx: dict[str, int] = {}
                for r in body:
                    v = str(r[i] if i < len(r) else "")
                    if v not in idx:
                        idx[v] = len(idx)
                if len(idx) > 60:
                    dropped.append(c)
                    continue
                X.append([idx.get(str(r[i] if i < len(r) else ""), 0) for r in body])
        if not X:
            return fail("train_model", "no usable feature columns", "no_features")
        if dropped:
            return ok("train_model", skipped=True, message=
                      f"too many categories in {dropped}; specify feature_columns",
                      columns=cols)
        X = np.asarray(X, dtype=np.float64).T
        y_raw = [r[ti] if ti < len(r) else "" for r in body]
        classes = sorted({str(v) for v in y_raw})

        task_kind = "regression" if algorithm in (
            "linear_regression", "ridge", "kmeans") else "classification"
        if algorithm == "auto":
            numeric_target = True
            try:
                [float(str(v).replace(",", "")) for v in y_raw[:50]]
            except (TypeError, ValueError):
                numeric_target = False
            if len(classes) > max(20, len(y_raw) * 0.5):
                task_kind = "clustering"
            elif numeric_target and len(classes) > 50:
                task_kind = "regression"
            else:
                task_kind = "classification"

        metrics: dict[str, Any] = {"task": task_kind, "algorithm": None,
                                   "n_samples": len(y_raw), "n_features": X.shape[1]}

        if task_kind == "clustering":
            from sklearn.cluster import KMeans
            k = min(8, max(2, len(classes)))
            km = KMeans(n_clusters=k, n_init=10, random_state=42)
            labels = km.fit_predict(X)
            try:
                metrics["silhouette"] = round(float(silhouette_score(X, labels)), 4)
            except ValueError:
                pass
            metrics["algorithm"] = "kmeans"
            metrics["clusters"] = k
            fitted = km
        elif task_kind == "regression":
            from sklearn.linear_model import LinearRegression, Ridge
            from sklearn.ensemble import RandomForestRegressor
            algos = {"linear_regression": LinearRegression(),
                     "ridge": Ridge(alpha=1.0),
                     "random_forest": RandomForestRegressor(n_estimators=120, random_state=42)}
            fitted = algos.get(algorithm) or algos["random_forest"]
            y = np.asarray([_num(v) for v in y_raw], dtype=np.float64)
            if len(y) < 10:
                return fail("train_model", "need at least 10 samples to split", "too_few")
            Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=test_size, random_state=42)
            fitted.fit(Xtr, ytr)
            pred = fitted.predict(Xte)
            metrics.update({
                "algorithm": type(fitted).__name__, "r2": round(float(r1_score(yte, pred)), 4),
                "rmse": round(float(np.sqrt(mean_squared_error(yte, pred))), 4),
            })
        else:
            from sklearn.linear_model import LogisticRegression
            from sklearn.ensemble import (RandomForestClassifier, GradientBoostingClassifier)
            from sklearn.naive_bayes import GaussianNB
            from sklearn.svm import SVC
            if len(classes) < 2:
                return fail("train_model", "target has only one class", "single_class")
            le = LabelEncoder()
            y = le.fit_transform([str(v) for v in y_raw])
            if len(classes) < 15 and algorithm in ("auto", "logistic_regression"):
                algos = {"logistic_regression": LogisticRegression(max_iter=2000),
                         "naive_bayes": GaussianNB(),
                         "random_forest": RandomForestClassifier(n_estimators=200, random_state=42),
                         "gradient_boosting": GradientBoostingClassifier(random_state=42),
                         "svm": SVC(probability=False)}
            else:
                algos = {"random_forest": RandomForestClassifier(n_estimators=200, random_state=42),
                         "gradient_boosting": GradientBoostingClassifier(random_state=42)}
            fitted = algos.get(algorithm) or algos["logistic_regression"]
            stratify = y if (min(np.bincount(y)) >= 2 and len(classes) <= len(y) // 3) else None
            Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=test_size,
                                                  random_state=42, stratify=stratify)
            if len(set(ytr.tolist())) < 2:
                return fail("train_model", "training split has one class", "too_few")
            fitted.fit(Xtr, ytr)
            pred = fitted.predict(Xte)
            avg = "binary" if len(classes) == 2 else "weighted"
            metrics.update({
                "algorithm": type(fitted).__name__,
                "accuracy": round(float(accuracy_score(yte, pred)), 4),
                "f1": round(float(f1_score(yte, pred, average=avg, zero_division=0)), 4),
                "classes": le.classes_.tolist(),
            })
            try:
                if X.shape[1] <= 60:
                    cv = cross_val_score(fitted, X, y, cv=min(5, len(set(y.tolist()))))
                    metrics["cv_accuracy"] = round(float(cv.mean()), 4)
                    metrics["cv_std"] = round(float(cv.std()), 4)
            except Exception:
                pass
            try:
                imp = getattr(fitted, "feature_importances_", None)
                if imp is None:
                    imp = getattr(fitted, "coef_", None)
                    imp = np.abs(imp[0]) if imp is not None and imp.ndim > 1 else imp
                if imp is not None:
                    order = np.argsort(-np.asarray(imp).ravel())[:12]
                    metrics["top_features"] = [{"feature": features[i],
                                                "importance": round(float(imp.ravel()[i]), 4)}
                                               for i in order]
            except Exception:
                pass

        # Persist
        saved = ""
        try:
            import joblib
            name = model_name or f"model_{int(__import__('time').time())}.joblib"
            p = ctx.settings.model_dir / name
            joblib.dump({"model": fitted, "features": features, "target": target,
                         "metrics": metrics, "format": fmt}, p)
            saved = str(p)
        except Exception as exc:  # noqa: BLE001
            saved = f"(not saved: {type(exc).__name__})"

        await ctx_extra_emit(ctx, "ml.trained", algorithm=metrics.get("algorithm"),
                             accuracy=metrics.get("accuracy"), task=task_kind)
        return ok("train_model", model_path=saved, **metrics)

    @registry.register(S(
        name="predict", description="Score new data with a model saved by train_model.",
        input_schema={"type": "object", "properties": {
            "model_path": {"type": "string"}, "data": {"type": "array"},
            "explain": {"type": "boolean"}}, "required": ["model_path", "data"]},
        risk_level=RiskLevel.LOW, timeout_seconds=90, idempotent=True, tags=["ml"],
    ))
    async def predict(model_path: str, ctx: ToolContext, data: list | None = None,
                      explain: bool = False) -> ToolResult:
        try:
            import joblib
        except ImportError:
            return fail("predict", "joblib is required", "not_available")
        p = Path(model_path)
        if not p.exists():
            p = ctx.settings.model_dir / Path(model_path).name
        if not p.exists():
            return fail("predict", f"model not found: {model_path}", "not_found")
        bundle = joblib.load(p)
        records = data or []
        if not records:
            return fail("predict", "data is required", "invalid_arguments")
        import numpy as np
        feats = bundle["features"]
        rows = []
        for r in records:
            if isinstance(r, dict):
                rows.append([_num(r.get(f, 0)) for f in feats])
            else:
                rows.append([_num(v) for v in r][:len(feats)])
        X = np.asarray(rows, dtype=np.float64)
        preds = bundle["model"].predict(X)
        classes = bundle["metrics"].get("classes")
        out: list[Any] = []
        for i, pr in enumerate(preds):
            out.append({"input": records[i],
                        "prediction": str(classes[pr]) if classes and
                        isinstance(pr, (int, np.integer)) else float(pr)})
        extra: dict[str, Any] = {}
        if explain and hasattr(bundle["model"], "predict_proba"):
            try:
                proba = bundle["model"].predict_proba(X)
                names = [str(c) for c in classes] if classes else \
                    [str(j) for j in range(proba.shape[1])]
                for i in range(min(len(out), len(proba))):
                    row = {names[j]: round(float(proba[i][j]), 4)
                           for j in range(proba.shape[1])}
                    out[i]["confidence"] = row
                    out[i]["predicted_class"] = max(row, key=row.get) if row else None
            except Exception:
                pass
        return ok("predict", model=p.name, predictions=out, **extra)


# --------------------------------------------------------------------------- #


def _num(v: Any) -> float:
    if v is None:
        return 0.0
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return float(v)
    try:
        return float(str(v).replace(",", "").strip())
    except (TypeError, ValueError):
        return 0.0


def _pearson(a: list[float], b: list[float]) -> float | None:
    import math
    pairs = [(x, y) for x, y in zip(a, b)
             if x == x and y == y]  # drop NaN
    if len(pairs) < 3:
        return None
    n = len(pairs)
    mx = sum(p[0] for p in pairs) / n
    my = sum(p[1] for p in pairs) / n
    num = sum((p[0] - mx) * (p[1] - my) for p in pairs)
    dx = math.sqrt(sum((p[0] - mx) ** 2 for p in pairs))
    dy = math.sqrt(sum((p[1] - my) ** 2 for p in pairs))
    if dx == 0 or dy == 0:
        return None
    return num / (dx * dy)


def _svg_chart(chart_type: str, xs: list[str], ys: list[float], title: str) -> str:
    """Dependency-free fallback so charting works with nothing installed."""
    w, h = 900, 520
    pad = 60
    if not ys:
        ys = [0]
    lo, hi = min(ys), max(ys)
    span = (hi - lo) or 1.0
    n = len(ys)
    step = (w - pad * 2) / max(1, n - 1)
    bw = max(2, min(36, (w - pad * 2) / max(1, n)))
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" '
             f'viewBox="0 0 {w} {h}" font-family="system-ui,sans-serif">',
             f'<rect width="{w}" height="{h}" fill="#0f1117"/>',
             f'<text x="{w / 2}" y="34" fill="#e6e8ee" font-size="19" '
             f'text-anchor="middle">{_esc(title)}</text>']
    for i in range(5):
        y = pad + (h - pad * 2) * i / 4
        val = hi - span * i / 4
        parts.append(f'<line x1="{pad}" y1="{y:.1f}" x2="{w - pad}" y2="{y:.1f}" '
                     f'stroke="#232733" stroke-width="1"/>')
        parts.append(f'<text x="{pad - 8}" y="{y + 4:.1f}" fill="#7a8194" font-size="11" '
                     f'text-anchor="end">{val:.2f}</text>')
    for i, v in enumerate(ys):
        bh = (v - lo) / span * (h - pad * 2)
        x = pad + i * step
        if chart_type == "line":
            if i < n - 1:
                nx = pad + (i + 1) * step
                ny = h - pad - ((ys[i + 1] - lo) / span * (h - pad * 2))
                parts.append(f'<line x1="{x:.1f}" y1="{h - pad - bh:.1f}" x2="{nx:.1f}" '
                             f'y2="{ny:.1f}" stroke="#4f7cff" stroke-width="2"/>')
        else:
            parts.append(f'<rect x="{x:.1f}" y="{h - pad - bh:.1f}" width="{bw:.1f}" '
                         f'height="{max(1, bh):.1f}" fill="#4f7cff" rx="2"/>')
    if chart_type in ("bar", "line") and n <= 25:
        for i, lbl in enumerate(xs):
            parts.append(f'<text x="{pad + i * step:.1f}" y="{h - pad + 18}" '
                         f'fill="#7a8194" font-size="10" text-anchor="middle" '
                         f'transform="rotate(-20 {pad + i * step:.1f} {h - pad + 18})">'
                         f'{_esc(lbl[:10])}</text>')
    parts.append("</svg>")
    return "\n".join(parts)


def _esc(s: str) -> str:
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
             .replace('"', "&quot;"))


async def ctx_extra_emit(ctx: ToolContext, event: str, **payload: Any) -> None:
    try:
        from ..core.events import BUS
        await BUS.emit(event, task_id=ctx.task_id, **payload)
    except Exception:
        pass


import re  # noqa: E402  (used by query_data guard)
