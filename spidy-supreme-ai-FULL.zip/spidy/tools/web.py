"""Web tools: search, fetch, extract, screenshot.

Network access is policy-gated, SSRF-checked before every request, and every
retrieved page is treated as untrusted content (fenced + scanned) before it
reaches a prompt.
"""
from __future__ import annotations

import html
import json
import re
import shutil
import time
from typing import Any
from urllib.parse import quote_plus, urlparse

import httpx

from ..core.schemas import RiskLevel, ToolResult, ToolSpec
from ..security.guard import scan
from .base import ToolContext, ToolRegistry, deny, fail, ok

UA = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "SPIDY/1.0 (offline-first AI assistant)")

_SCRIPT_STYLE = re.compile(
    r"<(script|style|noscript|svg|canvas|iframe|template)\b[^>]*>.*?</\1>",
    re.I | re.S)
_COMMENT = re.compile(r"<!--.*?-->", re.S)
_TAG = re.compile(r"<[^>]+>")
_WS = re.compile(r"[ \t\r\f\v]+")
_NL = re.compile(r"\n{3,}")
_ENTITY = re.compile(r"&(#x?[0-9a-fA-F]+|\w+);")

_ENTITIES = {"amp": "&", "lt": "<", "gt": ">", "quot": '"', "apos": "'", "nbsp": " ",
             "mdash": "—", "ndash": "–", "hellip": "…", "rsquo": "’", "lsquo": "‘",
             "ldquo": "“", "rdquo": "”"}


def html_to_text(raw: str) -> str:
    raw = _COMMENT.sub(" ", raw)
    raw = _SCRIPT_STYLE.sub(" ", raw)
    raw = re.sub(r"<br\s*/?>", "\n", raw, flags=re.I)
    raw = re.sub(r"</(p|div|li|tr|h[1-6]|section|article)>", "\n", raw, flags=re.I)
    raw = re.sub(r"<li\b[^>]*>", "  - ", raw, flags=re.I)
    raw = _TAG.sub(" ", raw)

    def _ent(m: re.Match[str]) -> str:
        g = m.group(1)
        if g.startswith("#x") or g.startswith("#X"):
            try:
                return chr(int(g[2:], 16))
            except ValueError:
                return m.group(0)
        if g.startswith("#"):
            try:
                return chr(int(g[1:]))
            except ValueError:
                return m.group(0)
        return _ENTITIES.get(g, m.group(0))

    raw = _ENTITY.sub(_ent, raw)
    raw = html.unescape(raw)
    raw = _WS.sub(" ", raw)
    raw = _NL.sub("\n\n", raw)
    return raw.strip()


def extract_title(raw: str, fallback: str = "") -> str:
    m = re.search(r"<title[^>]*>(.*?)</title>", raw, re.I | re.S)
    if m:
        return html.unescape(_TAG.sub("", m.group(1))).strip()[:200]
    m = re.search(r"<h1[^>]*>(.*?)</h1>", raw, re.I | re.S)
    if m:
        return html.unescape(_TAG.sub("", m.group(1))).strip()[:200]
    return fallback or urlparse(fallback).netloc


def extract_links(raw: str, base: str = "") -> list[dict[str, str]]:
    from urllib.parse import urljoin
    out: list[dict[str, str]] = []
    for m in re.finditer(r"<a\b[^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>",
                         raw, re.I | re.S):
        href, text = m.group(1), html.unescape(_TAG.sub(" ", m.group(2))).strip()
        if href.startswith(("#", "javascript:", "mailto:")):
            continue
        if base:
            href = urljoin(base, href)
        if href.startswith("http"):
            out.append({"url": href, "text": text[:120] or href})
        if len(out) >= 200:
            break
    return out


# --------------------------------------------------------------------------- #

# Free, no-key search backends. Each is tried in order until one answers.
SEARCH_BACKENDS = [
    ("duckduckgo_html", "https://html.duckduckgo.com/html/?q={q}"),
    ("duckduckgo_lite", "https://lite.duckduckgo.com/lite/?q={q}"),
    ("mojeek", "https://www.mojeek.com/search?q={q}"),
    ("searxng", ""),          # configured via SPIDY_SEARXNG_URL
]


def build(registry: ToolRegistry) -> None:
    S = ToolSpec

    def _check(url: str, ctx: ToolContext, tool: str) -> ToolResult | None:
        if not ctx.allow_network:
            return deny(tool, "network access is disabled (SPIDY_ALLOW_NETWORK=false)")
        if ctx.network_policy is not None:
            d = ctx.network_policy.check(url)
            if not d.allowed:
                return deny(tool, f"blocked by network policy: {d.reason}")
        return None

    @registry.register(S(
        name="search_web",
        description="Search the web for current information. Uses free no-key "
                    "backends. Returns titles, URLs and snippets.",
        input_schema={"type": "object", "properties": {
            "query": {"type": "string"},
            "count": {"type": "integer", "description": "Results, default 8"},
        }, "required": ["query"]},
        risk_level=RiskLevel.LOW, timeout_seconds=60, idempotent=True,
        tags=["web", "research"],
    ))
    async def search_web(query: str, ctx: ToolContext, count: int = 8) -> ToolResult:
        if not ctx.allow_network:
            return deny("search_web", "network access is disabled")
        from ..core.config import get_settings
        searx = getattr(ctx.settings, "searxng_url", "") if ctx.settings else ""
        backends = ([("searxng", searx + "/search?q={q}&format=json")] if searx else []) \
            + SEARCH_BACKENDS
        errors: list[str] = []

        for name, tmpl in backends:
            if not tmpl:
                continue
            url = tmpl.format(q=quote_plus(query))
            blocked = _check(url, ctx, "search_web")
            if blocked:
                return blocked
            try:
                async with httpx.AsyncClient(
                        timeout=20, follow_redirects=True,
                        headers={"User-Agent": UA}) as c:
                    r = await c.get(url)
                    r.raise_for_status()
                    body = r.text
            except Exception as exc:  # noqa: BLE001
                errors.append(f"{name}: {type(exc).__name__}")
                continue

            results = _parse_search(body, name, count)
            if results:
                return ok("search_web", query=query, backend=name, results=results,
                          count=len(results))
            errors.append(f"{name}: no results parsed")

        return fail("search_web",
                    f"all search backends failed ({'; '.join(errors[:4])}). "
                    "SPIDY will answer from local knowledge instead — do not "
                    "fabricate citations.",
                    "search_unavailable", retryable=True, query=query)

    def _parse_search(body: str, backend: str, count: int) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        if backend == "searxng":
            try:
                for r in json.loads(body).get("results", [])[:count]:
                    out.append({"title": r.get("title", ""), "url": r.get("url", ""),
                                "snippet": (r.get("content", "") or "")[:400]})
            except (json.JSONDecodeError, AttributeError, TypeError):
                pass
            return out

        patterns = [
            r'<a[^>]+class="[^"]*result__a[^"]*"[^>]+href="([^"]+)"[^>]*>(.*?)</a>',
            r'<a[^>]+class="[^"]*ob[^"]*"[^>]+href="([^"]+)"[^>]*>(.*?)</a>',
            r'<a[^>]+class="title"[^>]+href="([^"]+)"[^>]*>(.*?)</a>',
            r'<h2><a[^>]+href="([^"]+)"[^>]*>(.*?)</a></h2>',
        ]
        for pat in patterns:
            for m in re.finditer(pat, body, re.I | re.S):
                href, title = m.group(1), html.unescape(_TAG.sub("", m.group(2))).strip()
                if "duckduckgo.com/l/?uddg=" in href:
                    from urllib.parse import parse_qs, urlparse
                    href = (parse_qs(urlparse(href).query).get("uddg") or [href])[0]
                if not href.startswith("http"):
                    continue
                # Snippet = the text block that follows the anchor.
                tail = body[m.end(): m.end() + 900]
                snip = ""
                sm = re.search(
                    r'class="[^"]*(?:result__snippet|result-snippet|content)"[^>]*>(.*?)</',
                    tail, re.I | re.S)
                if sm:
                    snip = html.unescape(_TAG.sub(" ", sm.group(1))).strip()[:400]
                out.append({"title": title[:200], "url": href, "snippet": snip})
                if len(out) >= count:
                    return out
        return out

    @registry.register(S(
        name="fetch_url",
        description="Fetch a URL and return readable text. The page is treated "
                    "as untrusted: injection attempts are stripped before it "
                    "can reach the model as instructions.",
        input_schema={"type": "object", "properties": {
            "url": {"type": "string"},
            "max_chars": {"type": "integer", "description": "Default 12000"},
            "include_links": {"type": "boolean"}}, "required": ["url"]},
        risk_level=RiskLevel.LOW, timeout_seconds=60, idempotent=True,
        tags=["web", "research", "read"],
    ))
    async def fetch_url(url: str, ctx: ToolContext, max_chars: int = 12000,
                        include_links: bool = False) -> ToolResult:
        blocked = _check(url, ctx, "fetch_url")
        if blocked:
            return blocked
        try:
            async with httpx.AsyncClient(
                    timeout=25, follow_redirects=True,
                    headers={"User-Agent": UA}) as c:
                r = await c.get(url)
                r.raise_for_status()
                raw = r.text
                ctype = r.headers.get("content-type", "")
        except httpx.HTTPStatusError as exc:
            return fail("fetch_url", f"HTTP {exc.response.status_code}", "http_error",
                        retryable=exc.response.status_code >= 500)
        except Exception as exc:  # noqa: BLE001
            return fail("fetch_url", f"{type(exc).__name__}: {exc}", "network_error",
                        retryable=True)

        title = extract_title(raw, url)
        if "json" in ctype:
            try:
                data = json.loads(raw)
                text = json.dumps(data, indent=2)[:max_chars]
            except (json.JSONDecodeError, TypeError):
                text = raw[:max_chars]
            verdict = scan(raw[:3000])
            return ok("fetch_url", url=url, title=title, content=text,
                      content_type="json", guarded=not verdict.safe,
                      findings=verdict.findings if not verdict.safe else [])

        text = html_to_text(raw)
        verdict = scan(text[:5000])
        clean = text
        if not verdict.safe:
            clean = "\n".join(
                ln for ln in text.splitlines()
                if not any(p.search(ln) for _, p in
                           __import__("spidy.security.guard", fromlist=["x"])
                           .INJECTION_PATTERNS)) or text[:4000]
            clean += f"\n\n[SPIDY GUARD removed {len(verdict.findings or [])} suspicious " \
                     f"instruction-like segment(s): {verdict.reason}]"

        out: dict[str, Any] = {
            "url": url, "title": title, "content": clean[:max_chars],
            "content_type": "html", "guarded": not verdict.safe,
            "bytes": len(raw),
        }
        if not verdict.safe:
            out["findings"] = verdict.findings
        if include_links:
            out["links"] = extract_links(raw, url)[:60]
        return ok("fetch_url", **out)

    @registry.register(S(
        name="open_url", description="Alias of fetch_url that returns content "
                                     "directly in stdout for quick reading.",
        input_schema={"type": "object", "properties": {"url": {"type": "string"}},
                      "required": ["url"]},
        risk_level=RiskLevel.LOW, timeout_seconds=60, idempotent=True,
        tags=["web", "research", "read"],
    ))
    async def open_url(url: str, ctx: ToolContext) -> ToolResult:
        r = await fetch_url(url, ctx, max_chars=20000)
        if r.ok:
            return ok("open_url", url=url, title=r.data.get("title", ""),
                      content=r.data.get("content", ""))
        return r

    @registry.register(S(
        name="http_request", description="Make an authenticated HTTP request. "
                                         "Secrets are injected server-side, never "
                                         "passed in the prompt.",
        input_schema={"type": "object", "properties": {
            "url": {"type": "string"},
            "method": {"type": "string", "description": "GET/POST/PUT/PATCH/DELETE"},
            "body": {"type": "string"},
            "headers": {"type": "object"},
            "env_secret": {"type": "string",
                           "description": "Name of an env var to send as Bearer token"}},
            "required": ["url"]},
        risk_level=RiskLevel.MEDIUM, timeout_seconds=60, tags=["web"],
    ))
    async def http_request(url: str, ctx: ToolContext, method: str = "GET",
                           body: str = "", headers: dict | None = None,
                           env_secret: str = "") -> ToolResult:
        import os
        blocked = _check(url, ctx, "http_request")
        if blocked:
            return blocked
        hdrs = {"User-Agent": UA, "Accept": "*/*"}
        if headers:
            hdrs.update({k: v for k, v in headers.items() if k.lower() != "cookie"})
        if env_secret:
            secret = os.environ.get(env_secret, "")
            if not secret:
                return fail("http_request", f"env var {env_secret} is not set",
                            "missing_credential")
            hdrs["Authorization"] = f"Bearer {secret}"
        try:
            async with httpx.AsyncClient(timeout=45, follow_redirects=True) as c:
                r = await c.request(method.upper(), url, headers=hdrs,
                                    content=body.encode() if body else None)
                return ok("http_request", status=r.status_code, url=str(r.url),
                          body=r.text[:30000],
                          ok_status=200 <= r.status_code < 300)
        except Exception as exc:  # noqa: BLE001
            return fail("http_request", f"{type(exc).__name__}: {exc}", "network_error",
                        retryable=True)

    # ---- browser (optional: playwright) ---------------------------------- #
    @registry.register(S(
        name="browser_navigate", description="Open a page in a real browser and "
                                             "return its text. Falls back to "
                                             "fetch_url when Playwright is absent.",
        input_schema={"type": "object", "properties": {
            "url": {"type": "string"}, "screenshot": {"type": "boolean"},
            "wait_for": {"type": "string"}}, "required": ["url"]},
        risk_level=RiskLevel.LOW, timeout_seconds=90, tags=["web", "browser"],
    ))
    async def browser_navigate(url: str, ctx: ToolContext, screenshot: bool = False,
                              wait_for: str = "") -> ToolResult:
        blocked = _check(url, ctx, "browser_navigate")
        if blocked:
            return blocked
        try:
            from playwright.async_api import async_playwright
        except ImportError:
            r = await fetch_url(url, ctx, max_chars=20000)
            if r.ok:
                r.data["rendered"] = False
                r.data["note"] = "Playwright not installed — returned static HTML. " \
                                 "Install with: pip install playwright && playwright install"
            return r
        try:
            async with async_playwright() as p:
                browser = await p.chromium.launch(args=["--no-sandbox"])
                page = await browser.new_page(user_agent=UA)
                await page.goto(url, wait_until="domcontentloaded", timeout=30000)
                if wait_for:
                    try:
                        await page.wait_for_selector(wait_for, timeout=8000)
                    except Exception:
                        pass
                text = await page.inner_text("body")
                title = await page.title()
                shot = ""
                if screenshot:
                    shot = f"browser_{int(time.time())}.png"
                    await page.screenshot(path=str(ctx.artifacts_dir / shot), full_page=True)
                await browser.close()
                verdict = scan(text[:4000])
                return ok("browser_navigate", url=url, title=title,
                          content=text[:25000], rendered=True, guarded=not verdict.safe,
                          screenshot=shot)
        except Exception as exc:  # noqa: BLE001
            return fail("browser_navigate", f"{type(exc).__name__}: {exc}",
                        "browser_error", retryable=True)

    @registry.register(S(
        name="browser_screenshot", description="Capture a screenshot of a URL.",
        input_schema={"type": "object", "properties": {
            "url": {"type": "string"}, "full_page": {"type": "boolean"},
            "width": {"type": "integer"}, "height": {"type": "integer"}},
            "required": ["url"]},
        risk_level=RiskLevel.LOW, timeout_seconds=90, tags=["web", "browser", "image"],
    ))
    async def browser_screenshot(url: str, ctx: ToolContext, full_page: bool = True,
                                width: int = 1440, height: int = 900) -> ToolResult:
        try:
            from playwright.async_api import async_playwright
        except ImportError:
            return fail("browser_screenshot", "Playwright not installed", "not_available")
        blocked = _check(url, ctx, "browser_screenshot")
        if blocked:
            return blocked
        try:
            async with async_playwright() as p:
                browser = await p.chromium.launch(args=["--no-sandbox"])
                page = await browser.new_page(viewport={"width": width, "height": height})
                await page.goto(url, wait_until="networkidle", timeout=30000)
                name = f"shot_{int(time.time())}.png"
                path = ctx.artifacts_dir / name
                await page.screenshot(path=str(path), full_page=full_page)
                await browser.close()
                if ctx.db:
                    ctx.db.record_artifact(str(path), "image", ctx.task_id)
                return ok("browser_screenshot", path=str(path), url=url)
        except Exception as exc:  # noqa: BLE001
            return fail("browser_screenshot", str(exc)[:200], "browser_error")
