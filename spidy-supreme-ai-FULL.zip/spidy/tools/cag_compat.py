"""CAG needs to know each tool's risk level to decide what is safe to cache.
The registry owns the truth, so it registers it here on the way out."""
from __future__ import annotations


def register_risk(tool: str, risk) -> None:
    from ..cag.cache import register_risk as _r
    _r(tool, risk)
