"""Application container.

One object that owns every subsystem and wires the cross-cutting dependencies
(retriever into the tool context, router into the research pipeline, cache into
the runtime). Keeping this in one place stops the wiring from leaking into the
components.
"""
from __future__ import annotations

import asyncio
import sqlite3
from pathlib import Path
from typing import Any, Callable

from .agents.runtime import AgentRuntime
from .agents.team import TeamRunner
from .brain.router import ModelRouter
from .cag.cache import SemanticCache
from .core.config import Settings, get_settings
from .core.events import BUS, EventBus
from .core.schemas import LLMMessage
from .core.store import Database
from .core.token_budget import TokenBudget
from .rag.retriever import Retriever
from .tools import get_registry


def _event_persister(db: Database):
    """Return a bus subscriber that mirrors every event into the events table.

    Bound to one database. Each Spidy registers its own and unregisters on
    close (see `close`), so events reach the database of the instance that is
    actually running, and a stale instance can't write into a dead one.
    """
    def _persist(ev) -> None:
        try:
            if ev.task_id:
                db.log_event(ev.task_id, ev.type, ev.payload)
        except Exception:  # noqa: BLE001
            pass
    return _persist


class Spidy:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()
        self.db = Database(self.settings.db_path)
        self.registry = get_registry()
        self.router = ModelRouter(self.settings)
        self.events = BUS

        # RAG + CAG share one connection so the vector index and the cache are
        # consistent within a transaction.
        self._conn = sqlite3.connect(str(self.settings.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row

        self.retriever = Retriever(self._conn, self.settings)
        self.cache = SemanticCache(
            self._conn,
            embedder=self.retriever.embedder,
            threshold=self.settings.cag_similarity_threshold,
            ttl_seconds=self.settings.cag_ttl_seconds,
            max_entries=self.settings.cag_max_entries,
        )
        self.runtime = AgentRuntime(
            self.settings, self.registry, self.router, self.db,
            retriever=self.retriever, cache=self.cache, events=self.events,
        )
        # Persist every event once, at the source, so SSE replay after a refresh
        # works. Doing it here means no call site has to remember to log, which
        # is how replay silently goes empty when a new emit() is added.
        #
        # The bus is a process-wide singleton but the database is per-Spidy, so
        # the subscriber has to be re-pointed at the current db. Guarding on the
        # bus with a boolean looks right and is wrong: the first Spidy would own
        # the hook forever and every later instance would write to the wrong
        # database, silently dropping events.
        self._persister = _event_persister(self.db)
        self.events.on("*", self._persister)
        # Specialist team: several agents in parallel over one goal, with the
        # same router and tools underneath. Constructed here so the API and any
        # future transport get it without re-wiring.
        self.team = TeamRunner(self)
        self._tasks: dict[str, asyncio.Task] = {}

    # ------------------------------------------------------------------ #
    async def run(self, request: str, session_id: str = "",
                  project_root: str = "", **kw: Any):
        """Run a task, injecting the shared subsystems into the tool context."""
        rt = self.runtime

        original_ctx = rt.tool_context

        def tool_context_with_apps(state, approval_granted: bool = False):
            ctx = original_ctx(state, approval_granted)
            ctx.extra["retriever"] = self.retriever
            ctx.extra["router"] = self.router
            ctx.extra["cache"] = self.cache

            async def emit(name: str, **payload: Any) -> None:
                await self.events.emit(name, task_id=state.task_id, **payload)

            ctx.extra["emit"] = emit
            return ctx

        rt.tool_context = tool_context_with_apps  # type: ignore[method-assign]
        try:
            return await rt.run_task(request, session_id=session_id,
                                     project_root=project_root or None, **kw)
        finally:
            rt.tool_context = original_ctx  # type: ignore[method-assign]

    def run_background(self, request: str, **kw: Any) -> asyncio.Task:
        """Fire a task without awaiting it; the caller tracks the handle."""
        return asyncio.create_task(self.run(request, **kw))

    # ------------------------------------------------------------------ #
    async def chat(self, message: str, session_id: str = "", **kw: Any):
        """Chat is a task: same loop, conversational framing."""
        return await self.run(message, session_id=session_id, **kw)

    def cancel(self, task_id: str) -> None:
        self.runtime.cancel(task_id)

    def status(self) -> dict[str, Any]:
        return {
            "version": "1.0.0",
            "settings": self.settings.to_dict(),
            "tools": self.registry.stats(),
            "tool_count": len(self.registry.names()),
            "router": self.router.describe(),
            "router_health": self.router.health_report(),
            "rag": self.retriever.stats(),
            "cag": self.cache.stats(),
            "resumable": [t["task_id"] for t in self.db.resumable_tasks()],
        }

    def close(self) -> None:
        # Unregister before closing: a closed sqlite handle would raise on
        # every later event, and a lingering subscriber keeps this object (and
        # its db) alive through the bus.
        try:
            subs = self.events._subs.get("*", [])
            if self._persister in subs:
                subs.remove(self._persister)
        except Exception:
            pass
        try:
            self._conn.close()
        except Exception:
            pass
        self.db.close()


_APP: Spidy | None = None


def get_app(settings: Settings | None = None) -> Spidy:
    global _APP
    if _APP is None:
        _APP = Spidy(settings)
    return _APP


def reset_app() -> None:
    global _APP
    if _APP is not None:
        _APP.close()
    _APP = None
