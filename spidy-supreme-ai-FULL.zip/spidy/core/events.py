"""Async event bus.

The runtime never prints — it emits. The CLI, the web API, and the WebSocket
layer are all just subscribers, so the same task can be watched from several
places at once.
"""
from __future__ import annotations

import asyncio
import contextlib
from collections import deque
from typing import Any, AsyncIterator, Awaitable, Callable

from .schemas import Event

Subscriber = Callable[[Event], Awaitable[None] | None]


class EventBus:
    def __init__(self, history: int = 500) -> None:
        self._subs: dict[str, list[Subscriber]] = {}
        self._queues: dict[str, asyncio.Queue[Event]] = {}
        self._history: deque[Event] = deque(maxlen=history)
        self._task_id: str | None = None

    # ------------------------------------------------------------------ #
    def bind(self, task_id: str) -> None:
        """Scope subsequent emissions to a task."""
        self._task_id = task_id

    def on(self, event_type: str, fn: Subscriber) -> None:
        """Subscribe to one event type, or to every type with "*".

        A type-specific subscriber is stored only in its own bucket, and a
        "*" subscriber only in the wildcard bucket. Overlapping them (the old
        behaviour) meant every subscriber received every event and each one ran
        twice for its own type.
        """
        bucket = "*" if event_type == "*" else event_type
        self._subs.setdefault(bucket, []).append(fn)

    def stream(self, task_id: str) -> asyncio.Queue[Event]:
        q: asyncio.Queue[Event] = asyncio.Queue(maxsize=2000)
        self._queues[task_id] = q
        return q

    def close_stream(self, task_id: str) -> None:
        self._queues.pop(task_id, None)

    def history(self, limit: int = 100) -> list[Event]:
        return list(self._history)[-limit:]

    # ------------------------------------------------------------------ #
    async def emit(self, type_: str, **payload: Any) -> Event:
        ev = Event(
            type=type_,
            payload=payload,
            task_id=self._task_id or str(payload.get("task_id", "")),
            session_id=str(payload.get("session_id", "")),
        )
        self._history.append(ev)
        await self._dispatch(ev)
        return ev

    def emit_nowait(self, type_: str, **payload: Any) -> None:
        """Fire-and-forget emission for synchronous call sites."""
        ev = Event(
            type=type_,
            payload=payload,
            task_id=self._task_id or str(payload.get("task_id", "")),
        )
        self._history.append(ev)
        for sub in self._subs.get(type_, []) + self._subs.get("*", []):
            with contextlib.suppress(RuntimeError, TypeError):
                r = sub(ev)
                if asyncio.iscoroutine(r):
                    asyncio.get_event_loop().create_task(r)  # type: ignore[deprecated]
        q = self._queues.get(ev.task_id)
        if q is not None:
            with contextlib.suppress(asyncio.QueueFull):
                q.put_nowait(ev)

    async def _dispatch(self, ev: Event) -> None:
        # Per-type subscribers only see their type; "*" subscribers see all.
        # The two buckets are disjoint, so no dedup is needed here.
        for sub in self._subs.get(ev.type, []) + self._subs.get("*", []):
            try:
                r = sub(ev)
                if asyncio.iscoroutine(r):
                    await r
            except Exception:  # a bad subscriber must never kill the task
                continue
        q = self._queues.get(ev.task_id)
        if q is not None:
            with contextlib.suppress(asyncio.QueueFull):
                q.put_nowait(ev)

    async def __aiter__(self) -> AsyncIterator[Event]:  # pragma: no cover
        for ev in self._history:
            yield ev


# process-wide default bus
BUS = EventBus()
