"""Persistence: SQLite schema, sessions, tasks, checkpoints, audit log.

Everything the agent needs to resume after a crash lives here. A task is
durable the moment its state is written, so a browser refresh or a server
restart never loses work.
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Iterable

from .schemas import AgentPhase, AgentState, TaskResult, TaskStatus, new_id

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS sessions (
    session_id   TEXT PRIMARY KEY,
    title        TEXT,
    project_root TEXT,
    created_at   REAL NOT NULL,
    updated_at   REAL NOT NULL,
    meta         TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS tasks (
    task_id     TEXT PRIMARY KEY,
    session_id  TEXT NOT NULL,
    status      TEXT NOT NULL,
    phase       TEXT,
    goal        TEXT,
    request     TEXT,
    project_root TEXT,
    current_step INTEGER DEFAULT 0,
    retry_count INTEGER DEFAULT 0,
    repair_count INTEGER DEFAULT 0,
    tokens_spent INTEGER DEFAULT 0,
    tokens_saved INTEGER DEFAULT 0,
    created_at  REAL NOT NULL,
    updated_at  REAL NOT NULL,
    result      TEXT
);
CREATE INDEX IF NOT EXISTS idx_tasks_session ON tasks(session_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_tasks_status  ON tasks(status);

CREATE TABLE IF NOT EXISTS messages (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    role       TEXT NOT NULL,
    content    TEXT NOT NULL,
    task_id    TEXT,
    created_at REAL NOT NULL,
    meta       TEXT DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, id);

CREATE TABLE IF NOT EXISTS checkpoints (
    checkpoint_id TEXT PRIMARY KEY,
    task_id       TEXT NOT NULL,
    label         TEXT,
    state         TEXT NOT NULL,
    files         TEXT DEFAULT '[]',
    created_at    REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ckpt_task ON checkpoints(task_id, created_at DESC);

CREATE TABLE IF NOT EXISTS events (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT,
    type    TEXT NOT NULL,
    payload TEXT,
    ts      REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_task ON events(task_id, id);

CREATE TABLE IF NOT EXISTS audit (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    ts      REAL NOT NULL,
    actor   TEXT,
    action  TEXT NOT NULL,
    target  TEXT,
    outcome TEXT,
    detail  TEXT DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit(ts DESC);

CREATE TABLE IF NOT EXISTS memory (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    scope      TEXT NOT NULL,          -- episodic | semantic | preference
    key        TEXT,
    content    TEXT NOT NULL,
    project    TEXT,
    importance REAL DEFAULT 0.5,
    created_at REAL NOT NULL,
    accessed_at REAL
);
CREATE INDEX IF NOT EXISTS idx_memory_scope ON memory(scope, project);

CREATE TABLE IF NOT EXISTS artifacts (
    artifact_id TEXT PRIMARY KEY,
    task_id     TEXT,
    type        TEXT,
    path        TEXT NOT NULL,
    size        INTEGER DEFAULT 0,
    sha256      TEXT,
    created_at  REAL NOT NULL,
    meta        TEXT DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_artifacts_task ON artifacts(task_id);

CREATE TABLE IF NOT EXISTS docs (
    doc_id     TEXT PRIMARY KEY,
    source     TEXT NOT NULL,
    uri        TEXT,
    project    TEXT,
    sha256     TEXT NOT NULL,
    chunk_count INTEGER DEFAULT 0,
    indexed_at REAL NOT NULL,
    meta       TEXT DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_docs_sha ON docs(sha256);
CREATE INDEX IF NOT EXISTS idx_docs_project ON docs(project);

CREATE TABLE IF NOT EXISTS chunks (
    chunk_id   TEXT PRIMARY KEY,
    doc_id     TEXT NOT NULL,
    ord        INTEGER NOT NULL,
    text       TEXT NOT NULL,
    tokens     INTEGER DEFAULT 0,
    meta       TEXT DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_chunks_doc ON chunks(doc_id, ord);

CREATE TABLE IF NOT EXISTS cache (
    key        TEXT PRIMARY KEY,
    kind       TEXT NOT NULL,
    payload    TEXT NOT NULL,
    embedding  BLOB,
    tokens     INTEGER DEFAULT 0,
    hits       INTEGER DEFAULT 0,
    created_at REAL NOT NULL,
    expires_at REAL
);
CREATE INDEX IF NOT EXISTS idx_cache_kind ON cache(kind, expires_at);
"""


class Database:
    """Thread-safe SQLite wrapper. One connection guarded by a lock — SPIDY's
    write volume does not justify connection-pool complexity, and a lock keeps
    behaviour obvious."""

    def __init__(self, path: Path | str) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.executescript(SCHEMA)
            self._conn.commit()

    # ------------------------------------------------------------------ #
    def execute(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Cursor:
        with self._lock:
            cur = self._conn.execute(sql, tuple(params))
            self._conn.commit()
            return cur

    def query(self, sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
        with self._lock:
            return list(self._conn.execute(sql, tuple(params)).fetchall())

    def one(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Row | None:
        rows = self.query(sql, params)
        return rows[0] if rows else None

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    # ------------------------------------------------------------------ #
    # sessions
    # ------------------------------------------------------------------ #
    def create_session(self, title: str = "", project_root: str = "",
                       session_id: str | None = None) -> str:
        sid = session_id or new_id("sess_")
        now = time.time()
        self.execute(
            "INSERT OR REPLACE INTO sessions(session_id,title,project_root,created_at,updated_at)"
            " VALUES(?,?,?,?,?)", (sid, title, project_root, now, now),
        )
        return sid

    def touch_session(self, session_id: str) -> None:
        self.execute("UPDATE sessions SET updated_at=? WHERE session_id=?", (time.time(), session_id))

    def list_sessions(self, limit: int = 50) -> list[dict[str, Any]]:
        return [dict(r) for r in self.query(
            "SELECT * FROM sessions ORDER BY updated_at DESC LIMIT ?", (limit,))]

    # ------------------------------------------------------------------ #
    # messages
    # ------------------------------------------------------------------ #
    def add_message(self, session_id: str, role: str, content: str,
                    task_id: str = "", meta: dict | None = None) -> int:
        cur = self.execute(
            "INSERT INTO messages(session_id,role,content,task_id,created_at,meta)"
            " VALUES(?,?,?,?,?,?)",
            (session_id, role, content, task_id, time.time(), json.dumps(meta or {})),
        )
        self.touch_session(session_id)
        return int(cur.lastrowid or 0)

    def get_messages(self, session_id: str, limit: int = 200) -> list[dict[str, Any]]:
        rows = self.query(
            "SELECT * FROM messages WHERE session_id=? ORDER BY id ASC LIMIT ?",
            (session_id, limit),
        )
        out = []
        for r in rows:
            d = dict(r)
            d["meta"] = json.loads(d.get("meta") or "{}")
            out.append(d)
        return out

    # ------------------------------------------------------------------ #
    # tasks
    # ------------------------------------------------------------------ #
    def save_task(self, state: AgentState, tokens_spent: int = 0,
                  tokens_saved: int = 0) -> None:
        now = time.time()
        self.execute(
            "INSERT INTO tasks(task_id,session_id,status,phase,goal,request,project_root,"
            "current_step,retry_count,repair_count,tokens_spent,tokens_saved,created_at,updated_at)"
            " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            " ON CONFLICT(task_id) DO UPDATE SET status=excluded.status, phase=excluded.phase,"
            " goal=excluded.goal, current_step=excluded.current_step,"
            " retry_count=excluded.retry_count, repair_count=excluded.repair_count,"
            " tokens_spent=excluded.tokens_spent, tokens_saved=excluded.tokens_saved,"
            " updated_at=excluded.updated_at",
            (state.task_id, state.session_id, state.status.value, state.phase.value,
             state.goal, state.user_request, state.project_root, state.current_step,
             state.retry_count, state.repair_count, tokens_spent, tokens_saved,
             state.created_at, now),
        )
        self.execute("INSERT OR IGNORE INTO sessions(session_id,title,project_root,"
                     "created_at,updated_at) VALUES(?,?,?,?,?)",
                     (state.session_id, state.goal[:80], state.project_root or "",
                      state.created_at, now))

    def finish_task(self, task_id: str, result: TaskResult) -> None:
        self.execute(
            "UPDATE tasks SET status=?, phase='done', result=?, updated_at=? WHERE task_id=?",
            (result.status, json.dumps(result.to_dict(), default=str), time.time(), task_id),
        )

    def load_task(self, task_id: str) -> AgentState | None:
        row = self.one("SELECT * FROM tasks WHERE task_id=?", (task_id,))
        if not row:
            return None
        # Prefer the final checkpoint: it serializes the complete AgentState,
        # including the real observations list. The `result` column and the
        # periodic checkpoints are lossy for this purpose (result has no
        # observations; periodic checkpoints lag the run).
        ck = self.one(
            "SELECT state, label FROM checkpoints WHERE task_id=? "
            "ORDER BY created_at DESC LIMIT 1", (task_id,),
        )
        if ck and ck["label"] == "final":
            try:
                st = AgentState.from_dict(json.loads(ck["state"]))
                if st.observations:
                    return st
            except (TypeError, ValueError):
                pass
        finished = self.one("SELECT result FROM tasks WHERE task_id=?", (task_id,))
        if finished and finished["result"]:
            try:
                d = json.loads(finished["result"])
                st = AgentState(
                    task_id=row["task_id"], session_id=row["session_id"],
                    user_request=row["request"] or "",
                    project_root=row["project_root"])
                st.goal = d.get("goal", "")
                st.phase = AgentPhase.DONE
                st.plan = d.get("plan", [])
                st.verification = d.get("verification", {})
                st.created_files = [f for f in d.get("files_changed", [])]
                return st
            except (TypeError, ValueError, KeyError):
                pass
        if ck:
            try:
                return AgentState.from_dict(json.loads(ck["state"]))
            except (TypeError, ValueError):
                pass
        return AgentState(
            task_id=row["task_id"], session_id=row["session_id"],
            user_request=row["request"] or "", project_root=row["project_root"],
            goal=row["goal"] or "", current_step=row["current_step"] or 0,
            retry_count=row["retry_count"] or 0, repair_count=row["repair_count"] or 0,
            status=TaskStatus(row["status"]), created_at=row["created_at"],
        )

    def list_tasks(self, session_id: str = "", limit: int = 50) -> list[dict[str, Any]]:
        if session_id:
            rows = self.query(
                "SELECT * FROM tasks WHERE session_id=? ORDER BY created_at DESC LIMIT ?",
                (session_id, limit))
        else:
            rows = self.query(
                "SELECT * FROM tasks ORDER BY created_at DESC LIMIT ?", (limit,))
        return [dict(r) for r in rows]

    def resumable_tasks(self) -> list[dict[str, Any]]:
        return [dict(r) for r in self.query(
            "SELECT * FROM tasks WHERE status IN ('running','retrying','paused',"
            "'waiting_for_approval','queued') ORDER BY updated_at DESC")]

    # ------------------------------------------------------------------ #
    # checkpoints
    # ------------------------------------------------------------------ #
    def checkpoint(self, task_id: str, state: AgentState, label: str = "",
                   files: list[str] | None = None) -> str:
        cid = new_id("ckpt_")
        self.execute(
            "INSERT INTO checkpoints(checkpoint_id,task_id,label,state,files,created_at)"
            " VALUES(?,?,?,?,?,?)",
            (cid, task_id, label, json.dumps(state.to_dict(), default=str),
             json.dumps(files or []), time.time()),
        )
        return cid

    def list_checkpoints(self, task_id: str, limit: int = 50) -> list[dict[str, Any]]:
        return [dict(r) for r in self.query(
            "SELECT checkpoint_id,label,created_at,files FROM checkpoints"
            " WHERE task_id=? ORDER BY created_at DESC LIMIT ?", (task_id, limit))]

    def restore_checkpoint(self, checkpoint_id: str) -> AgentState | None:
        row = self.one("SELECT state FROM checkpoints WHERE checkpoint_id=?", (checkpoint_id,))
        if not row:
            return None
        try:
            return AgentState.from_dict(json.loads(row["state"]))
        except (TypeError, ValueError):
            return None

    # ------------------------------------------------------------------ #
    # events
    # ------------------------------------------------------------------ #
    def log_event(self, task_id: str, type_: str, payload: dict[str, Any]) -> None:
        self.execute(
            "INSERT INTO events(task_id,type,payload,ts) VALUES(?,?,?,?)",
            (task_id, type_, json.dumps(payload, default=str)[:8000], time.time()),
        )

    def get_events(self, task_id: str, limit: int = 500) -> list[dict[str, Any]]:
        out = []
        for r in self.query(
            "SELECT type,payload,ts FROM events WHERE task_id=? ORDER BY id ASC LIMIT ?",
            (task_id, limit)):
            d = dict(r)
            d["payload"] = json.loads(d.get("payload") or "{}")
            out.append(d)
        return out

    # ------------------------------------------------------------------ #
    # audit
    # ------------------------------------------------------------------ #
    def audit(self, action: str, actor: str = "agent", target: str = "",
              outcome: str = "ok", detail: dict[str, Any] | None = None) -> None:
        self.execute(
            "INSERT INTO audit(ts,actor,action,target,outcome,detail) VALUES(?,?,?,?,?,?)",
            (time.time(), actor, action, target, outcome,
             json.dumps(detail or {}, default=str)[:4000]),
        )

    def recent_audit(self, limit: int = 100) -> list[dict[str, Any]]:
        return [dict(r) for r in self.query(
            "SELECT * FROM audit ORDER BY id DESC LIMIT ?", (limit,))]

    # ------------------------------------------------------------------ #
    # memory
    # ------------------------------------------------------------------ #
    def remember(self, scope: str, content: str, key: str = "", project: str = "",
                 importance: float = 0.5) -> str:
        mid = new_id("mem_")
        self.execute(
            "INSERT INTO memory(id,scope,key,content,project,importance,created_at,accessed_at)"
            " VALUES(?,?,?,?,?,?,?,?)",
            (mid, scope, key, content, project, importance, time.time(), time.time()),
        )
        return mid

    def recall(self, scope: str = "", project: str = "", limit: int = 20,
               query: str = "") -> list[dict[str, Any]]:
        sql = "SELECT * FROM memory WHERE 1=1"
        params: list[Any] = []
        if scope:
            sql += " AND scope=?"
            params.append(scope)
        if project:
            sql += " AND (project=? OR project='')"
            params.append(project)
        if query:
            sql += " AND content LIKE ?"
            params.append(f"%{query}%")
        sql += " ORDER BY importance DESC, accessed_at DESC LIMIT ?"
        params.append(limit)
        return [dict(r) for r in self.query(sql, params)]

    def forget(self, memory_id: str) -> None:
        self.execute("DELETE FROM memory WHERE id=?", (memory_id,))

    # ------------------------------------------------------------------ #
    # artifacts
    # ------------------------------------------------------------------ #
    def record_artifact(self, path: str, type_: str = "file", task_id: str = "",
                        sha256: str = "", size: int = 0,
                        meta: dict[str, Any] | None = None) -> str:
        aid = new_id("art_")
        self.execute(
            "INSERT OR REPLACE INTO artifacts(artifact_id,task_id,type,path,size,sha256,"
            "created_at,meta) VALUES(?,?,?,?,?,?,?,?)",
            (aid, task_id, type_, str(path), size, sha256, time.time(),
             json.dumps(meta or {}, default=str)),
        )
        return aid

    def list_artifacts(self, task_id: str = "", limit: int = 100) -> list[dict[str, Any]]:
        if task_id:
            rows = self.query(
                "SELECT * FROM artifacts WHERE task_id=? ORDER BY created_at DESC LIMIT ?",
                (task_id, limit))
        else:
            rows = self.query(
                "SELECT * FROM artifacts ORDER BY created_at DESC LIMIT ?", (limit,))
        return [dict(r) for r in rows]


_DB: Database | None = None


def get_db() -> Database:
    global _DB
    if _DB is None:
        from .config import get_settings
        _DB = Database(get_settings().db_path)
    return _DB


def reset_db() -> None:
    global _DB
    if _DB is not None:
        _DB.close()
    _DB = None
