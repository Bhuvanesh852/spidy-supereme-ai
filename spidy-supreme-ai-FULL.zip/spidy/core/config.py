"""SPIDY Supreme AI — central configuration.

Everything is env-driven with sane offline-first defaults. No API key is ever
required to boot: SPIDY ships a native deterministic brain that works with zero
models running, and layers LLMs on top when they are reachable.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

# Providers SPIDY knows how to talk to. Kept here (not in brain/) so config can
# answer "is anything configured?" without importing the provider stack.
_PROVIDER_SLUGS = (
    "anthropic", "openai", "google", "openrouter", "groq", "together",
    "deepseek", "mistral", "xai", "fireworks", "cerebras",
)

# Any field whose name looks like a credential gets redacted in to_dict().
_SECRET_FIELD_RE = re.compile(
    r"(api_?key|secret|token|password|credential)", re.I)

# --------------------------------------------------------------------------- #
# paths
# --------------------------------------------------------------------------- #


def _default_home() -> Path:
    env = os.environ.get("SPIDY_HOME")
    base = Path(env).expanduser() if env else Path.home() / ".spidy"
    base.mkdir(parents=True, exist_ok=True)
    return base


def _load_dotenv(path: Path) -> None:
    """Tiny .env loader — avoids a hard dependency and never overrides real env."""
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        key = key.strip()
        val = val.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = val


_load_dotenv(Path(__file__).resolve().parents[2] / ".env")


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


def _env_bool(name: str, default: bool = False) -> bool:
    raw = _env(name, "").lower()
    if not raw:
        return default
    return raw in {"1", "true", "yes", "on", "y"}


def _env_map(name: str) -> dict[str, str]:
    """Parse `a=1,b=2` into `{"a": "1", "b": "2"}`. Malformed entries are dropped."""
    raw = _env(name, "")
    out: dict[str, str] = {}
    for pair in raw.split(","):
        if "=" not in pair:
            continue
        k, _, v = pair.partition("=")
        k, v = k.strip(), v.strip()
        if k and v:
            out[k] = v
    return out


def _env_int(name: str, default: int) -> int:
    try:
        return int(_env(name, str(default)) or default)
    except (TypeError, ValueError):
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(_env(name, str(default)) or default)
    except (TypeError, ValueError):
        return default


# --------------------------------------------------------------------------- #
# permission profiles
# --------------------------------------------------------------------------- #

PERMISSION_PROFILES = ("LOCKED", "SAFE", "BALANCED", "AUTONOMOUS")


@dataclass
class Settings:
    """Runtime settings snapshot. Build once, read everywhere."""

    # --- identity -------------------------------------------------------- #
    home: Path = field(default_factory=_default_home)

    # --- model routing --------------------------------------------------- #
    # Ordered preference. Native always exists and is the guaranteed floor.
    model_preference: list[str] = field(
        default_factory=lambda: [
            p
            for p in _env("SPIDY_MODEL_ORDER", "ollama,llamacpp,openrouter,cloud").split(",")
            if p
        ]
    )
    ollama_endpoint: str = field(default_factory=lambda: _env("OLLAMA_ENDPOINT", "http://127.0.0.1:11434"))
    llamacpp_base_url: str = field(default_factory=lambda: _env("LLAMACPP_BASE_URL", "http://127.0.0.1:8080"))
    openrouter_base_url: str = field(default_factory=lambda: _env("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1"))

    # Role -> model name. Users map these to whatever they actually run.
    model_roles: dict[str, str] = field(default_factory=dict)

    # --- provider credentials -------------------------------------------- #
    # Each key is optional; a provider with no key is simply not registered,
    # so there is no "enable" flag to keep in sync. `*_base_url` overrides let
    # any OpenAI-shaped gateway (LiteLLM, vLLM, a proxy) slot in without code.
    anthropic_api_key: str = field(default_factory=lambda: _env("ANTHROPIC_API_KEY"))
    anthropic_base_url: str = field(default_factory=lambda: _env("ANTHROPIC_BASE_URL", "https://api.anthropic.com"))
    openai_api_key: str = field(default_factory=lambda: _env("OPENAI_API_KEY"))
    openai_base_url: str = field(default_factory=lambda: _env("OPENAI_BASE_URL", "https://api.openai.com/v1"))
    # GEMINI_API_KEY is the name the AI Studio console actually shows; accept
    # both, with GOOGLE_API_KEY winning if someone sets both.
    google_api_key: str = field(default_factory=lambda: (
        _env("GOOGLE_API_KEY") or _env("GEMINI_API_KEY")))
    google_base_url: str = field(default_factory=lambda: _env(
        "GOOGLE_BASE_URL", "https://generativelanguage.googleapis.com/v1beta"))
    openrouter_api_key: str = field(default_factory=lambda: _env("OPENROUTER_API_KEY"))
    groq_api_key: str = field(default_factory=lambda: _env("GROQ_API_KEY"))
    groq_base_url: str = field(default_factory=lambda: _env("GROQ_BASE_URL", "https://api.groq.com/openai/v1"))
    together_api_key: str = field(default_factory=lambda: _env("TOGETHER_API_KEY"))
    together_base_url: str = field(default_factory=lambda: _env(
        "TOGETHER_BASE_URL", "https://api.together.xyz/v1"))
    deepseek_api_key: str = field(default_factory=lambda: _env("DEEPSEEK_API_KEY"))
    deepseek_base_url: str = field(default_factory=lambda: _env("DEEPSEEK_BASE_URL", "https://api.deepseek.com/v1"))
    mistral_api_key: str = field(default_factory=lambda: _env("MISTRAL_API_KEY"))
    mistral_base_url: str = field(default_factory=lambda: _env("MISTRAL_BASE_URL", "https://api.mistral.ai/v1"))
    xai_api_key: str = field(default_factory=lambda: _env("XAI_API_KEY"))
    xai_base_url: str = field(default_factory=lambda: _env("XAI_BASE_URL", "https://api.x.ai/v1"))
    fireworks_api_key: str = field(default_factory=lambda: _env("FIREWORKS_API_KEY"))
    fireworks_base_url: str = field(default_factory=lambda: _env(
        "FIREWORKS_BASE_URL", "https://api.fireworks.ai/inference/v1"))
    cerebras_api_key: str = field(default_factory=lambda: _env("CEREBRAS_API_KEY"))
    cerebras_base_url: str = field(default_factory=lambda: _env(
        "CEREBRAS_BASE_URL", "https://api.cerebras.ai/v1"))

    # Pin a model per provider ("openai=gpt-4o,google=gemini-2.0-flash").
    # Empty means: ask the provider what it serves, then use the catalog default.
    provider_models: dict[str, str] = field(
        default_factory=lambda: _env_map("SPIDY_PROVIDER_MODELS")
    )
    # Never contact a cloud provider, whatever keys are present.
    allow_cloud: bool = field(default_factory=lambda: _env_bool("SPIDY_ALLOW_CLOUD", True))

    request_timeout: float = field(default_factory=lambda: _env_float("SPIDY_REQUEST_TIMEOUT", 120.0))
    max_context_tokens: int = field(default_factory=lambda: _env_int("SPIDY_MAX_CONTEXT", 32768))

    # --- token economics -------------------------------------------------- #
    task_token_budget: int = field(default_factory=lambda: _env_int("SPIDY_TASK_TOKEN_BUDGET", 240_000))
    model_token_budget: int = field(default_factory=lambda: _env_int("SPIDY_MODEL_TOKEN_BUDGET", 200_000))
    tool_result_token_budget: int = field(default_factory=lambda: _env_int("SPIDY_TOOL_RESULT_BUDGET", 12_000))
    rag_token_budget: int = field(default_factory=lambda: _env_int("SPIDY_RAG_TOKEN_BUDGET", 4_000))
    memory_token_budget: int = field(default_factory=lambda: _env_int("SPIDY_MEMORY_TOKEN_BUDGET", 2_000))
    output_token_budget: int = field(default_factory=lambda: _env_int("SPIDY_OUTPUT_TOKEN_BUDGET", 4_000))
    cache_hit_credit: float = field(default_factory=lambda: _env_float("SPIDY_CACHE_HIT_CREDIT", 0.9))

    # --- agent behaviour -------------------------------------------------- #
    permission_mode: str = field(default_factory=lambda: _env("SPIDY_PERMISSION", "BALANCED").upper())
    max_repair_rounds: int = field(default_factory=lambda: _env_int("SPIDY_MAX_REPAIR", 3))
    max_plan_steps: int = field(default_factory=lambda: _env_int("SPIDY_MAX_PLAN_STEPS", 24))
    max_tool_retries: int = field(default_factory=lambda: _env_int("SPIDY_MAX_TOOL_RETRIES", 2))
    default_tool_timeout: int = field(default_factory=lambda: _env_int("SPIDY_TOOL_TIMEOUT", 120))
    enable_parallel_reads: bool = field(default_factory=lambda: _env_bool("SPIDY_PARALLEL_READS", True))
    offline_only: bool = field(default_factory=lambda: _env_bool("SPIDY_OFFLINE_ONLY", False))

    # --- knowledge -------------------------------------------------------- #
    embedding_model: str = field(default_factory=lambda: _env("SPIDY_EMBEDDING_MODEL", "spidy-hash-ngram-384"))
    embedding_dim: int = field(default_factory=lambda: _env_int("SPIDY_EMBEDDING_DIM", 384))
    rag_top_k: int = field(default_factory=lambda: _env_int("SPIDY_RAG_TOP_K", 8))
    rag_candidate_k: int = field(default_factory=lambda: _env_int("SPIDY_RAG_CANDIDATES", 40))
    rag_chunk_size: int = field(default_factory=lambda: _env_int("SPIDY_RAG_CHUNK", 900))
    rag_chunk_overlap: int = field(default_factory=lambda: _env_int("SPIDY_RAG_OVERLAP", 140))
    rerank_enabled: bool = field(default_factory=lambda: _env_bool("SPIDY_RERANK", True))

    # --- cag -------------------------------------------------------------- #
    cag_enabled: bool = field(default_factory=lambda: _env_bool("SPIDY_CAG", True))
    cag_similarity_threshold: float = field(default_factory=lambda: _env_float("SPIDY_CAG_THRESHOLD", 0.86))
    cag_ttl_seconds: int = field(default_factory=lambda: _env_int("SPIDY_CAG_TTL", 86_400))
    cag_max_entries: int = field(default_factory=lambda: _env_int("SPIDY_CAG_MAX", 2048))

    # --- safety ----------------------------------------------------------- #
    redact_secrets: bool = field(default_factory=lambda: _env_bool("SPIDY_REDACT", True))
    allow_network: bool = field(default_factory=lambda: _env_bool("SPIDY_ALLOW_NETWORK", True))
    command_timeout: int = field(default_factory=lambda: _env_int("SPIDY_COMMAND_TIMEOUT", 120))
    max_output_bytes: int = field(default_factory=lambda: _env_int("SPIDY_MAX_OUTPUT_BYTES", 200_000))
    audit_enabled: bool = field(default_factory=lambda: _env_bool("SPIDY_AUDIT", True))
    workspace_root: Path = field(
        default_factory=lambda: Path(_env("SPIDY_WORKSPACE", str(Path.home()))).expanduser()
    )

    # --- server ------------------------------------------------------------ #
    host: str = field(default_factory=lambda: _env("SPIDY_HOST", "127.0.0.1"))
    port: int = field(default_factory=lambda: _env_int("SPIDY_PORT", 5000))

    # ------------------------------------------------------------------ #
    def __post_init__(self) -> None:
        if self.permission_mode not in PERMISSION_PROFILES:
            self.permission_mode = "BALANCED"
        # Derived dirs, all inside the home so the app is self-contained.
        for sub in ("data", "vectors", "artifacts", "logs", "checkpoints", "cache", "models"):
            (self.home / sub).mkdir(parents=True, exist_ok=True)

        # Role defaults are provider-scoped, not global. A hardcoded
        # "gemma3:4b" here used to be sent to OpenAI and Anthropic too, which
        # 404s on every call. Roles are now "provider:model", and a role with
        # no provider prefix only applies to local providers.
        if not self.model_roles:
            self.model_roles = {
                "reasoning": _env("SPIDY_MODEL_REASONING", "ollama:gemma3:4b"),
                "coding": _env("SPIDY_MODEL_CODING", "ollama:gemma3:4b"),
                "fast": _env("SPIDY_MODEL_FAST", "ollama:gemma3:4b"),
                "vision": _env("SPIDY_MODEL_VISION", "ollama:gemma3:4b"),
                "embedding": _env("SPIDY_MODEL_EMBEDDING", "ollama:nomic-embed-text"),
            }

    # ------------------------------------------------------------------ #
    @property
    def db_path(self) -> Path:
        return self.home / "data" / "spidy.db"

    @property
    def vector_dir(self) -> Path:
        return self.home / "vectors"

    @property
    def artifact_dir(self) -> Path:
        return self.home / "artifacts"

    @property
    def log_dir(self) -> Path:
        return self.home / "logs"

    @property
    def checkpoint_dir(self) -> Path:
        return self.home / "checkpoints"

    @property
    def model_dir(self) -> Path:
        return self.home / "models"

    def has_cloud_keys(self) -> bool:
        return any(bool(getattr(self, f"{p}_api_key", ""))
                   for p in _PROVIDER_SLUGS)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["home"] = str(self.home)
        d["workspace_root"] = str(self.workspace_root)
        # Never leak key material. Matched by shape, not by a hand-kept list:
        # a new provider added without updating that list would otherwise ship
        # its key to every /api/settings caller.
        for k in list(d):
            if _SECRET_FIELD_RE.search(k) and d[k]:
                d[k] = "***set***"
        return d

    def redacted(self) -> dict[str, Any]:
        return self.to_dict()


_SETTINGS: Settings | None = None


def get_settings() -> Settings:
    global _SETTINGS
    if _SETTINGS is None:
        _SETTINGS = Settings()
    return _SETTINGS


def reset_settings() -> None:
    """Test hook — forces a fresh snapshot."""
    global _SETTINGS
    _SETTINGS = None
