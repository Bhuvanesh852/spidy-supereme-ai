"""Token economics — the module that makes SPIDY cheap.

Three ideas do most of the work:

1. **Measure everything.** Every model call, tool result, and RAG chunk is
   metered against a task budget.
2. **Compress before you spend.** Tool output is aggressively trimmed, and old
   observations are collapsed into running summaries rather than replayed.
3. **Never pay twice.** CAG turns a repeat question into a near-zero-token hit.

The tokenizer is a cheap, dependency-free estimator. It is deliberately an
*estimate* — exact counting costs more time than it saves, and the number only
needs to be good enough to steer budgeting decisions.
"""
from __future__ import annotations

import re
import time
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Iterable

from .schemas import now

_WORD_RE = re.compile(r"\w+|[^\w\s]")


def estimate_tokens(text: str) -> int:
    """Rough BPE-equivalent token count.

    CJK and other dense scripts are counted per-character because they pack
    roughly one token per glyph; Latin text lands near 4 chars/token.
    """
    if not text:
        return 0
    cjk = sum(1 for ch in text if "぀" <= ch <= "鿿" or "가" <= ch <= "힯")
    rest = len(text) - cjk
    return max(1, int(cjk * 0.9 + rest / 3.6))


def truncate_middle(text: str, max_tokens: int) -> tuple[str, bool]:
    """Keep the head and tail; drop the middle. Tool errors live in both ends."""
    limit = max_tokens * 4
    if len(text) <= limit:
        return text, False
    head = int(limit * 0.65)
    tail = limit - head
    elided = len(text) - limit
    return f"{text[:head]}\n\n... [{elided} chars elided by token governor] ...\n\n{text[-tail:]}", True


def squeeze_whitespace(text: str) -> str:
    """Reclaim tokens from tool output without losing information."""
    t = text.replace("\r\n", "\n")
    t = re.sub(r"[ \t]+\n", "\n", t)
    t = re.sub(r"\n{4,}", "\n\n\n", t)
    t = re.sub(r"(?<=\n) {2,}", "  ", t)
    return t


# --------------------------------------------------------------------------- #


@dataclass
class UsageRecord:
    category: str            # model | tool | rag | memory | cache
    label: str
    tokens: int
    cost: float = 0.0
    cached: bool = False
    at: float = field(default_factory=now)


@dataclass
class TokenBudget:
    """Per-task token governor with sub-budgets and running compression."""

    total: int = 240_000
    model: int = 200_000
    tool_result: int = 12_000
    rag: int = 4_000
    memory: int = 2_000
    output: int = 4_000

    spent: dict[str, int] = field(default_factory=dict)
    saved: dict[str, int] = field(default_factory=dict)
    records: list[UsageRecord] = field(default_factory=list)
    cache_hits: int = 0
    cache_misses: int = 0
    _billed: dict[str, int] = field(default_factory=dict)

    # ------------------------------------------------------------------ #
    @staticmethod
    def limits(category: str) -> int:
        return {
            "model": 200_000,
            "tool": 12_000,
            "rag": 4_000,
            "memory": 2_000,
            "output": 4_000,
        }.get(category, 8_000)

    # ------------------------------------------------------------------ #
    def used(self, category: str) -> int:
        return self.spent.get(category, 0)

    def saved_total(self) -> int:
        return sum(self.saved.values())

    def total_spent(self) -> int:
        return sum(self.spent.values())

    def remaining(self) -> int:
        return max(0, self.total - self.total_spent())

    def remaining_for(self, category: str) -> int:
        room = self.remaining()
        cap = self.limits(category)
        return max(0, min(room, cap - self.used(category)))

    def exhausted(self, category: str | None = None) -> bool:
        if category:
            return self.used(category) >= self.limits(category)
        return self.remaining() <= 0

    # ------------------------------------------------------------------ #
    def spend(self, category: str, tokens: int, label: str = "", cost: float = 0.0) -> int:
        """Record real spend. Returns the effective (capped) amount."""
        if tokens <= 0:
            return 0
        cap = self.limits(category)
        effective = tokens
        if self.used(category) + tokens > cap:
            effective = max(0, cap - self.used(category))
        self.spent[category] = self.used(category) + effective
        self.records.append(UsageRecord(category, label, effective, cost))
        return effective

    def credit(self, category: str, tokens: int, label: str = "") -> int:
        """Record tokens avoided by a cache hit. Never goes negative."""
        if tokens <= 0:
            return 0
        cat = self.spent.get(category, 0)
        recovered = min(tokens, cat)
        self.spent[category] = max(0, cat - recovered)
        self.saved[category] = self.saved.get(category, 0) + recovered
        self.records.append(UsageRecord(category, label, -recovered, 0.0, cached=True))
        return recovered

    def hit(self) -> None:
        self.cache_hits += 1

    def miss(self) -> None:
        self.cache_misses += 1

    # ------------------------------------------------------------------ #
    def fit_text(self, text: str, category: str = "tool") -> str:
        """Compress `text` down to the category budget, accounting for what we save."""
        if not text:
            return ""
        room = self.remaining_for(category)
        if room <= 0:
            self.saved[category] = self.saved.get(category, 0) + estimate_tokens(text)
            return "[token budget exhausted for this category]"
        squeezed = squeeze_whitespace(text)
        squeezed = re.sub(r"\n\s*\n\s*\n+", "\n\n", squeezed)
        if estimate_tokens(squeezed) <= room:
            self.spend(category, estimate_tokens(squeezed))
            return squeezed
        out, cut = truncate_middle(squeezed, room)
        original = estimate_tokens(text)
        final = estimate_tokens(out)
        self.spend(category, final)
        self.saved[category] = self.saved.get(category, 0) + max(0, original - final)
        return out

    def fit_list(self, items: Iterable[str], category: str = "rag") -> list[str]:
        out: list[str] = []
        for it in items:
            if self.remaining_for(category) <= 0:
                self.saved[category] = self.saved.get(category, 0) + estimate_tokens(it)
                continue
            piece = self.fit_text(it, category)
            if piece and piece != "[token budget exhausted for this category]":
                out.append(piece)
        return out

    # ------------------------------------------------------------------ #
    def summary(self) -> dict[str, Any]:
        hit_rate = (
            self.cache_hits / (self.cache_hits + self.cache_misses)
            if (self.cache_hits + self.cache_misses)
            else 0.0
        )
        return {
            "total_spent": self.total_spent(),
            "saved": self.saved_total(),
            "remaining": self.remaining(),
            "by_category": dict(self.spent),
            "saved_by_category": dict(self.saved),
            "cache_hits": self.cache_hits,
            "cache_misses": self.cache_misses,
            "cache_hit_rate": round(hit_rate, 3),
            # The headline number: work done per token actually spent.
            "effective_token_efficiency": round(
                (self.total_spent() + self.saved_total())
                / max(1, self.total_spent()),
                2,
            ),
        }


# --------------------------------------------------------------------------- #


def compress_observations(observations: list[dict[str, Any]], keep_recent: int = 4) -> str:
    """Collapse old observations into a digest so context does not grow linearly.

    The most recent few stay verbatim because they are what the next step
    reasons about; everything older becomes one deduped line.
    """
    if not observations:
        return ""
    if len(observations) <= keep_recent:
        return "\n".join(f"- {o.get('text', '')}" for o in observations)

    older = observations[:-keep_recent]
    recent = observations[-keep_recent:]

    seen: set[str] = set()
    digest: list[str] = []
    for o in older:
        t = str(o.get("text", "")).strip()
        if not t:
            continue
        key = t[:110].lower()
        if key in seen:
            continue
        seen.add(key)
        digest.append(f"- {t[:220]}")
    collapsed = "\n".join(digest[-40:])
    tail = "\n".join(f"- {o.get('text', '')}" for o in recent)
    return (
        f"Earlier findings (deduplicated, {len(older)} entries):\n{collapsed}\n"
        f"Most recent:\n{tail}"
    )


def dedupe_tool_output(stdout: str, seen: dict[str, str], max_repeats: int = 2) -> str:
    """Drop output identical to something already observed. Polling loops are
    the single biggest source of wasted tokens in coding agents."""
    key = stdout.strip()[:200]
    if not key:
        return ""
    n = seen.get(key, 0) + 1
    seen[key] = n
    if n > max_repeats:
        return f"[output identical to {n - 1} earlier observations — omitted]"
    return stdout
