"""Canonical data contracts for the SPIDY agent runtime.

Every tool, agent, and API surface speaks these types. They are deliberately
dependency-light (stdlib dataclasses) so the runtime can be imported without
FastAPI, torch, or any model present.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any


def new_id(prefix: str = "") -> str:
    return f"{prefix}{uuid.uuid4().hex[:16]}"


def now() -> float:
    return time.time()


# --------------------------------------------------------------------------- #
# enums
# --------------------------------------------------------------------------- #


class RiskLevel(str, Enum):
    READ = "READ"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    DESTRUCTIVE = "DESTRUCTIVE"


RISK_ORDER = {
    RiskLevel.READ: 0,
    RiskLevel.LOW: 1,
    RiskLevel.MEDIUM: 2,
    RiskLevel.HIGH: 3,
    RiskLevel.DESTRUCTIVE: 4,
}


class ToolStatus(str, Enum):
    SUCCESS = "success"
    ERROR = "error"
    DENIED = "denied"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"
    SKIPPED = "skipped"
    NEEDS_APPROVAL = "needs_approval"


class TaskStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    PAUSED = "paused"
    WAITING_FOR_APPROVAL = "waiting_for_approval"
    RETRYING = "retrying"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class AgentPhase(str, Enum):
    INTAKE = "intake"
    UNDERSTAND = "understand"
    PLAN = "plan"
    APPROVAL = "approval"
    CONTEXT = "context"
    ACT = "act"
    OBSERVE = "observe"
    RECOVER = "recover"
    REPLAN = "replan"
    REPAIR = "repair"
    VERIFY = "verify"
    FINALIZE = "finalize"
    DONE = "done"


class ErrorClass(str, Enum):
    """Drives the retry/repair decision — see `FailureClassifier`."""

    TRANSIENT = "transient"          # network blip, provider 5xx -> retry
    RECOVERABLE = "recoverable"      # bad args, test failure, compile error -> repair
    NON_RECOVERABLE = "non_recoverable"  # policy denial, permission -> stop
    USER_ABORT = "user_abort"


# --------------------------------------------------------------------------- #
# tool contracts
# --------------------------------------------------------------------------- #


@dataclass
class ToolSpec:
    """Schema + policy for one tool. Nothing runs without one of these."""

    name: str
    description: str
    input_schema: dict[str, Any] = field(default_factory=dict)
    permission: str = "tools.execute"
    risk_level: RiskLevel = RiskLevel.LOW
    timeout_seconds: int = 120
    supports_dry_run: bool = False
    tags: list[str] = field(default_factory=list)
    # Tools that only read are safe to fan out concurrently.
    idempotent: bool = False

    def to_model_schema(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.input_schema,
        }

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["risk_level"] = self.risk_level.value
        return d


@dataclass
class ToolResult:
    """The single normalized envelope every tool returns.

    This is what makes the agent loop provider-independent: no matter whether a
    tool is local Python, a subprocess, or a remote MCP call, the runtime sees
    the same shape.
    """

    tool: str
    status: ToolStatus = ToolStatus.SUCCESS
    exit_code: int | None = None
    stdout: str = ""
    stderr: str = ""
    data: dict[str, Any] = field(default_factory=dict)
    error_type: str | None = None
    message: str = ""
    retryable: bool = False
    duration_ms: int = 0
    artifacts: list[dict[str, Any]] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    truncated: bool = False

    @property
    def ok(self) -> bool:
        return self.status in (ToolStatus.SUCCESS, ToolStatus.SKIPPED)

    def to_dict(self) -> dict[str, Any]:
        return {
            "tool": self.tool,
            "status": self.status.value,
            "exit_code": self.exit_code,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "data": self.data,
            "error_type": self.error_type,
            "message": self.message,
            "retryable": self.retryable,
            "duration_ms": self.duration_ms,
            "artifacts": self.artifacts,
            "metadata": self.metadata,
            "truncated": self.truncated,
        }

    def render(self, max_chars: int = 4000) -> str:
        """Compact, model-facing rendering. Saves tokens on the biggest cost centre."""
        if self.ok:
            body = self.stdout or self.message or self._data_preview(max_chars)
            if len(body) > max_chars:
                body = body[:max_chars] + f"\n... [{len(body) - max_chars} chars elided]"
            return body
        return f"[{self.tool} FAILED: {self.error_type or self.status.value}] {self.message}".strip()

    def _data_preview(self, max_chars: int = 4000) -> str:
        import json

        if not self.data:
            return ""
        try:
            return json.dumps(self.data, default=str)[:max_chars]
        except (TypeError, ValueError):
            return str(self.data)[:max_chars]


# --------------------------------------------------------------------------- #
# planning
# --------------------------------------------------------------------------- #


@dataclass
class PlanStep:
    id: str
    action: str                      # inspect | search | read | edit | run | test | verify | research | create ...
    target: str = ""
    rationale: str = ""
    tool_hint: str = ""
    risk: RiskLevel = RiskLevel.LOW
    depends_on: list[str] = field(default_factory=list)
    parallel_safe: bool = True
    done: bool = False
    result_summary: str = ""
    approval_required: bool = False

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["risk"] = self.risk.value
        return d

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "PlanStep":
        d = dict(d)
        d["risk"] = RiskLevel(d.get("risk", RiskLevel.LOW))
        known = {f for f in PlanStep.__dataclass_fields__}
        return PlanStep(**{k: v for k, v in d.items() if k in known})


@dataclass
class Plan:
    goal: str
    steps: list[PlanStep] = field(default_factory=list)
    constraints: list[str] = field(default_factory=list)
    success_criteria: list[str] = field(default_factory=list)
    notes: str = ""
    revision: int = 1

    def to_dict(self) -> dict[str, Any]:
        return {
            "goal": self.goal,
            "steps": [s.to_dict() for s in self.steps],
            "constraints": self.constraints,
            "success_criteria": self.success_criteria,
            "notes": self.notes,
            "revision": self.revision,
        }


# --------------------------------------------------------------------------- #
# agent state
# --------------------------------------------------------------------------- #


@dataclass
class AgentState:
    """The whole world for one task. Serialized to SQLite so it survives restarts."""

    task_id: str = field(default_factory=lambda: new_id("task_"))
    session_id: str = field(default_factory=lambda: new_id("sess_"))
    user_request: str = ""
    project_root: str | None = None

    goal: str = ""
    constraints: list[str] = field(default_factory=list)
    plan: list[dict[str, Any]] = field(default_factory=list)
    current_step: int = 0
    phase: AgentPhase = AgentPhase.INTAKE

    context_refs: list[str] = field(default_factory=list)
    memory_refs: list[str] = field(default_factory=list)
    retrieved_sources: list[dict[str, Any]] = field(default_factory=list)

    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    observations: list[dict[str, Any]] = field(default_factory=list)
    errors: list[dict[str, Any]] = field(default_factory=list)

    modified_files: list[str] = field(default_factory=list)
    created_files: list[str] = field(default_factory=list)
    deleted_files: list[str] = field(default_factory=list)

    tests: list[dict[str, Any]] = field(default_factory=list)
    verification: dict[str, Any] = field(default_factory=dict)

    approval_required: bool = False
    approval_status: str = "not_required"

    retry_count: int = 0
    repair_count: int = 0
    status: TaskStatus = TaskStatus.QUEUED

    token_budget: int = 0
    model_route: str = ""
    created_at: float = field(default_factory=now)
    updated_at: float = field(default_factory=now)

    # ---- helpers ------------------------------------------------------- #
    @property
    def plan_steps(self) -> list[PlanStep]:
        return [PlanStep.from_dict(s) for s in self.plan]

    def set_plan_steps(self, steps: list[PlanStep]) -> None:
        self.plan = [s.to_dict() for s in steps]

    def record_tool(self, name: str, result: ToolResult) -> None:
        self.tool_calls.append(
            {
                "tool": name,
                "status": result.status.value,
                "duration_ms": result.duration_ms,
                "at": now(),
            }
        )
        # Keep the ring buffer bounded — long tasks must not grow unbounded.
        if len(self.tool_calls) > 400:
            del self.tool_calls[:-400]
        if not result.ok:
            self.errors.append(
                {
                    "tool": name,
                    "type": result.error_type or result.status.value,
                    "message": result.message,
                    "at": now(),
                }
            )

    def record_observation(self, text: str, step_id: str | None = None) -> None:
        self.observations.append({"step": step_id, "text": text, "at": now()})
        if len(self.observations) > 300:
            del self.observations[:-300]

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["status"] = self.status.value
        d["phase"] = self.phase.value
        return d

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "AgentState":
        known = {f for f in AgentState.__dataclass_fields__}
        data = {k: v for k, v in d.items() if k in known}
        data["status"] = TaskStatus(data.get("status", TaskStatus.QUEUED))
        data["phase"] = AgentPhase(data.get("phase", AgentPhase.INTAKE))
        return AgentState(**data)


# --------------------------------------------------------------------------- #
# timeline events (what the UI renders)
# --------------------------------------------------------------------------- #


@dataclass
class Event:
    type: str
    payload: dict[str, Any] = field(default_factory=dict)
    task_id: str = ""
    session_id: str = ""
    id: str = field(default_factory=lambda: new_id("evt_"))
    ts: float = field(default_factory=now)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# --------------------------------------------------------------------------- #
# model contracts
# --------------------------------------------------------------------------- #


@dataclass
class LLMMessage:
    role: str                 # system | user | assistant | tool
    content: str = ""
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    name: str | None = None
    tool_call_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"role": self.role, "content": self.content}
        if self.tool_calls:
            d["tool_calls"] = self.tool_calls
        if self.name:
            d["name"] = self.name
        if self.tool_call_id:
            d["tool_call_id"] = self.tool_call_id
        return d


@dataclass
class LLMResponse:
    text: str = ""
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    provider: str = "native"
    model: str = "native"
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cached: bool = False
    latency_ms: int = 0
    error: str | None = None
    finish_reason: str = "stop"

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["total_tokens"] = self.total_tokens
        return d


@dataclass
class ModelCapability:
    name: str
    provider: str
    supports_tools: bool = False
    supports_json_schema: bool = False
    supports_vision: bool = False
    supports_reasoning: bool = True
    supports_streaming: bool = True
    context_window: int = 32768
    priority: int = 10
    cost_per_1k: float = 0.0
    local: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# --------------------------------------------------------------------------- #
# final result
# --------------------------------------------------------------------------- #


@dataclass
class TaskResult:
    task_id: str
    goal: str
    status: str = "completed"
    answer: str = ""
    plan: list[dict[str, Any]] = field(default_factory=list)
    files_changed: list[str] = field(default_factory=list)
    artifacts: list[dict[str, Any]] = field(default_factory=list)
    sources: list[dict[str, Any]] = field(default_factory=list)
    verification: dict[str, Any] = field(default_factory=dict)
    timeline: list[dict[str, Any]] = field(default_factory=list)
    token_usage: dict[str, Any] = field(default_factory=dict)
    cache: dict[str, Any] = field(default_factory=dict)
    error: str | None = None
    duration_ms: int = 0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
