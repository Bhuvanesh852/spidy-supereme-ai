"""HTTP routes.

Thin adapter over the kernel. Handlers call `Spidy` (run/registry/db/router/
retriever/cache) and the tenancy dependency — they never import from
`spidy.tools.*` or `spidy.brain.*` directly, which is what keeps the kernel
swappable and lets a CLI or bot reuse these exact handlers.

The guiding rule for error handling: a failing TASK is not an HTTP error. The
loop catches its own exceptions, emits `task.failed`, and returns a FAILED
result. Handlers only raise for genuinely bad requests.
"""
from __future__ import annotations

import asyncio
import json
import mimetypes
import time
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import FileResponse, StreamingResponse

from ..app import Spidy, get_app
from ..core.events import Event
from ..core.schemas import TaskStatus, new_id
from .schemas import (ApproveRequest, ChatRequest, FileWriteRequest,
                      IndexRequest, MemoryRequest, result_view, task_view)
from .tenancy import ApiError, TenantContext, assert_shell_allowed, rate_limit, resolve_tenant

router = APIRouter(prefix="/api")

# Live task handles, so /cancel and the SSE pump can reach a running loop.
_TASKS: dict[str, asyncio.Task] = {}
_RESULTS: dict[str, Any] = {}


def _spidy() -> Spidy:
    return get_app()


# --------------------------------------------------------------------------- #
# health / metadata
# --------------------------------------------------------------------------- #


@router.get("/health")
async def health() -> dict[str, Any]:
    import os

    app = _spidy()
    st = app.status()
    providers = await app.router.probe()
    # Native always counts: it's the guaranteed floor that keeps tasks completing
    # offline. A reachable *model* provider additionally unlocks generation.
    native_ok = providers.get("native", {}).get("reachable", False)
    live = [n for n, p in providers.items() if p["reachable"] and p["models"]]
    has_llm = any(n != "native" for n in live)
    return {
        "status": "ok",
        "version": st.get("version", "1.0.0"),
        "mode": os.environ.get("SPIDY_MODE", "local"),
        "sandbox": os.environ.get("SPIDY_SANDBOX", "local"),
        "allow_cloud": bool(getattr(app.settings, "allow_cloud", True)),
        "offline_only": bool(getattr(app.settings, "offline_only", False)),
        "providers": providers,
        "models_available": live,
        "has_llm": has_llm,
        "native_floor": native_ok,
        # The offline badge is driven by exactly this flag: true when no real
        # LLM is reachable and we're running on the native engine only.
        "offline_mode": not has_llm,
        "tools": st.get("tool_count", 0),
        "rag": st.get("rag", {}),
        "cag": st.get("cag", {}),
        "db_ok": True,
        "uptime_s": int(time.time() - _START),
    }

_START = time.time()


@router.get("/tools")
async def list_tools(tag: str = Query(""),
                     ctx: TenantContext = Depends(resolve_tenant)) -> list[dict[str, Any]]:
    app = _spidy()
    specs = app.registry.specs()
    if tag:
        specs = [s for s in specs if tag in (s.tags or [])]
    shell_blocked = False
    try:
        assert_shell_allowed(ctx)   # sets the flag rather than raising
    except ApiError:
        shell_blocked = True
    out = []
    for s in specs:
        is_shell = "shell" in (s.tags or [])
        out.append({
            "name": s.name, "description": s.description,
            "risk_level": getattr(s.risk_level, "value", str(s.risk_level)),
            "idempotent": s.idempotent, "tags": s.tags or [],
            "input_schema": s.input_schema,
            # Surface availability so the UI can grey out tools the sandbox
            # policy refuses, instead of letting the user discover it on click.
            "available": not (is_shell and shell_blocked),
        })
    return out


@router.get("/models")
async def list_models() -> list[dict[str, Any]]:
    """Every provider SPIDY knows about, with its live status and model list.

    The catalog is returned even for providers with no key, so the UI can show
    what adding a key would unlock instead of hiding the option entirely.
    """
    from ..brain.catalog import PROVIDERS, default_model_for

    app = _spidy()
    probe = await app.router.probe()
    out = []
    for slug, spec in sorted(PROVIDERS.items(), key=lambda t: t[1].priority):
        live = probe.get(slug, {})
        listed = list(live.get("models") or [])
        catalog = [m.id for m in spec.models]
        has_key = bool(getattr(app.settings, spec.key_field, ""))
        # Catalog models are shown only to advertise what a key *would* unlock.
        # Falling back to them for a key that was rejected would list models
        # that cannot be called, which is the one thing this screen must not do.
        show_catalog = (not listed) and bool(catalog) and (spec.kind == "local" or not has_key)
        out.append({
            "slug": slug,
            "label": spec.label,
            "kind": spec.kind,
            "local": spec.kind == "local",
            "key_env": spec.key_env,
            "configured": has_key if spec.kind != "local" else True,
            "reachable": bool(live.get("reachable", False)),
            "models": listed or (catalog if show_catalog else []),
            "models_from_catalog": show_catalog,
            "default_model": default_model_for(app.settings, slug),
            "priority": spec.priority,
            "docs": spec.docs,
            "degraded": live.get("degraded", False),
            "error": live.get("error", ""),
        })
    return out


@router.get("/providers")
async def list_providers_route() -> list[dict[str, Any]]:
    """The static catalog, independent of live connectivity."""
    from ..brain.catalog import list_providers
    return [p.to_dict() for p in list_providers()]


# --------------------------------------------------------------------------- #
# chat + tasks
# --------------------------------------------------------------------------- #


@router.get("/specialists")
async def list_specialists_route() -> list[dict[str, Any]]:
    """The specialist roster, with which tools each one may actually touch."""
    app = _spidy()
    real = set(app.registry.names())
    out = []
    for spec in app.team.roster():
        allowed = spec.pop("allowed_tools", [])
        spec["tools_available"] = [t for t in allowed if t in real]
        # Surface anything the allowlist names but the registry lacks: that is
        # a definition bug, and hiding it makes it undebuggable.
        spec["tools_missing"] = [t for t in allowed if t not in real]
        out.append(spec)
    return out


@router.post("/team/run")
async def run_team(req: ChatRequest,
                    ctx: TenantContext = Depends(resolve_tenant)) -> dict[str, Any]:
    """Run several specialists in parallel over one goal."""
    rate_limit(ctx)
    app = _spidy()
    result = await app.team.run(req.message, limit=3)
    return result.to_dict()


@router.post("/chat")
async def chat(req: ChatRequest,
               ctx: TenantContext = Depends(resolve_tenant)) -> dict[str, Any]:
    rate_limit(ctx)
    app = _spidy()
    session_id = req.session_id or app.db.create_session(title=req.message[:80])
    # Mint the task_id up front so the client can subscribe to SSE, cancel, and
    # fetch the result by a real id rather than a session stand-in.
    task_id = new_id("task_")

    async def runner() -> None:
        try:
            # Fail closed: in server mode without a container sandbox, refuse
            # before the loop starts rather than half-running a task whose shell
            # tools would be blocked mid-flight. This runs in a background task,
            # so the refusal is reported over the event stream, not as an HTTP
            # status (the 200 for "started" has already been sent).
            assert_shell_allowed(ctx)
            result = await app.run(req.message, session_id=session_id,
                                   project_root=req.project, task_id=task_id)
            _RESULTS[task_id] = result
            app.db.add_message(session_id, "assistant", result.answer,
                               task_id=result.task_id)
        except ApiError as exc:
            await app.events.emit("task.failed", task_id=task_id,
                                  error=exc.message, code=exc.code)
        except Exception as exc:  # noqa: BLE001
            await app.events.emit("task.failed", task_id=task_id,
                                  error=f"{type(exc).__name__}: {exc}")
        finally:
            _TASKS.pop(task_id, None)

    _TASKS[task_id] = asyncio.create_task(runner())
    return {"task_id": task_id, "session_id": session_id, "status": "started"}


@router.get("/tasks")
async def list_tasks(limit: int = Query(50), ctx: TenantContext = Depends(resolve_tenant)) -> list[dict[str, Any]]:
    return _spidy().db.list_tasks(limit=limit)


@router.get("/tasks/{task_id}")
async def get_task(task_id: str, ctx: TenantContext = Depends(resolve_tenant)) -> dict[str, Any]:
    app = _spidy()
    # Prefer the in-memory result. The live TaskResult is authoritative; the DB
    # row is only a checkpoint snapshot and lags the run, so it under-reports
    # observations the UI needs for the timeline and tool cards.
    result = _RESULTS.get(task_id)
    if result is not None and hasattr(result, "to_dict"):
        view = result_view(result)
        # Prefer the persisted final state (complete observations); fall back to
        # deriving them from the event timeline.
        state = app.db.load_task(task_id)
        if state is not None and state.observations:
            view["observations"] = [
                {"text": str(o.get("text", ""))[:2000], "step_id": o.get("step", ""),
                 "ts": o.get("at", 0), "type": "observation"}
                for o in state.observations]
            if state.plan:
                view["plan"] = task_view(state)["plan"]
        else:
            obs = []
            for e in (result.timeline or []):
                if not isinstance(e, dict):
                    continue
                etype = e.get("type", "")
                if etype in ("observation", "tool.finished", "step.note", "step.skipped"):
                    text = (e.get("text") or e.get("output") or e.get("summary")
                            or e.get("reason") or e.get("tool") or "")
                    obs.append({"text": str(text)[:2000], "step_id": e.get("step", ""),
                                "ts": e.get("ts", 0), "type": etype})
            view["observations"] = obs
        return view
    state = app.db.load_task(task_id)
    if state is None:
        raise ApiError(404, "not_found", f"no task {task_id}")
    return task_view(state)


@router.post("/tasks/{task_id}/cancel")
async def cancel_task(task_id: str, ctx: TenantContext = Depends(resolve_tenant)) -> dict[str, Any]:
    handle = _TASKS.get(task_id)
    if handle and not handle.done():
        handle.cancel()
    _spidy().cancel(task_id)
    return {"ok": True, "task_id": task_id}


@router.post("/tasks/{task_id}/approve")
async def approve_task(task_id: str, req: ApproveRequest,
                       ctx: TenantContext = Depends(resolve_tenant)) -> dict[str, Any]:
    app = _spidy()
    state = app.db.load_task(task_id)
    if state is None:
        raise ApiError(404, "not_found", f"no task {task_id}")
    state.approval_status = "approved" if req.approved else "denied"
    state.approval_required = False
    app.db.save_task(state)
    return {"ok": True, "step_id": req.step_id, "approved": req.approved}


@router.get("/tasks/{task_id}/result")
async def task_result(task_id: str, ctx: TenantContext = Depends(resolve_tenant)) -> dict[str, Any]:
    result = _RESULTS.get(task_id)
    if result is not None and hasattr(result, "to_dict"):
        return result_view(result)
    raise ApiError(404, "not_found", f"no result for {task_id}")


# --------------------------------------------------------------------------- #
# sessions
# --------------------------------------------------------------------------- #


@router.get("/sessions")
async def list_sessions(ctx: TenantContext = Depends(resolve_tenant)) -> list[dict[str, Any]]:
    return _spidy().db.list_sessions()


@router.get("/sessions/{session_id}/messages")
async def session_messages(session_id: str,
                           ctx: TenantContext = Depends(resolve_tenant)) -> list[dict[str, Any]]:
    return _spidy().db.get_messages(session_id)


@router.delete("/sessions/{session_id}")
async def delete_session(session_id: str,
                         ctx: TenantContext = Depends(resolve_tenant)) -> dict[str, Any]:
    db = _spidy().db
    db.execute("DELETE FROM messages WHERE session_id=?", (session_id,))
    db.execute("DELETE FROM sessions WHERE session_id=?", (session_id,))
    return {"ok": True}


# --------------------------------------------------------------------------- #
# files
# --------------------------------------------------------------------------- #

_TEXT_LIMIT = 400_000


def _safe_path(app: Spidy, raw: str) -> Path:
    root = app.settings.workspace_root.resolve()
    target = (root / raw).resolve() if not Path(raw).is_absolute() else Path(raw).resolve()
    try:
        target.relative_to(root)
    except ValueError:
        raise ApiError(403, "policy_denied", f"path escapes workspace: {raw}")
    return target


@router.get("/files")
async def list_files(path: str = Query(""), glob: str = Query(""),
                     max_results: int = Query(500, le=5000),
                     ctx: TenantContext = Depends(resolve_tenant)) -> list[dict[str, Any]]:
    app = _spidy()
    root = _safe_path(app, path) if path else app.settings.workspace_root.resolve()
    out: list[dict[str, Any]] = []
    pattern = glob or "**/*"
    for p in root.glob(pattern):
        if len(out) >= max_results:
            break
        try:
            if p.is_file():
                stt = p.stat()
                out.append({"path": str(p.relative_to(root)),
                            "size": stt.st_size, "mtime": stt.st_mtime,
                            "kind": (p.suffix.lstrip(".") or "file").lower()})
        except OSError:
            continue
    return sorted(out, key=lambda d: d["path"])


@router.get("/files/content")
async def file_content(path: str = Query(...),
                       ctx: TenantContext = Depends(resolve_tenant)) -> dict[str, Any]:
    app = _spidy()
    target = _safe_path(app, path)
    if not target.exists() or not target.is_file():
        raise ApiError(404, "not_found", f"no file {path}")
    try:
        raw = target.read_bytes()
    except OSError as exc:
        raise ApiError(403, "read_denied", str(exc))
    text = raw[:_TEXT_LIMIT].decode("utf-8", "replace")
    return {"path": path, "content": text,
            "language": target.suffix.lstrip("."),
            "truncated": len(raw) > _TEXT_LIMIT,
            "lines": text.count("\n") + 1}


@router.put("/files/content")
async def write_file(req: FileWriteRequest,
                     ctx: TenantContext = Depends(resolve_tenant)) -> dict[str, Any]:
    app = _spidy()
    target = _safe_path(app, req.path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(req.content, encoding="utf-8")
    app.db.audit("file.write", actor=ctx.tenant_id, target=req.path)
    return {"ok": True, "path": req.path, "bytes": len(req.content.encode("utf-8"))}


@router.get("/files/raw")
async def raw_file(request: Request, path: str = Query(...),
                   ctx: TenantContext = Depends(resolve_tenant)) -> FileResponse:
    app = _spidy()
    target = _safe_path(app, path)
    if not target.is_file():
        raise ApiError(404, "not_found", f"no file {path}")
    mime = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
    return FileResponse(target, media_type=mime)


# --------------------------------------------------------------------------- #
# projects / indexing
# --------------------------------------------------------------------------- #


@router.get("/projects")
async def list_projects(ctx: TenantContext = Depends(resolve_tenant)) -> list[dict[str, Any]]:
    app = _spidy()
    stats = app.retriever.stats()
    projects = stats.get("projects", []) if isinstance(stats, dict) else []
    return projects if isinstance(projects, list) else []


@router.post("/projects/index")
async def index_project(req: IndexRequest,
                        ctx: TenantContext = Depends(resolve_tenant)) -> dict[str, Any]:
    app = _spidy()
    started = time.perf_counter()
    root = _safe_path(app, req.root)
    if not root.is_dir():
        raise ApiError(404, "not_found", f"no directory {req.root}")
    result = await app.retriever.index_workspace(root, force=req.force)
    return {"ok": True, **result, "duration_ms": int((time.perf_counter() - started) * 1000)}


# --------------------------------------------------------------------------- #
# memory
# --------------------------------------------------------------------------- #


@router.get("/memory")
async def recall_memory(q: str = Query(""), limit: int = Query(20, le=200),
                        ctx: TenantContext = Depends(resolve_tenant)) -> list[dict[str, Any]]:
    return _spidy().db.recall(query=q, limit=limit)


@router.post("/memory")
async def remember(req: MemoryRequest,
                   ctx: TenantContext = Depends(resolve_tenant)) -> dict[str, Any]:
    mid = _spidy().db.remember(scope="note", content=req.value, key=req.key)
    return {"ok": True, "id": mid}


# --------------------------------------------------------------------------- #
# settings / audit
# --------------------------------------------------------------------------- #

_SECRET_HINTS = ("key", "token", "secret", "password")


def _redacted_settings() -> dict[str, Any]:
    out = _spidy().settings.to_dict()
    for k in list(out):
        if any(h in k.lower() for h in _SECRET_HINTS) and out[k]:
            out[k] = "***redacted***"
    return out


@router.get("/settings")
async def get_settings(ctx: TenantContext = Depends(resolve_tenant)) -> dict[str, Any]:
    return _redacted_settings()


@router.patch("/settings")
async def patch_settings(patch: dict[str, Any],
                         ctx: TenantContext = Depends(resolve_tenant)) -> dict[str, Any]:
    settings = _spidy().settings
    applied, rejected = [], []
    for k, v in (patch or {}).items():
        if k in ("home", "db_path", "workspace_root"):
            rejected.append(k)
            continue
        if hasattr(settings, k):
            try:
                setattr(settings, k, v)
                applied.append(k)
            except Exception:
                rejected.append(k)
        else:
            rejected.append(k)
    # A new key or model pin has to reach the provider set, or the UI would
    # show it saved while the router kept using the old providers.
    if any(k.endswith("_api_key") or k in ("offline_only", "allow_cloud",
                                           "provider_models", "model_roles")
           for k in applied):
        try:
            _spidy().router.reconfigure()
        except Exception:
            pass
    return {"ok": True, "applied": applied, "rejected": rejected}


@router.get("/audit")
async def audit_log(limit: int = Query(100, le=1000),
                    ctx: TenantContext = Depends(resolve_tenant)) -> list[dict[str, Any]]:
    return _spidy().db.recent_audit(limit=limit)


# --------------------------------------------------------------------------- #
# SSE
# --------------------------------------------------------------------------- #


@router.get("/events/stream")
async def event_stream(request: Request, task_id: str = Query(""),
                       replay: str = Query(""),
                       ctx: TenantContext = Depends(resolve_tenant)) -> StreamingResponse:
    app = _spidy()
    bus = app.events

    async def gen():
        # 1. replay persisted history so a refresh mid-task doesn't lose the trail
        replay_id = replay or task_id
        if replay_id:
            for ev in app.db.get_events(replay_id, limit=1000):
                yield _sse(ev["type"], {"task_id": replay_id, "ts": ev["ts"],
                                        "replay": True, **ev["payload"]}, ev.get("id"))

        # 2. live subscription.
        #
        # The bus routes each event to a per-task_id queue, so subscribing with
        # a synthetic key would never match. Instead register a wildcard
        # subscriber and fan into a local queue: one hook, correct routing
        # whether or not the client passed a task_id.
        loop = asyncio.get_running_loop()
        q: asyncio.Queue = asyncio.Queue(maxsize=4000)

        def _on_event(ev: Event) -> None:
            if task_id and ev.task_id and ev.task_id != task_id:
                return
            loop.call_soon_threadsafe(_offer, ev)

        def _offer(ev: Event) -> None:
            try:
                q.put_nowait(ev)
            except asyncio.QueueFull:
                pass

        bus.on("*", _on_event)
        try:
            while True:
                if await request.is_disconnected():
                    break
                try:
                    ev = await asyncio.wait_for(q.get(), timeout=15.0)
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"
                    continue
                yield _sse(ev.type, {"task_id": ev.task_id, **ev.payload}, ev.id)
        finally:
            try:
                bus._subs.get("*", []).remove(_on_event)
            except (AttributeError, ValueError):
                pass

    return StreamingResponse(gen(), media_type="text/event-stream", headers={
        "Cache-Control": "no-cache", "X-Accel-Buffering": "no",
        "Connection": "keep-alive",
    })


def _sse(event: str, data: dict[str, Any], seq: Any = None) -> str:
    lines = []
    if seq is not None:
        lines.append(f"id: {seq}")
    lines.append(f"event: {event}")
    lines.append("data: " + json.dumps(data, default=str))
    return "\n".join(lines) + "\n\n"
