"""Tenancy — the ONLY place mode branches.

The single rule that keeps this maintainable: handlers read `ctx.tenant_id` and
never test `SPIDY_MODE` themselves. Scattering mode checks through route bodies
is exactly what makes adding a second mode expensive, so it happens here, once,
at dependency-injection time.

    local   (default) — one implicit tenant, no auth, LocalSandbox
    server            — bearer token -> tenant, per-tenant rate limit,
                        per-tenant memory namespace, shell requires a real sandbox
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from typing import Any

from ..sandbox import sandbox_kind

MODE_LOCAL = "local"
MODE_SERVER = "server"


class ApiError(Exception):
    """Raised by tenancy, rendered as the documented error envelope."""

    def __init__(self, status: int, code: str, message: str,
                 detail: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message
        self.detail = detail or {}


@dataclass
class TenantContext:
    tenant_id: str
    mode: str
    sandbox_kind: str
    limit_per_min: int = 60
    buckets: dict[str, list[float]] = field(default_factory=dict)

    @property
    def is_local(self) -> bool:
        return self.mode == MODE_LOCAL


def mode() -> str:
    m = os.environ.get("SPIDY_MODE", MODE_LOCAL).strip().lower()
    return m if m in (MODE_LOCAL, MODE_SERVER) else MODE_LOCAL


# --------------------------------------------------------------------------- #
# auth
# --------------------------------------------------------------------------- #


def _valid_server_tokens() -> dict[str, str]:
    """SPIDY_TOKENS as `token:tenant,token2:tenant2`. Empty => refuse all.

    Refusing all by default (rather than allowing all) is deliberate: a server
    deployment that forgets to configure tokens is a deployment that should
    fail loudly, not silently serve everyone.
    """
    raw = os.environ.get("SPIDY_TOKENS", "").strip()
    out: dict[str, str] = {}
    for pair in raw.split(","):
        if ":" not in pair:
            continue
        tok, _, tenant = pair.partition(":")
        tok, tenant = tok.strip(), tenant.strip()
        if tok and tenant:
            out[tok] = tenant
    return out


def resolve_tenant(request: Any = None) -> TenantContext:
    """FastAPI dependency. Injects a TenantContext or raises ApiError."""
    m = mode()
    if m == MODE_LOCAL:
        return TenantContext(tenant_id="local", mode=MODE_LOCAL,
                             sandbox_kind=sandbox_kind(),
                             limit_per_min=int(os.environ.get("SPIDY_RATE_LIMIT", "600")))

    # server mode
    tokens = _valid_server_tokens()
    header = ""
    if request is not None:
        auth = request.headers.get("authorization", "")
        if auth.lower().startswith("bearer "):
            header = auth[7:].strip()
    tenant = tokens.get(header)
    if not tenant:
        raise ApiError(401, "unauthorized",
                       "valid bearer token required in server mode",
                       {"configured": bool(tokens)})
    return TenantContext(tenant_id=tenant, mode=MODE_SERVER,
                         sandbox_kind=sandbox_kind(),
                         limit_per_min=int(os.environ.get("SPIDY_RATE_LIMIT", "60")))


def rate_limit(ctx: TenantContext) -> None:
    """Token bucket per tenant. Raises 429 with Retry-After when exhausted."""
    now = time.time()
    hits = [t for t in ctx.buckets.get(ctx.tenant_id, []) if now - t < 60.0]
    if len(hits) >= ctx.limit_per_min:
        retry = int(60 - (now - hits[0])) + 1
        raise ApiError(429, "rate_limited",
                       f"tenant {ctx.tenant_id} exceeded {ctx.limit_per_min}/min",
                       {"retry_after": retry})
    hits.append(now)
    ctx.buckets[ctx.tenant_id] = hits


def assert_shell_allowed(ctx: TenantContext) -> None:
    """Fail closed: shell tools in server mode need a real sandbox.

    LocalSandbox shares a kernel and filesystem with SPIDY. That is fine for one
    trusted user; handing it to a remote tenant would expose every other
    tenant's memory. So server mode refuses rather than pretending.
    """
    if ctx.is_local:
        return
    if ctx.sandbox_kind != "container":
        raise ApiError(
            403, "sandbox_unavailable",
            "shell tools are disabled in server mode until a container sandbox "
            "is configured (set SPIDY_SANDBOX=container).",
            {"sandbox": ctx.sandbox_kind, "mode": ctx.mode})
