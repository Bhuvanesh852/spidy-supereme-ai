"""Request/response DTOs for the HTTP API.

Kept separate from `spidy.core.schemas` on purpose: the wire format is a public
contract that clients depend on, and the kernel's internal types are free to
change. This layer is the translation boundary.
"""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=32_000)
    session_id: str = ""
    project: str = ""
    stream: bool = True


class ApproveRequest(BaseModel):
    step_id: str = ""
    approved: bool = True


class IndexRequest(BaseModel):
    root: str = Field(..., min_length=1)
    force: bool = False


class FileWriteRequest(BaseModel):
    path: str = Field(..., min_length=1)
    content: str


class MemoryRequest(BaseModel):
    key: str = Field(..., min_length=1)
    value: str = Field("", max_length=16_000)


class SettingsPatch(BaseModel):
    """Partial settings update. Only known, non-secret fields are applied."""

    model_config = {"extra": "allow"}


def task_view(state: Any) -> dict[str, Any]:
    """Serialize an AgentState into the documented task envelope.

    Fields are read defensively: a state restored from an older checkpoint may
    lack attributes added later, and the UI should degrade rather than 500.
    """
    def g(name: str, default: Any) -> Any:
        return getattr(state, name, default)

    steps = []
    for s in g("plan", []) or []:
        if not isinstance(s, dict):
            continue
        steps.append({
            "id": s.get("id", ""),
            "action": s.get("action", ""),
            "tool": s.get("tool_hint") or s.get("tool", ""),
            "target": s.get("target", ""),
            "goal": s.get("goal", ""),
            "done": bool(s.get("done")),
            "result": str(s.get("result_summary") or "")[:400],
        })

    observations = []
    for o in (g("observations", []) or [])[-50:]:
        if isinstance(o, dict):
            observations.append({
                "text": str(o.get("text") or o.get("summary") or "")[:2000],
                "step_id": o.get("step_id", ""),
                "ts": o.get("ts", 0),
            })

    files_changed = list(g("modified_files", []) or []) + list(g("created_files", []) or [])
    phase = g("phase", "")
    return {
        "task_id": g("task_id", ""),
        "session_id": g("session_id", ""),
        "status": getattr(g("status", ""), "value", str(g("status", ""))),
        "phase": getattr(phase, "value", str(phase)),
        "request": g("user_request", ""),
        "answer": g("final_answer", "") or g("goal", ""),
        "plan": steps,
        "current_step": g("current_step", 0),
        "observations": observations,
        "files_changed": files_changed,
        "created_files": list(g("created_files", []) or []),
        "modified_files": list(g("modified_files", []) or []),
        "deleted_files": list(g("deleted_files", []) or []),
        "verification": g("verification", {}) or {},
        "errors": list(g("errors", []) or [])[:20],
        "token_usage": g("token_usage", {}) or {},
        "repair_count": g("repair_count", 0),
        "approval_required": bool(g("approval_required", False)),
        "sources": list(g("retrieved_sources", []) or [])[:20],
        "duration_ms": int(max(0.0, (g("updated_at", 0) or 0) - (g("created_at", 0) or 0)) * 1000),
    }


def result_view(result: Any) -> dict[str, Any]:
    """Serialize a TaskResult (the value `Spidy.run()` returns)."""
    if result is None:
        return {}
    return {
        "task_id": result.task_id,
        "status": result.status,
        "answer": result.answer,
        "plan": result.plan,
        "files_changed": result.files_changed,
        "artifacts": result.artifacts,
        "sources": result.sources,
        "verification": result.verification,
        "timeline": result.timeline,
        "token_usage": result.token_usage,
        "cache": result.cache,
        "error": result.error,
        "duration_ms": result.duration_ms,
    }
