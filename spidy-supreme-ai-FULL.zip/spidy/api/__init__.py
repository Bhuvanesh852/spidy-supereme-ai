"""SPIDY HTTP API.

Thin adapter over the kernel — the same `Spidy` object backs the CLI, so every
route here is replaceable and a different transport (bot, IDE plugin) can reuse
the handler logic.
"""
from .server import create_app

__all__ = ["create_app"]
