"""FastAPI application factory.

    uvicorn spidy.api.server:app

The UI is mounted at `/` and the API at `/api`. The module-level `app` is built
lazily so that importing this module for tests never requires the UI directory
to exist — the UI ships as static files and the API must stand alone.
"""
from __future__ import annotations

import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, AsyncIterator

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from .routes import router
from .tenancy import ApiError, mode, resolve_tenant

UI_DIR = Path(__file__).resolve().parent.parent / "ui"


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    from ..app import get_app
    get_app()          # warm the kernel once, not per-request
    yield
    from ..app import reset_app
    reset_app()


def create_app() -> FastAPI:
    app = FastAPI(
        title="SPIDY Supreme AI",
        version="1.0.0",
        description="Offline-first tool-using agentic AI operating environment.",
        lifespan=lifespan,
    )
    app.include_router(router)

    @app.exception_handler(ApiError)
    async def _api_error(_: Request, exc: ApiError) -> JSONResponse:
        headers = {}
        if exc.status == 429 and "retry_after" in exc.detail:
            headers["Retry-After"] = str(exc.detail["retry_after"])
        if exc.status == 401:
            headers["WWW-Authenticate"] = "Bearer"
        return JSONResponse(
            status_code=exc.status,
            content={"error": {"code": exc.code, "message": exc.message,
                               "detail": exc.detail}},
            headers=headers or None,
        )

    @app.exception_handler(Exception)
    async def _unhandled(_: Request, exc: Exception) -> JSONResponse:
        # Last-resort net. Task failures never reach here (the loop catches its
        # own), so anything landing here is a real server bug worth surfacing.
        return JSONResponse(status_code=500, content={
            "error": {"code": "internal", "message": f"{type(exc).__name__}: {exc}",
                      "detail": {}}})

    if UI_DIR.is_dir():
        app.mount("/", StaticFiles(directory=str(UI_DIR), html=True), name="ui")
    return app


class _LazyApp:
    """Defers create_app() until ASGI actually serves, so `import` is cheap and
    import-time side effects (DB, registry) don't fire during test collection."""

    def __init__(self) -> None:
        self._app: FastAPI | None = None

    def _resolve(self) -> FastAPI:
        if self._app is None:
            self._app = create_app()
        return self._app

    async def __call__(self, scope, receive, send) -> None:
        await self._resolve()(scope, receive, send)


app: Any = _LazyApp()
