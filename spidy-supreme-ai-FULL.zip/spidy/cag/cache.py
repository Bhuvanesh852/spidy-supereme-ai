"""CAG — Cache-Augmented Generation.

The economic claim of this project is "high impact, fewer tokens." CAG is where
that is cashed in. Two caches, both keyed semantically rather than exactly:

  **Answer cache** — a new question that is semantically close to a previous
  one reuses the previous answer. Match is embedding cosine plus a lexical
  guard, so a paraphrase hits but a different question does not.

  **Artifact cache** — search results, file summaries, dependency metadata,
  embeddings, and safe deterministic command output are all cached. These are
  the expensive retrievals that get repeated across steps of one task.

The lexical guard matters more than it looks. Pure embedding matching will
happily serve a cached answer to a question that flipped a critical detail
("how do I delete X" vs "how do I create X"), which is worse than a cache miss.
"""
from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import time
from dataclasses import dataclass
from typing import Any

import numpy as np

from ..core.schemas import ToolResult
from ..core.token_budget import TokenBudget, estimate_tokens
from ..rag.embeddings import BaseEmbedder, get_embedder, split_identifiers

NEGATION_RE = re.compile(
    r"(?i)\b(not|no|never|without|except|exclude|disable|avoid|stop|un\w+|non)\b")
_STOP = {"the", "a", "an", "and", "or", "of", "to", "in", "is", "are", "for", "on",
         "with", "as", "by", "at", "from", "this", "that", "it", "be", "do", "does",
         "how", "what", "why", "i", "you", "my", "your", "can", "should", "?"}


@dataclass
class CacheEntry:
    key: str
    kind: str
    payload: dict[str, Any]
    tokens: int = 0
    similarity: float = 1.0
    hits: int = 0


@dataclass
class CacheLookup:
    hit: bool
    entry: CacheEntry | None = None
    similarity: float = 0.0
    reason: str = ""


class SemanticCache:
    def __init__(
        self,
        db: sqlite3.Connection,
        embedder: BaseEmbedder | None = None,
        threshold: float = 0.86,
        ttl_seconds: int = 86_400,
        max_entries: int = 2048,
    ) -> None:
        self.db = db
        self.embedder = embedder or get_embedder()
        self.threshold = threshold
        self.ttl = ttl_seconds
        self.max_entries = max_entries
        self._ensure()

    def _ensure(self) -> None:
        self.db.execute("""CREATE TABLE IF NOT EXISTS cache (
            key TEXT PRIMARY KEY, kind TEXT NOT NULL, payload TEXT NOT NULL,
            embedding BLOB, tokens INTEGER DEFAULT 0, hits INTEGER DEFAULT 0,
            created_at REAL NOT NULL, expires_at REAL)""")
        self.db.commit()

    # ------------------------------------------------------------------ #
    @staticmethod
    def _key(kind: str, *parts: Any) -> str:
        blob = kind + "|" + "|".join(str(p) for p in parts)
        return hashlib.blake2b(blob.encode("utf-8"), digest_size=20).hexdigest()

    def _pack(self, v: np.ndarray) -> bytes:
        return v.astype(np.float32).tobytes()

    def _unpack(self, b: bytes) -> np.ndarray:
        return np.frombuffer(b, dtype=np.float32)

    # ------------------------------------------------------------------ #
    def put(self, kind: str, key_parts: list[Any], payload: dict[str, Any],
            text: str = "") -> None:
        key = self._key(kind, *key_parts)
        now = time.time()
        emb = self.embedder.embed_one(text) if text else None
        tokens = estimate_tokens(json.dumps(payload, default=str))
        self.db.execute(
            "INSERT OR REPLACE INTO cache(key,kind,payload,embedding,tokens,hits,"
            "created_at,expires_at) VALUES(?,?,?,?,?,0,?,?)",
            (key, kind, json.dumps(payload, default=str),
             self._pack(emb) if emb is not None else None, tokens, now, now + self.ttl))
        self.db.commit()
        self._evict()

    def _evict(self) -> None:
        n = self.db.execute("SELECT COUNT(*) FROM cache").fetchone()[0]
        if n <= self.max_entries:
            return
        self.db.execute(
            "DELETE FROM cache WHERE key IN ("
            "SELECT key FROM cache ORDER BY (expires_at IS NULL), expires_at ASC LIMIT ?)",
            (n - self.max_entries,))
        self.db.commit()

    # ------------------------------------------------------------------ #
    def get(self, kind: str, key_parts: list[Any]) -> CacheLookup:
        key = self._key(kind, *key_parts)
        row = self.db.execute(
            "SELECT key,kind,payload,tokens,hits,expires_at FROM cache WHERE key=?",
            (key,)).fetchone()
        if not row:
            return CacheLookup(False, reason="not found")
        if row[5] and row[5] < time.time():
            self.db.execute("DELETE FROM cache WHERE key=?", (key,))
            self.db.commit()
            return CacheLookup(False, reason="expired")
        entry = CacheEntry(key=row[0], kind=row[1], payload=json.loads(row[2]),
                           tokens=row[3], hits=row[4] + 1)
        self.db.execute("UPDATE cache SET hits=hits+1 WHERE key=?", (key,))
        self.db.commit()
        return CacheLookup(True, entry, 1.0, "exact")

    # ------------------------------------------------------------------ #
    def lookup_similar(self, query: str, kind: str = "answer") -> CacheLookup:
        """Semantic lookup for a new query against cached answers of the same kind.

        Two guards prevent wrong hits:
          1. Cosine must clear `threshold`.
          2. The token sets must overlap and polarity must agree — a cached
             answer to "create X" must never serve "delete X".
        """
        q = (query or "").strip()
        if not q:
            return CacheLookup(False, reason="empty query")

        rows = self.db.execute(
            "SELECT key,kind,payload,embedding,tokens,hits,created_at FROM cache "
            "WHERE kind=? AND embedding IS NOT NULL AND (expires_at IS NULL OR expires_at>?)",
            (kind, time.time())).fetchall()
        if not rows:
            return CacheLookup(False, reason="no candidates")

        qvec = self.embedder.embed_one(q)
        qt = {t for t in split_identifiers(q.lower()) if t not in _STOP}
        q_neg = bool(NEGATION_RE.search(q))

        best: tuple[float, Any] | None = None
        for r in rows:
            v = self._unpack(r[3])
            if v.shape[0] != qvec.shape[0]:
                continue
            sim = self.embedder.cosine(qvec, v)
            if sim < self.threshold:
                continue
            payload = json.loads(r[2])
            ct = {t for t in split_identifiers(str(payload.get("query", "")).lower())
                  if t not in _STOP}
            if qt and ct:
                overlap = len(qt & ct) / max(1, min(len(qt), len(ct)))
                if overlap < 0.34:
                    continue
                jaccard = len(qt & ct) / max(1, len(qt | ct))
                if jaccard < 0.18:
                    continue
            if bool(payload.get("negated", False)) != q_neg:
                continue
            score = sim * 0.75 + (0.25 * (overlap if qt and ct else 1.0))
            if best is None or score > best[0]:
                best = (score, r)

        if best is None:
            return CacheLookup(False, similarity=0.0, reason="below threshold")
        score, r = best
        entry = CacheEntry(key=r[0], kind=r[1], payload=json.loads(r[2]),
                           tokens=r[4], similarity=round(score, 3), hits=r[5] + 1)
        self.db.execute("UPDATE cache SET hits=hits+1 WHERE key=?", (r[0],))
        self.db.commit()
        return CacheLookup(True, entry, round(score, 3), "semantic")

    # ------------------------------------------------------------------ #
    def cache_answer(self, query: str, answer: str, meta: dict[str, Any] | None = None) -> None:
        self.put("answer", [hashlib.blake2b(query.encode(), digest_size=12).hexdigest()],
                 {"query": query, "answer": answer,
                  "negated": bool(NEGATION_RE.search(query)),
                  "meta": meta or {}}, text=query + " " + answer[:400])

    def lookup_answer(self, query: str, budget: TokenBudget | None = None) -> CacheLookup:
        """Try semantic then exact. A hit credits the budget for the tokens it saved."""
        hit = self.lookup_similar(query, "answer")
        if hit.hit and hit.entry:
            if budget:
                saved = hit.entry.tokens or estimate_tokens(hit.entry.payload.get("answer", ""))
                budget.credit("model", saved, "cag_answer")
                budget.hit()
            return hit
        if budget:
            budget.miss()
        return hit

    # ---- artifact caches ------------------------------------------- #
    def cache_tool_result(self, tool: str, args: dict[str, Any],
                          result: ToolResult, cacheable: bool = True) -> None:
        """Cache tool output.

        Only side-effect-free tools are cached: re-running a write and serving a
        stale read would be a correctness bug, not an optimization.
        """
        if not cacheable or not result.ok:
            return
        from ..core.schemas import RiskLevel
        spec_risk = _RISK.get(tool, RiskLevel.MEDIUM)
        if spec_risk not in (RiskLevel.READ, RiskLevel.LOW):
            return
        if result.status.value != "success":
            return
        self.put(f"tool:{tool}", [json.dumps(args, sort_keys=True, default=str)],
                 {"tool": tool, "stdout": result.stdout[:20000],
                  "data": _jsonable(result.data)}, text=result.stdout[:500])

    def get_tool_result(self, tool: str, args: dict[str, Any],
                        budget: TokenBudget | None = None) -> ToolResult | None:
        look = self.get(f"tool:{tool}", [json.dumps(args, sort_keys=True, default=str)])
        if not look.hit or not look.entry:
            return None
        p = look.entry.payload
        r = ToolResult(tool=p["tool"], stdout=p.get("stdout", ""),
                       data=p.get("data", {}), cached=True,
                       metadata={"cache_hit": True, "cache_key": look.entry.key})
        if budget:
            budget.credit("tool", estimate_tokens(r.stdout), f"cag:{tool}")
            budget.hit()
        return r

    def cache_embeddings(self, text: str) -> bool:
        key = self._key("embedding", hashlib.sha256(text.encode()).hexdigest())
        row = self.db.execute("SELECT 1 FROM cache WHERE key=?", (key,)).fetchone()
        return row is not None

    def invalidate(self, kind: str | None = None) -> int:
        if kind:
            cur = self.db.execute("DELETE FROM cache WHERE kind=?", (kind,))
        else:
            cur = self.db.execute("DELETE FROM cache")
        self.db.commit()
        return cur.rowcount or 0

    def stats(self) -> dict[str, Any]:
        rows = self.db.execute(
            "SELECT kind, COUNT(*), COALESCE(SUM(hits),0), COALESCE(SUM(tokens),0) "
            "FROM cache GROUP BY kind ORDER BY 2 DESC").fetchall()
        total = self.db.execute(
            "SELECT COUNT(*), COALESCE(SUM(hits),0), COALESCE(SUM(tokens),0) "
            "FROM cache").fetchone()
        return {
            "entries": total[0] or 0,
            "total_hits": total[1] or 0,
            "tokens_avoided": total[2] or 0,
            "by_kind": [{"kind": r[0], "entries": r[1], "hits": r[2], "tokens": r[3]}
                        for r in rows],
            "threshold": self.threshold,
            "ttl_seconds": self.ttl,
        }


_RISK: dict[str, Any] = {}


def register_risk(tool: str, risk) -> None:
    _RISK[tool] = risk


def _jsonable(d: dict[str, Any]) -> dict[str, Any]:
    out = {}
    for k, v in d.items():
        try:
            json.dumps(v, default=str)
            out[k] = v
        except (TypeError, ValueError):
            out[k] = str(v)
    return out
