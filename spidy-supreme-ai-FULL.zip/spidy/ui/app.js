/* ═══════════════════════════════════════════════════════════════
   SPIDY — client
   No framework. A tiny observable store, a hash router, an SSE
   client, and one render function per screen. The transcript is an
   append-only list and the timeline is a bounded array, so targeted
   DOM updates beat pulling in a runtime here.

   Every value that came from the server is untrusted: it reaches the
   DOM through textContent or el(), never innerHTML. Tool output can
   contain anything the filesystem holds.
   ═══════════════════════════════════════════════════════════════ */
(function () {
'use strict';

// ── tiny DOM helpers ──────────────────────────────────────
// h(tag, attrs, ...children) — the only element factory. Text always
// goes in as a text node, which is what makes the untrusted-data rule
// structural rather than a thing to remember.
function h(tag, attrs) {
  var e = document.createElement(tag);
  if (attrs) {
    for (var k in attrs) {
      var v = attrs[k];
      if (v === null || v === undefined || v === false) continue;
      if (k === 'class') e.className = v;
      else if (k === 'text') e.textContent = v;
      else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v);
    }
  }
  for (var i = 2; i < arguments.length; i++) append(e, arguments[i]);
  return e;
}
function append(parent, child) {
  if (child === null || child === undefined || child === false) return;
  if (Array.isArray(child)) { child.forEach(function (c) { append(parent, c); }); return; }
  parent.appendChild(child.nodeType ? child : document.createTextNode(String(child)));
}
function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); }
function $(sel) { return document.querySelector(sel); }
function fmtBytes(n) {
  if (!n && n !== 0) return '—';
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n / 1024).toFixed(1) + ' K';
  return (n / 1048576).toFixed(1) + ' M';
}
function fmtNum(n) { return typeof n === 'number' ? n.toLocaleString() : (n || 0); }

// ── API client ────────────────────────────────────────────
var API = {
  get: function (path) { return fetch('/api' + path).then(read); },
  post: function (path, body) {
    return fetch('/api' + path, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body)
    }).then(read);
  },
  patch: function (path, body) {
    return fetch('/api' + path, {
      method: 'PATCH',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body)
    }).then(read);
  },
  put: function (path, body) {
    return fetch('/api' + path, {
      method: 'PUT',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body)
    }).then(read);
  },
  del: function (path) { return fetch('/api' + path, { method: 'DELETE' }).then(read); }
};

function read(r) {
  return r.json().catch(function () { return {}; }).then(function (d) {
    if (!r.ok) {
      var e = (d && d.error) || {};
      var err = new Error(e.message || ('HTTP ' + r.status));
      err.code = e.code || String(r.status);
      err.status = r.status;
      throw err;
    }
    return d;
  });
}

function toast(msg, kind) {
  var t = h('div', { class: 'toast' + (kind ? ' ' + kind : ''), text: msg });
  $('#toasts').appendChild(t);
  setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 4200);
}

// ── store ─────────────────────────────────────────────────
var S = {
  health: null,
  models: [],
  tools: [],
  sessionId: '',
  taskId: '',
  messages: [],        // {role, body, kind}
  events: [],          // live SSE events for the current task
  steps: [],
  files: [],
  selFile: '',
  fileContent: '',
  projects: [],
  providers: [],
  tagFilter: '',
  busy: false
};

// ── SSE client ─────────────────────────────────────────────
var stream = null;

function connect(taskId) {
  if (stream) { stream.close(); stream = null; }
  var url = '/api/events/stream' + (taskId ? '?task_id=' + encodeURIComponent(taskId) : '');
  try { stream = new EventSource(url); } catch (e) { return; }

  stream.onopen = function () { setConn('on'); };
  stream.onerror = function () {
    setConn('off');
    // EventSource auto-reconnects; nothing to do but reflect the state.
  };

  // Every documented event type gets a handler. Unknown types are ignored,
  // which is what lets the server add events without breaking old clients.
  ['task.created', 'agent.understood', 'plan.created', 'step.started',
   'step.finished', 'step.skipped', 'step.failed', 'tool.started',
   'tool.finished', 'repair.started', 'task.verified', 'task.completed',
   'task.failed', 'task.cancelled', 'approval.required', 'token.spend',
   'rag.retrieved', 'cache.hit'
  ].forEach(function (name) {
    stream.addEventListener(name, function (ev) {
      var d = {};
      try { d = JSON.parse(ev.data); } catch (e) { return; }
      S.events.push({ type: name, data: d });
      onEvent(name, d);
    });
  });
}

function setConn(state) {
  var el = $('#conn');
  el.className = 'conn' + (state === 'on' ? ' on' : state === 'off' ? ' off' : '');
  el.querySelector('.conn-lab').textContent =
    state === 'on' ? 'live' : state === 'off' ? 'reconnecting' : 'idle';
}

// ── event handling → UI ────────────────────────────────────
var activeToolCards = {};

function onEvent(name, d) {
  if (S.taskId && d.task_id && d.task_id !== S.taskId) return;

  if (name === 'token.spend') {
    setTokens(d.total_spent || d.spent || 0);
  } else if (name === 'tool.started') {
    addToolCard(d.tool, 'run', d.arguments);
  } else if (name === 'tool.finished') {
    finishToolCard(d.tool, d.ok ? 'ok' : 'err', d.summary || d.message || d.error_type);
  } else if (name === 'step.started') {
    S.steps.forEach(function (s) { s.active = (s.id === d.step); });
  } else if (name === 'step.finished' || name === 'step.skipped') {
    var st = findStep(d.step);
    if (st) { st.active = false; st.done = true; st.result = d.summary || d.reason || ''; }
  } else if (name === 'plan.created') {
    S.steps = (d.steps || []).map(function (s) {
      return { id: s.id, action: s.action, tool: s.tool_hint || s.tool,
               done: false, active: false, result: '' };
    });
  } else if (name === 'approval.required') {
    showApproval(d);
  } else if (name === 'task.completed' || name === 'task.failed' || name === 'task.cancelled') {
    endBusy();
  }
  if (currentView() === 'timeline') renderView();
}

function findStep(id) {
  for (var i = 0; i < S.steps.length; i++) if (S.steps[i].id === id) return S.steps[i];
  return null;
}

function setTokens(n) {
  var el = $('#token-meter .t-val');
  if (el) el.textContent = fmtNum(n);
}

// ── chat rendering ─────────────────────────────────────────
function renderChat() {
  var scroll = h('div', { class: 'chat-scroll', id: 'chat-scroll' });
  var inner = h('div', { class: 'chat-inner', id: 'chat-inner' });

  if (!S.messages.length) {
    inner.appendChild(h('div', { class: 'empty' },
      h('div', { class: 'big', text: '◈' }),
      h('div', { class: 'sub', text:
        'SPIDY plans, runs tools, and verifies — offline, with no model required. ' +
        'Ask for something: "read app.py and find the bug", "search for TODOs", ' +
        '"summarize this project".' })));
  }

  S.messages.forEach(function (m) { inner.appendChild(renderMessage(m)); });

  var busy = !!S.busy;
  var ta = h('textarea', {
    id: 'composer-input', rows: '1', placeholder: 'Ask SPIDY to do something…',
    disabled: busy ? 'disabled' : null,
    'aria-busy': busy ? 'true' : null,
    oninput: function () { autoGrow(this); },
    onkeydown: function (e) {
      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); send(); }
    }
  });

  var composer = h('div', { class: 'composer' },
    h('div', { class: 'composer-inner' },
      h('div', { class: 'composer-box' + (busy ? ' busy' : '') },
        busy ? h('span', { class: 'spin', 'aria-hidden': 'true' }) : null,
        ta,
        h('button', {
          class: 'btn primary', id: 'send-btn',
          disabled: busy ? 'disabled' : null,
          onclick: send
        }, busy ? 'Working…' : 'Send')),
      h('div', { class: 'composer-hint' },
        h('kbd', { text: '⌘' }), h('kbd', { text: 'Enter' }), ' to send')));

  scroll.appendChild(inner);
  return h('div', { class: 'chat-wrap' }, scroll, composer);
}

function autoGrow(ta) {
  ta.style.height = 'auto';
  ta.style.height = Math.min(ta.scrollHeight, 160) + 'px';
}

function renderMessage(m) {
  var cls = m.kind === 'user' ? 'user' : m.kind === 'error' ? 'bot msg-err' : 'bot';
  var role = m.kind === 'user' ? 'You' : m.kind === 'error' ? 'SPIDY · error' : 'SPIDY';
  return h('div', { class: 'msg ' + cls },
    h('div', { class: 'msg-head' }, h('span', { class: 'msg-role', text: role })),
    h('div', { class: 'msg-body' }, mdLite(m.body || '')));
}

// Minimal markdown: bold, inline code, fenced code, headings, bullets.
// Deliberately tiny — the answer is mostly prose and tool output, and a
// full parser would be both bigger and a worse escape hatch.
function mdLite(s) {
  var out = [];
  var parts = String(s).split(/```/);
  parts.forEach(function (chunk, i) {
    if (i % 2 === 1) {
      var m = chunk.match(/^([a-z]*)\n([\s\S]*)$/i);
      out.push(h('pre', null, h('code', { text: m ? m[2] : chunk })));
      return;
    }
    chunk.split('\n').forEach(function (line) {
      var inline = inlineFmt(line);
      if (/^\s*[-*]\s+/.test(line)) out.push(h('div', { style: 'padding-left:14px' }, inline));
      else if (/^#{1,4}\s+/.test(line)) out.push(h('h3', null, inline));
      else if (line.trim()) out.push(h('div', null, inline));
      else out.push(h('div', null, h('br')));
    });
  });
  return out;
}

function inlineFmt(line) {
  var frag = document.createDocumentFragment();
  var re = /(\*\*[^*]+\*\*|`[^`]+`)/g;
  var last = 0, m;
  while ((m = re.exec(line)) !== null) {
    if (m.index > last) frag.appendChild(document.createTextNode(line.slice(last, m.index)));
    var tok = m[0];
    if (tok.slice(0, 2) === '**') frag.appendChild(h('strong', { text: tok.slice(2, -2) }));
    else frag.appendChild(h('code', { text: tok.slice(1, -1) }));
    last = m.index + tok.length;
  }
  if (last < line.length) frag.appendChild(document.createTextNode(line.slice(last)));
  return frag;
}

function addToolCard(tool, state, detail) {
  var body = $('#chat-inner');
  if (!body) return;
  var card = h('div', { class: 'tool-card' + (detail ? ' open' : '') },
    h('div', {
      class: 'tool-card-head',
      onclick: function () { card.classList.toggle('open'); }
    },
      h('span', { class: 'tool-dot ' + state }),
      h('span', { class: 'tname', text: tool || 'tool' }),
      h('span', { class: 'caret', text: '▶' }),
      h('span', { class: 'tdur', text: '' })),
    h('div', { class: 'tool-card-body', text: pretty(detail) }));
  body.appendChild(card);
  activeToolCards[tool] = card;
  scrollChat();
  return card;
}

function finishToolCard(tool, state, summary) {
  var card = activeToolCards[tool];
  if (!card) return;
  card.querySelector('.tool-dot').className = 'tool-dot ' + state;
  var b = card.querySelector('.tool-card-body');
  b.textContent = pretty(summary);
  if (!summary) card.classList.remove('open');
  delete activeToolCards[tool];
}

function pretty(v) {
  if (v === null || v === undefined) return '';
  if (typeof v === 'string') return v;
  try { return JSON.stringify(v, null, 2); } catch (e) { return String(v); }
}

function showApproval(d) {
  var body = $('#chat-inner');
  if (!body) return;
  var box = h('div', { class: 'approval' },
    h('h4', { text: 'Approval required' }),
    h('div', { class: 'mono', style: 'font-size:12px;color:var(--text-dim)',
               text: d.reason || (d.tool ? 'Run ' + d.tool + '?' : 'Approve this step?') }),
    h('div', { class: 'btns' },
      h('button', {
        class: 'btn primary sm',
        onclick: function () {
          API.post('/tasks/' + S.taskId + '/approve',
                   { step_id: d.step || '', approved: true })
            .then(function () { box.remove(); });
        }
      }, 'Approve'),
      h('button', {
        class: 'btn danger sm',
        onclick: function () {
          API.post('/tasks/' + S.taskId + '/approve',
                   { step_id: d.step || '', approved: false })
            .then(function () { box.remove(); });
        }
      }, 'Deny')));
  body.appendChild(box);
  scrollChat();
}

function scrollChat() {
  var el = $('#chat-scroll');
  if (el) el.scrollTop = el.scrollHeight;
}

// Busy state is rendered from S.busy by renderChat(); these are no-ops kept
// so existing call sites stay honest. Setting the DOM directly used to be
// undone by the next render, which made the app look idle mid-run.
function endBusy() { S.busy = false; if (currentView() === 'chat') renderView(); }
function beginBusy() { S.busy = true;  if (currentView() === 'chat') renderView(); }

// ── send ───────────────────────────────────────────────────
function send() {
  if (S.busy) return;
  var ta = $('#composer-input');
  if (!ta) return;
  var msg = (ta.value || '').trim();
  if (!msg) return;

  ta.value = ''; autoGrow(ta);
  // Retire any poll still in flight; its loop is now stale.
  if (typeof S._cancelPoll === 'function') { S._cancelPoll(); S._cancelPoll = null; }
  S.messages.push({ role: 'assistant', kind: 'user', body: msg });
  S.steps = []; S.events = []; activeToolCards = {};
  setTokens(0);
  renderView();
  scrollChat();

  beginBusy();
  // Hold a reference to THIS message. Polling used to write into
  // S.messages[last], which meant a fast second send overwrote the first
  // answer and every reply after it arrived one question late.
  var pending = { role: 'assistant', kind: 'bot', body: '' };
  S.messages.push(pending);
  renderView();

  API.post('/chat', { message: msg, session_id: S.sessionId })
    .then(function (d) {
      S.taskId = d.task_id;
      if (d.session_id) S.sessionId = d.session_id;
      connect(S.taskId);
      pollTask(S.taskId, pending);
    })
    .catch(function (e) {
      endBusy();
      pending.kind = 'error';
      pending.body = 'Could not start task: ' + e.message;
      renderView();
    });
}

// Poll the task until it settles. SSE drives the live view; this is the
// durable channel that survives a dropped stream.
//
// Binds to a specific message and a specific task id, so overlapping runs
// can't cross-write each other's answers.
var _pollSeq = 0;

function pollTask(taskId, pending) {
  var seq = ++_pollSeq;
  var done = false;

  function stop() { done = true; }

  (function tick() {
    if (done || seq !== _pollSeq) return;
    API.get('/tasks/' + taskId).then(function (d) {
      if (done || seq !== _pollSeq) return;
      if (S.steps.length === 0 && d.plan) {
        S.steps = d.plan.map(function (s) {
          return { id: s.id, action: s.action, tool: s.tool, done: !!s.done,
                   active: false, result: s.result || '' };
        });
      }
      if (d.status === 'completed' || d.status === 'failed' || d.status === 'cancelled') {
        finishWith(d, pending);
        return;
      }
      setTimeout(tick, 1200);
    }).catch(function () {
      if (done || seq !== _pollSeq) return;
      setTimeout(tick, 2500);
    });
  })();

  // Expose a cancel so a new send() can retire the previous loop.
  S._cancelPoll = stop;
}

function finishWith(d, pending) {
  endBusy();
  var m = pending;
  if (!m) m = S.messages[S.messages.length - 1];
  if (!m.body) m.body = d.answer || '(no answer returned)';
  if (d.status === 'failed' && d.answer) m.kind = 'error';
  if (d.verification && d.verification.passed === false) {
    var failed = (d.verification.failed_checks || []).join(', ');
    if (failed) m.body += '\n\n⚠ verification did not pass: ' + failed;
  }
  if (d.token_usage && d.token_usage.total_spent) setTokens(d.token_usage.total_spent);
  renderView();
  scrollChat();
}

// ── timeline view ──────────────────────────────────────────
var PHASES = ['understand', 'context', 'plan', 'approval', 'act', 'observe', 'verify'];

function renderTimeline() {
  var reached = {};
  S.events.forEach(function (e) {
    if (e.type === 'agent.understood') reached.understand = true;
    if (e.type === 'rag.retrieved') reached.context = true;
    if (e.type === 'plan.created') reached.plan = true;
    if (e.type === 'approval.required') reached.approval = true;
    if (e.type === 'tool.started') reached.act = true;
    if (e.type === 'step.finished') reached.observe = true;
    if (e.type === 'task.verified') reached.verify = true;
  });
  var order = ['understand', 'context', 'plan', 'approval', 'act', 'observe', 'verify'];
  var cur = -1;
  for (var i = 0; i < order.length; i++) if (reached[order[i]]) cur = i;

  var dag = h('div', { class: 'dag' });
  order.forEach(function (p, i) {
    dag.appendChild(h('div', {
      class: 'phase' + (i === cur ? ' active' : reached[p] ? ' done' : '')
    },
      h('span', { class: 'pmark', text: i === cur ? '◐' : reached[p] ? '✓' : '·' }),
      h('span', { class: 'pname', text: p }),
      h('span', { class: 'pdetail', text: phaseDetail(p) })));
  });

  var steps = h('div', { class: 'steps' });
  if (!S.steps.length) {
    steps.appendChild(h('div', { class: 'empty' },
      h('div', { class: 'sub', text: 'No active task. Send something from Chat and its plan appears here.' })));
  }
  S.steps.forEach(function (s) {
    steps.appendChild(h('div', { class: 'step-row' + (s.done ? ' done' : '') + (s.active ? ' active' : '') },
      h('span', { class: 'step-id', text: s.id }),
      h('span', { class: 'step-tool', text: s.tool || s.action }),
      h('span', { class: 'step-sum', text: s.result || s.action }),
      h('span', { class: 'step-state', text: s.done ? '✓' : s.active ? '◐' : '·' })));
  });

  return h('div', { class: 'pane' },
    h('div', { class: 'pane-head' },
      h('h2', { text: 'Agent timeline' }),
      h('p', { text: S.taskId ? 'Task ' + S.taskId : 'Live 7-phase agent loop' })),
    dag, steps);
}

function phaseDetail(p) {
  var evs = S.events;
  for (var i = evs.length - 1; i >= 0; i--) {
    var d = evs[i].data || {};
    if (p === 'understand' && evs[i].type === 'agent.understood')
      return 'intent: ' + (d.intent || '?') + ' · confidence ' + Math.round((d.confidence || 0) * 100) + '%';
    if (p === 'plan' && evs[i].type === 'plan.created')
      return (d.steps || []).length + ' steps planned';
    if (p === 'verify' && evs[i].type === 'task.verified')
      return d.passed ? 'all checks passed' : (d.failed_checks || []).length + ' checks failed';
    if (p === 'act' && evs[i].type === 'tool.started') return 'running ' + d.tool;
  }
  return '—';
}

// ── tools view ─────────────────────────────────────────────
function renderTools() {
  var tags = {};
  S.tools.forEach(function (t) {
    (t.tags || []).forEach(function (g) { tags[g] = (tags[g] || 0) + 1; });
  });
  var filters = h('div', { class: 'filters' },
    h('button', {
      class: 'btn sm' + (S.tagFilter === '' ? ' sel' : ''),
      onclick: function () { S.tagFilter = ''; renderView(); }
    }, 'All ' + S.tools.length),
    Object.keys(tags).sort().map(function (g) {
      return h('button', {
        class: 'btn sm' + (S.tagFilter === g ? ' sel' : ''),
        onclick: function () { S.tagFilter = g; renderView(); }
      }, g + ' ' + tags[g]);
    }));

  var list = h('div', { class: 'card' });
  var shown = S.tools.filter(function (t) {
    return !S.tagFilter || (t.tags || []).indexOf(S.tagFilter) >= 0;
  });
  if (!shown.length) {
    list.appendChild(h('div', { class: 'empty' }, h('div', { class: 'sub', text: 'No tools.' })));
  }
  shown.forEach(function (t) {
    list.appendChild(h('div', { class: 'tool-row', onclick: function () { showTool(t); } },
      h('span', { class: 'nm', text: t.name }),
      h('span', { class: 'ds', text: t.description || '' }),
      h('span', { class: 'tg' },
        t.available === false ? h('span', { class: 'tag err', text: 'blocked' }) : null,
        h('span', { class: 'tag', text: t.risk_level || '' }),
        (t.tags || []).slice(0, 2).map(function (g) {
          return h('span', { class: 'tag', text: g });
        }))));
  });

  return h('div', { class: 'pane' },
    h('div', { class: 'pane-head' },
      h('h2', { text: 'Tools' }),
      h('p', { text: S.tools.length + ' tools registered · click one for its schema' })),
    filters, list);
}

function showTool(t) {
  var body = h('div', { class: 'tool-card-body', style: 'display:block;max-height:none' },
    h('div', { style: 'color:var(--muted);margin-bottom:8px', text: t.description || '' }),
    h('pre', { style: 'margin:0;white-space:pre-wrap', text: pretty(t.input_schema) }));
  var view = h('div', { class: 'pane' },
    h('div', { class: 'pane-head' },
      h('h2', { text: t.name }),
      h('p', { text: (t.tags || []).join(' · ') })),
    h('div', { class: 'card' }, h('div', { class: 'tool-card-head' },
      h('span', { class: 'tname', text: t.risk_level || '' }),
      h('span', { class: 'tdur', text: t.idempotent ? 'idempotent' : '' })),
      body),
    h('div', { style: 'margin-top:14px' },
      h('button', { class: 'btn sm', onclick: function () { location.hash = '#/tools'; } }, '← All tools')));
  $('#view').replaceChildren(view);
}

// ── files view ─────────────────────────────────────────────
function renderFiles() {
  var list = h('div', { class: 'card filelist' });
  if (!S.files.length) {
    list.appendChild(h('div', { class: 'empty' }, h('div', { class: 'sub', text: 'No files found.' })));
  }
  S.files.forEach(function (f) {
    list.appendChild(h('div', {
      class: 'file-row' + (f.path === S.selFile ? ' sel' : ''),
      onclick: function () { openFile(f.path); }
    },
      h('span', { class: 'fn', text: f.path }),
      h('span', { class: 'fs', text: fmtBytes(f.size) })));
  });

  var editor;
  if (S.selFile) {
    editor = h('div', { class: 'card editor-wrap' },
      h('div', { class: 'editor-bar' },
        h('span', { class: 'path', text: S.selFile }),
        h('button', { class: 'btn sm', onclick: function () { openFile(S.selFile); } }, 'Reload'),
        h('button', { class: 'btn sm primary', onclick: saveFile }, 'Save')),
      h('textarea', {
        class: 'editor', id: 'file-editor',
        oninput: function (e) { S.fileContent = e.target.value; }
      }, S.fileContent));
  } else {
    editor = h('div', { class: 'card' }, h('div', { class: 'empty' },
      h('div', { class: 'sub', text: 'Select a file to view or edit it.' })));
  }

  return h('div', { class: 'pane' },
    h('div', { class: 'pane-head' },
      h('h2', { text: 'Files' }),
      h('p', { text: S.files.length + ' files in the workspace' })),
    h('div', { class: 'files-grid' }, list, editor));
}

function openFile(path) {
  API.get('/files/content?path=' + encodeURIComponent(path)).then(function (d) {
    S.selFile = path;
    S.fileContent = d.content || '';
    renderView();
  }).catch(function (e) { toast('Could not open file: ' + e.message, 'err'); });
}

function saveFile() {
  if (!S.selFile) return;
  API.put('/files/content', { path: S.selFile, content: S.fileContent })
    .then(function () { toast('Saved ' + S.selFile, 'ok'); })
    .catch(function (e) { toast('Save failed: ' + e.message, 'err'); });
}

// ── projects view ──────────────────────────────────────────
function renderProjects() {
  var grid = h('div', { class: 'proj-grid' });
  if (!S.projects.length) {
    grid.appendChild(h('div', { class: 'empty' },
      h('div', { class: 'big', text: '◱' }),
      h('div', { class: 'sub', text: 'No projects indexed yet. Index the workspace to enable RAG over your code and documents.' })));
  }
  S.projects.forEach(function (p) {
    grid.appendChild(h('div', { class: 'proj' },
      h('h3', { text: p.name || p.root || 'workspace' }),
      h('div', { class: 'root', text: p.root || '' }),
      h('div', { class: 'metrics' },
        h('div', { class: 'metric' }, h('b', { text: fmtNum(p.chunks || 0) }), h('span', { text: 'chunks' })),
        h('div', { class: 'metric' }, h('b', { text: fmtNum(p.docs || 0) }), h('span', { text: 'documents' })))));
  });

  return h('div', { class: 'pane' },
    h('div', { class: 'pane-head' },
      h('h2', { text: 'Projects' }),
      h('p', { text: 'Indexed workspaces powering retrieval and the semantic cache' })),
    grid);
}

// ── settings view ──────────────────────────────────────────
function renderSettings() {
  var s = S.health || {};
  var rows = h('div', { class: 'card rows' });

  function row(k, v, cls) {
    rows.appendChild(h('div', { class: 'row' },
      h('span', { class: 'rk', text: k }),
      h('span', { class: 'rv' + (cls ? ' ' + cls : ''), text: String(v) })));
  }

  row('version', s.version || '—');
  row('mode', s.mode || 'local');
  row('sandbox', s.sandbox || 'local');
  row('cloud providers allowed', s.allow_cloud === false ? 'disabled' : 'enabled',
      s.allow_cloud === false ? 'bad' : 'good');
  row('tools', s.tools || '—');
  row('database', s.db_ok === false ? 'unavailable' : 'ok', s.db_ok === false ? 'bad' : 'good');
  row('uptime', Math.round(s.uptime_s || 0) + 's');

  var provRows = h('div', { class: 'card rows' });
  S.providers.forEach(function (p) {
    var label = p.reachable
      ? (p.models || []).length + ' model(s) reachable'
      : (p.configured ? 'configured, but not reachable'
                       : (p.local ? 'local — not running' : 'no key set'));
    provRows.appendChild(h('div', { class: 'row' },
      h('span', { class: 'rk', text: p.label }),
      h('span', { class: 'rv ' + (p.reachable ? 'good' : ''), text: label })));
  });

  return h('div', { class: 'pane' },
    h('div', { class: 'pane-head' },
      h('h2', { text: 'Settings' }),
      h('p', { text: 'Runtime configuration · read-only in this version' })),
    rows,
    h('div', { style: 'height:16px' }),
    h('div', { class: 'pane-head' }, h('h2', { text: 'Model providers' })),
    provRows);
}

// ── models view ────────────────────────────────────────────
// One card per provider. Shows what each key would unlock, lets you paste a
// key and pin a model, and reports live reachability. A provider with no key
// is still shown — hiding it would make the option undiscoverable.
function renderModels() {
  var cloud = S.providers.filter(function (p) { return !p.local; });
  var local = S.providers.filter(function (p) { return p.local; });
  var pane = h('div', { class: 'pane' },
    h('div', { class: 'pane-head' },
      h('h2', { text: 'Models & providers' }),
      h('p', { text: S.providers.length + ' providers · keys stay on this machine and are never returned by the API' })));

  function card(p) {
    var keyField = p.slug + '_api_key';
    var keyInput = h('input', {
      class: 'input', type: 'password', placeholder: p.key_env || 'local — no key needed',
      autocomplete: 'off', spellcheck: 'false',
      value: p.configured ? '••••••••••••••••' : ''
    });

    var modelSel = h('select', { class: 'input' },
      (p.models || []).map(function (m) {
        return h('option', { value: m, selected: m === p.default_model ? 'selected' : null }, m);
      }));
    if (!(p.models || []).length) {
      modelSel = h('input', { class: 'input', placeholder: 'no models detected',
        value: p.default_model || '', disabled: 'disabled' });
    }

    var saveBtn = h('button', { class: 'btn primary sm', onclick: function () {
      var patch = {};
      var key = keyInput.value;
      // Don't submit the redaction placeholder back as if it were a real key.
      if (key && key.indexOf('•') === -1) patch[keyField] = key;
      if (modelSel.tagName === 'SELECT' && modelSel.value) {
        var pins = {}; pins[p.slug] = modelSel.value;
        patch.provider_models = pins;
      }
      if (!Object.keys(patch).length) { toast('Nothing to save', 'err'); return; }
      API.patch('/settings', patch).then(function (r) {
        if (r.rejected && r.rejected.length) {
          toast('Rejected: ' + r.rejected.join(', '), 'err');
        } else { toast(p.label + ' updated', 'ok'); }
        return refreshModels();
      }).catch(function (e) { toast(e.message, 'err'); });
    } }, 'Save');

    return h('div', { class: 'prov' + (p.reachable ? ' on' : '') },
      h('div', { class: 'prov-head' },
        h('span', { class: 'prov-name', text: p.label }),
        h('span', { class: 'prov-slug', text: p.slug }),
        p.local ? h('span', { class: 'tag', text: 'local' }) : null,
        h('span', { class: 'prov-state' },
          h('span', { class: 'dot' }),
          h('span', { text: p.reachable ? (p.degraded ? 'degraded' : 'reachable')
                                       : (p.configured ? 'unreachable' : 'no key') }))),

      h('div', { class: 'prov-body' },
        p.local ? null : h('div', { class: 'prov-field' },
          h('label', { text: 'API key' }), keyInput),
        h('div', { class: 'prov-field' },
          h('label', { text: 'Model' }), modelSel),
        p.local ? null : saveBtn),

      (p.models || []).length ? h('div', { class: 'prov-models' },
        p.models.map(function (m) {
          return h('span', {
            class: 'm' + (m === p.default_model ? ' sel' : ''),
            title: 'Use ' + m,
            onclick: function () {
              var pins = {}; pins[p.slug] = m;
              API.patch('/settings', { provider_models: pins }).then(function () {
                toast(p.label + ' → ' + m, 'ok');
                refreshModels();
              });
            }
          }, m.length > 40 ? m.slice(0, 38) + '…' : m);
        })) : null,

      h('div', { class: 'prov-note' },
        p.key_env ? h('span', null, 'set via ', h('code', { text: p.key_env })) :
                    h('span', { text: 'runs locally — nothing to configure' }),
        p.error ? h('span', { class: 'tag err', text: p.error }) : null,
        p.docs ? h('a', { href: p.docs, target: '_blank', rel: 'noreferrer noopener',
                          style: 'color:var(--accent-2);text-decoration:none' }, 'docs') : null));
  }

  function group(title, hint, list) {
    var g = h('div', { class: 'prov-group' }, h('h3', { text: title }),
               h('p', { class: 'hint', text: hint }));
    if (!list.length) {
      g.appendChild(h('div', { class: 'empty' },
        h('div', { class: 'sub', text: 'No providers.' })));
    } else list.forEach(function (p) { g.appendChild(card(p)); });
    return g;
  }

  pane.appendChild(group('Local — free and private',
    'No key, no cost, no data leaving the machine.', local));
  pane.appendChild(group('Cloud — bring your own key',
    'Used only when a local model is unavailable. Set SPIDY_OFFLINE_ONLY=true to forbid them entirely.',
    cloud));
  return pane;
}

function refreshModels() {
  return API.get('/models').then(function (d) {
    S.providers = d || [];
    if (currentView() === 'models') renderView();
  }).catch(function () {});
}

// ── router ─────────────────────────────────────────────────
var VIEWS = {
  chat: renderChat, timeline: renderTimeline, tools: renderTools,
  files: renderFiles, models: renderModels, projects: renderProjects,
  settings: renderSettings
};
var TITLES = {
  chat: 'Chat', timeline: 'Agent timeline', tools: 'Tools',
  files: 'Files', models: 'Models & providers', projects: 'Projects',
  settings: 'Settings'
};

function currentView() {
  var name = (location.hash || '#/chat').replace(/^#\//, '') || 'chat';
  return VIEWS[name] ? name : 'chat';
}

function renderView() {
  var name = currentView();
  var view = $('#view');
  clear(view);
  view.appendChild(VIEWS[name]());
  $('#crumbs').textContent = TITLES[name];
  Array.prototype.forEach.call(document.querySelectorAll('.nav a'), function (a) {
    a.classList.toggle('active', a.dataset.view === name);
  });
  if (name === 'chat') scrollChat();
  if (name === 'chat') { var t = $('#composer-input'); if (t) t.focus(); }
}

window.addEventListener('hashchange', renderView);

// ── boot ───────────────────────────────────────────────────
function boot() {
  $('#theme-btn').addEventListener('click', function () {
    var cur = document.documentElement.getAttribute('data-density');
    document.documentElement.setAttribute('data-density', cur === 'compact' ? '' : 'compact');
  });

  connect('');           // open the stream before any task exists
  renderView();

  API.get('/health').then(function (d) {
    S.health = d;
    $('#tool-count').firstChild.textContent = d.tools || 0;
    var badge = $('#offline-badge');
    if (d.offline_mode) badge.classList.remove('hidden');
    else badge.classList.add('hidden');
    if (d.rag && d.rag.chunks) $('#rag-count').firstChild.textContent = d.rag.chunks;
    if (currentView() === 'settings') renderView();
  }).catch(function () { setConn('off'); });

  API.get('/tools').then(function (d) {
    S.tools = d || [];
    if (currentView() === 'tools') renderView();
  }).catch(function () {});

  API.get('/files?max=2000').then(function (d) {
    S.files = d || [];
    if (currentView() === 'files') renderView();
  }).catch(function () {});

  refreshModels();

  API.get('/projects').then(function (d) {
    S.projects = d || [];
    if (currentView() === 'projects') renderView();
  }).catch(function () {});
}

// Exposed deliberately: it makes the client state inspectable from the console
// and from the demo harness, which is how the "answers arrive empty" bug was
// found. Read-only in practice; nothing in the app mutates it from outside.
window.SPYDY = S;

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();

})();
