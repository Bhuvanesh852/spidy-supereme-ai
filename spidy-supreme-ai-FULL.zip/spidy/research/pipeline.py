"""Deep research pipeline.

    Question
      → query decomposition
      → parallel search
      → source-quality filter
      → fetch
      → cross-check
      → conflict detection
      → synthesis
      → citations + confidence

The output is a structured report, not prose. Confidence is computed from
source agreement and source quality rather than asserted, and a claim with no
support is reported as unsupported instead of being quietly dropped.
"""
from __future__ import annotations

import asyncio
import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from ..core.token_budget import estimate_tokens

DEPTHS = {
    "quick":     {"queries": 2, "fetch": 3, "rounds": 1},
    "standard":  {"queries": 4, "fetch": 5, "rounds": 1},
    "thorough":  {"queries": 7, "fetch": 9, "rounds": 2},
}

# Domains that are a strong default signal for factual accuracy.
TRUST_HINTS = {
    "arxiv.org": 0.9, "doi.org": 0.9, ".gov": 0.95, ".edu": 0.85, "nature.com": 0.9,
    "sciencedirect.com": 0.85, "springer.com": 0.8, "ieee.org": 0.85,
    "nytimes.com": 0.75, "reuters.com": 0.85, "apnews.com": 0.8, "bbc.co.uk": 0.8,
    "stackoverflow.com": 0.6, "medium.com": 0.4, "quora.com": 0.3,
    "wikipedia.org": 0.6, "reddit.com": 0.3, "blogspot.com": 0.3,
    "pypi.org": 0.85, "npmjs.com": 0.85, "github.com": 0.6, "docs.": 0.8,
    "microsoft.com": 0.75, "apple.com": 0.75, "google.com": 0.7, "anthropic.com": 0.8,
    "openai.com": 0.8, "huggingface.co": 0.7, "kaggle.com": 0.65,
}


def source_quality(url: str) -> float:
    from urllib.parse import urlparse
    host = (urlparse(url).hostname or "").lower()
    score = 0.5
    for pattern, weight in TRUST_HINTS.items():
        if pattern in host:
            score = max(score, weight)
    if host.endswith((".org", ".net", ".io", ".ai", ".dev")):
        score = max(score, 0.5)
    if re.search(r"\d{4}-\d{2}-\d{2}|\d{4}/\d{2}/\d{2}", url):
        score += 0.03
    return min(1.0, score)


def decompose(question: str, max_queries: int = 4) -> list[str]:
    """Break a question into angles that search well.

    Compound questions and questions with a time dimension ("latest", "vs")
    need more than one query to be answered properly.
    """
    q = question.strip()
    out: list[str] = [q]

    lower = q.lower()
    if re.search(r"\bvs\.?\b|\bversus\b|\bcompared to\b|\bdifference between\b", lower):
        m = re.search(r"(.+?)\s+(?:vs\.?|versus|compared to)\s+(.+)", lower)
        if m:
            out.append(f"{m.group(1).strip()} explanation")
            out.append(f"{m.group(2).strip()} explanation")
            out.append(f"{m.group(1).strip()} vs {m.group(2).strip()} comparison")
    if re.search(r"\bhow (do|does|to|can)\b|\bwhy\b", lower):
        out.append(f"{q} tutorial")
        out.append(f"{q} best practices")
    if re.search(r"\blatest\b|\bcurrent\b|\bnow\b|\b202[4-9]\b", lower):
        out.append(f"{q} 2025")
        out.append(f"{q} recent developments")
    if re.search(r"\bwhat is\b|\bwhat are\b", lower):
        out.append(q.replace("what is", "definition of").replace("what are", "definition of"))
    if re.search(r"\bbest\b|\btop\b|\brecommend", lower):
        out.append(f"{q} comparison and recommendations")
    if re.search(r"\bimplement\b|\bbuild\b|\bcode\b", lower):
        out.append(f"{q} example code")
        out.append(f"{q} tutorial implementation")

    seen: set[str] = set()
    out = [s for s in (x.strip() for x in out)
           if s and s.lower() not in seen and not seen.add(s.lower())]
    return out[:max_queries]


@dataclass
class Source:
    title: str
    url: str
    snippet: str = ""
    content: str = ""
    quality: float = 0.5
    fetched: bool = False
    error: str = ""
    claims: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {"title": self.title, "url": self.url, "quality": round(self.quality, 2),
                "fetched": self.fetched, "chars": len(self.content),
                "relevance": round(self.quality, 2),
                "publisher": _publisher(self.url), "error": self.error}


def _publisher(url: str) -> str:
    from urllib.parse import urlparse
    h = (urlparse(url).hostname or "")
    return h[4:] if h.startswith("www.") else h


_SENTENCE_RE = re.compile(r"(?<=[.!?])\s+")
_STOP_CLAIM = {
    "cookie", "privacy policy", "terms of service", "subscribe", "sign in",
    "all rights reserved", "©", "advertisement", "cookie policy", "javascript",
}


def extract_claims(text: str, limit: int = 8) -> list[str]:
    """Pull candidate factual claims out of a page."""
    out: list[str] = []
    for para in text.split("\n\n"):
        para = para.strip()
        if len(para) < 60 or len(para) > 700:
            continue
        if any(s in para.lower() for s in _STOP_CLAIM):
            continue
        for s in _SENTENCE_RE.split(para):
            s = s.strip()
            if not (50 <= len(s) <= 400):
                continue
            if any(b in s.lower() for b in _STOP_CLAIM):
                continue
            has_fact = bool(re.search(r"\d", s)) or \
                bool(re.search(r"\b(is|are|was|were|has|have|can|will|must|should|"
                               r"provides|supports|requires|uses|allows|enables)\b", s,
                               re.I))
            if has_fact and len(s.split()) >= 8:
                out.append(s)
            if len(out) >= limit:
                return out
    return out


def _normalize_claim(c: str) -> str:
    c = re.sub(r"\s+", " ", c.lower()).strip()
    c = re.sub(r"[^\w\s%$.]", "", c)
    return c


def similarity(a: str, b: str) -> float:
    aw, bw = set(a.split()), set(b.split())
    if not aw or not bw:
        return 0.0
    return len(aw & bw) / len(aw | bw)


def detect_conflicts(claims: list[tuple[str, str]]) -> list[dict[str, Any]]:
    """Flag claims that look related but disagree on a number or polarity."""
    conflicts: list[dict[str, Any]] = []
    nums: dict[tuple[str, ...], list[tuple[str, str, float]]] = {}
    for text, url, q in claims:
        for m in re.finditer(r"([\w\s-]{2,40}?)\s+((?:\$)?\d[\d,.]*\s*(?:%|percent|"
                             r"million|billion|trillion|ms|seconds?|x|GB|MB|KB))?",
                             text, re.I):
            pass
        for m in re.finditer(r"(.{0,60}?)(\$?\d[\d,.]*\s*(?:%|percent|million|billion|"
                             r"ms|seconds?|x\b|GB|MB))", text, re.I):
            ctx_words = tuple(sorted(set(re.findall(r"[a-z]{4,}", m.group(1).lower())))[:3])
            if not ctx_words:
                continue
            value = _to_number(m.group(2))
            if value is None:
                continue
            nums.setdefault(ctx_words, []).append((text, url, value))
    for ctx, entries in nums.items():
        values = {round(v, 4) for _, _, v in entries}
        if len(values) > 1 and len(entries) >= 2:
            lo, hi = min(values), max(values)
            if hi > 0 and (hi - lo) / max(abs(hi), 1e-9) > 0.5:
                conflicts.append({
                    "topic": " ".join(ctx),
                    "values": sorted(values),
                    "sources": [u for _, u, _ in entries][:4],
                    "note": f"sources disagree: {lo:g} vs {hi:g}",
                })
    return conflicts[:8]


def _to_number(s: str) -> float | None:
    m = re.search(r"[\d,.]+", s)
    if not m:
        return None
    try:
        v = float(m.group(0).replace(",", ""))
    except ValueError:
        return None
    low = s.lower()
    for mult, keys in ((1e9, ("billion",)), (1e6, ("million",)), (1e3, ("thousand",))):
        if any(k in low for k in keys):
            v *= mult
    return v


# --------------------------------------------------------------------------- #


async def run_research(
    question: str,
    ctx: Any,
    depth: str = "standard",
    max_sources: int = 6,
    emit: Callable | None = None,
) -> dict[str, Any]:
    """Execute the pipeline against a live ToolContext."""
    from ..tools.web import fetch_url, search_web

    cfg = DEPTHS.get(depth, DEPTHS["standard"])
    started = time.perf_counter()
    report: dict[str, Any] = {"question": question, "depth": depth,
                              "pipeline": [], "sources": [], "claims": [],
                              "conflicts": [], "confidence": "unknown", "answer": ""}

    async def step(name: str, detail: str = "") -> None:
        report["pipeline"].append({"stage": name, "detail": detail,
                                   "at": round(time.perf_counter() - started, 2)})
        if emit:
            try:
                await emit("research.stage", stage=name, detail=detail[:200])
            except Exception:
                pass

    await step("decompose", "splitting the question")
    queries = decompose(question, cfg["queries"])

    await step("search", f"{len(queries)} parallel queries")
    results: list[dict[str, Any]] = []
    for batch_start in range(0, len(queries), 3):
        batch = queries[batch_start:batch_start + 3]
        rs = await asyncio.gather(
            *(search_web(q, ctx, count=6) for q in batch), return_exceptions=True)
        for q, r in zip(batch, rs):
            if isinstance(r, ToolResult_ := type(r)) and getattr(r, "ok", False):
                for item in r.data.get("results", []):
                    item = dict(item)
                    item["_query"] = q
                    results.append(item)
            elif isinstance(r, Exception):
                continue
    if not results:
        report["answer"] = (
            "No live sources were reachable. SPIDY will not fabricate citations — "
            "the question can be answered from local knowledge, but any "
            "time-sensitive claim should be verified once a network or search "
            "backend is available.")
        report["confidence"] = "unverified"
        await step("complete", "no sources")
        return report

    # filter + dedupe
    await step("filter", f"{len(results)} raw results")
    seen: set[str] = set()
    sources: list[Source] = []
    for r in sorted(results, key=lambda x: -source_quality(x.get("url", ""))):
        url = r.get("url", "")
        if not url or url in seen:
            continue
        seen.add(url)
        sources.append(Source(
            title=r.get("title", "") or url, url=url,
            snippet=r.get("snippet", ""), quality=source_quality(url)))
        if len(sources) >= max(cfg["fetch"], max_sources):
            break

    await step("fetch", f"fetching {len(sources)} sources")
    fetched = await asyncio.gather(
        *(fetch_url(s.url, ctx, max_chars=9000) for s in sources[:cfg["fetch"]]),
        return_exceptions=True)
    for s, r in zip(sources, fetched):
        if isinstance(r, Exception) or not getattr(r, "ok", False):
            s.error = "fetch failed"
            continue
        s.content = r.data.get("content", "")
        s.title = r.data.get("title") or s.title
        s.fetched = bool(s.content)
        if not s.fetched:
            s.error = "empty content"

    good = [s for s in sources if s.fetched]
    if not good:
        report["sources"] = [s.to_dict() for s in sources]
        report["answer"] = ("Sources were found but none could be fetched. "
                            "SPIDY will not summarize pages it could not read.")
        report["confidence"] = "unverified"
        await step("complete", "0 sources readable")
        return report

    # claims + cross-check
    await step("extract_claims", "extracting factual claims")
    claim_rows: list[tuple[str, str, float]] = []
    for s in good:
        s.claims = extract_claims(s.content)
        for c in s.claims:
            claim_rows.append((c, s.url, s.quality))

    await step("cross_check", "corroborating claims across sources")
    corroborated: list[dict[str, Any]] = []
    seen_norm: set[str] = set()
    for text, url, q in claim_rows:
        norm = _normalize_claim(text)
        if not norm or norm in seen_norm:
            continue
        seen_norm.add(norm)
        support = 0
        for other, other_url, _ in claim_rows:
            if other_url == url:
                continue
            if similarity(norm, _normalize_claim(other)) > 0.42:
                support += 1
        corroborated.append({
            "claim": text, "source": url, "source_title": _title_of(good, url),
            "quality": round(q, 2), "corroborating_sources": min(support, 5),
            "confidence": "high" if support >= 2 else ("medium" if support == 1 else "low"),
        })
    corroborated.sort(key=lambda c: (-c["corroborating_sources"], -c["quality"]))

    await step("conflict_detection", "checking for disagreements")
    conflicts = detect_conflicts([(t, u, q) for t, u, q in claim_rows])

    # synthesis
    await step("synthesis", "composing the answer")
    ctx_block = "\n\n".join(
        f"<SOURCE url=\"{s.url}\" quality=\"{s.quality:.2f}\">\n{s.content[:3000]}\n</SOURCE>"
        for s in good[:4])
    from ..brain.router import ModelRouter
    from ..core.schemas import LLMMessage
    from ..security.guard import as_untrusted_context

    router: ModelRouter = ctx.extra.get("router")
    answer = ""
    if router is not None:
        untrusted = as_untrusted_context(ctx_block, "research_sources", max_chars=14000)
        resp = await router.complete([
            LLMMessage(role="system", content=(
                "You are SPIDY's research synthesizer. Answer ONLY from the sources "
                "provided. Cite each factual claim with its [n] marker. If the "
                "sources do not answer part of the question, say so explicitly — "
                "never fill gaps from memory. Note disagreements between sources.")),
            LLMMessage(role="user", content=(
                f"{untrusted}\n\nQuestion: {question}\n\n"
                f"Numbered sources:\n" + "\n".join(
                    f"[{i}] {s.title} — {s.url}" for i, s in enumerate(good[:8], 1)) +
                f"\n\nAnswer:")),
        ], role="reasoning", max_tokens=2500, temperature=0.2)
        if not resp.error:
            answer = resp.text.strip()

    if not answer:
        answer = _extractive_summary(question, good, corroborated)

    n_multi = sum(1 for c in corroborated if c["corroborating_sources"] >= 1)
    avg_q = sum(s.quality for s in good) / len(good)
    if conflicts and len(conflicts) > 2:
        confidence = "low"
    elif n_multi >= 4 and avg_q > 0.65 and not conflicts:
        confidence = "high"
    elif n_multi >= 1:
        confidence = "medium"
    else:
        confidence = "low"

    report.update({
        "sources": [s.to_dict() for s in sources],
        "readable_sources": len(good),
        "claims": corroborated[:25],
        "conflicts": conflicts,
        "confidence": confidence,
        "answer": answer,
        "queries_used": queries,
        "duration_ms": int((time.perf_counter() - started) * 1000),
    })
    await step("complete", f"confidence={confidence}")
    return report


def _title_of(sources: list[Source], url: str) -> str:
    for s in sources:
        if s.url == url:
            return s.title
    return url


def _extractive_summary(question: str, sources: list[Source],
                        claims: list[dict[str, Any]]) -> str:
    """Fallback synthesis — quote the best-supported claims rather than invent prose."""
    qt = set(re.findall(r"[a-z]{4,}", question.lower()))
    ranked = sorted(claims, key=lambda c: (
        -c["corroborating_sources"],
        -len(qt & set(re.findall(r"[a-z]{4,}", c["claim"].lower())))))
    lines = [f"**{question}**", "",
             f"Based on {len(sources)} source(s); "
             f"{sum(1 for c in claims if c['corroborating_sources'] >= 1)} claim(s) "
             f"corroborated across multiple sources.", ""]
    used_urls: dict[str, int] = {}
    for c in ranked[:6]:
        urls = c["source"]
        idx = used_urls.get(urls, 0) + 1
        used_urls[urls] = idx
        lines.append(f"- {c['claim']} [{idx}]")
    lines.append("")
    lines.append("**Sources**")
    for i, s in enumerate(sources[:8], 1):
        lines.append(f"[{i}] [{s.title}]({s.url}) — quality {s.quality:.2f}")
    return "\n".join(lines)
