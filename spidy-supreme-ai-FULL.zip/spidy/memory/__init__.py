"""Memory subsystem: delegated to the store + runtime for now."""
