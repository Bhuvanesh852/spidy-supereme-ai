"""Secret redaction + credential handling.

Redaction is applied on the way *out* of every tool result and on the way *in*
to every prompt, so a credential read out of a config file never reaches the
model, the logs, or the UI.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

# Ordered: most specific first so a well-known key prefix is not pre-empted by
# the generic high-entropy detector.
_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("anthropic_key", re.compile(r"sk-ant-[A-Za-z0-9_\-]{20,}")),
    ("openai_key", re.compile(r"sk-(?:proj-)?[A-Za-z0-9_\-]{32,}")),
    ("openrouter_key", re.compile(r"sk-or-v1-[A-Za-z0-9]{32,}")),
    ("google_key", re.compile(r"AIza[0-9A-Za-z_\-]{35}")),
    ("github_token", re.compile(r"gh[pousr]_[A-Za-z0-9]{30,}")),
    ("slack_token", re.compile(r"xox[baprs]-[A-Za-z0-9\-]{10,}")),
    ("aws_access_key", re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b")),
    ("stripe_key", re.compile(r"\b(?:sk|rk)_(?:live|test)_[A-Za-z0-9]{16,}\b")),
    ("private_key_block", re.compile(
        r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----",
        re.DOTALL,
    )),
    ("jwt", re.compile(r"\beyJ[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}")),
    ("bearer", re.compile(r"(?i)\b(?:bearer|authorization:\s*bearer)\s+[A-Za-z0-9._\-]{16,}")),
    # key=value in env / config / query strings
    ("assignment", re.compile(
        r"(?i)\b((?:api[_\-]?key|apikey|secret|secret[_\-]?key|token|password|passwd|"
        r"pwd|pw|access[_\-]?key|client[_\-]?secret|private[_\-]?key|auth[_\-]?token)"
        r"\s*[:=]\s*)(\"[^\"]{6,}\"|'[^']{6,}'|[^\s,;&)\]}]{6,})"
    )),
    ("url_credentials", re.compile(r"(?i)\b([a-z][a-z0-9+.\-]*://)([^/\s:@]+):([^/\s@]+)@")),
]

# Generic high-entropy string that looks like a credential.
_ENTROPY_RE = re.compile(r"\b[A-Za-z0-9_\-]{32,}\b")
_SAFE_SUBSTRINGS = (
    "sha256:", "sha1:", "md5:", "http://", "https://", "data:image",
    "-----BEGIN CERTIFICATE-----", "utf-8", "application/json",
)


def _looks_secret(s: str) -> bool:
    low = s.lower()
    if any(marker in low for marker in _SAFE_SUBSTRINGS):
        return False
    if s.count(".") == 2 and s.startswith("eyJ"):      # already covered by jwt
        return False
    if re.fullmatch(r"[0-9a-fA-F]{32,}", s):              # plain hash
        return False
    classes = sum(bool(re.search(c, s)) for c in (r"[a-z]", r"[A-Z]", r"\d", r"[_\-]"))
    return classes >= 3


@dataclass
class RedactionResult:
    text: str
    findings: list[dict[str, str]]

    @property
    def clean(self) -> bool:
        return not self.findings


def redact(text: str, placeholder: str = "[REDACTED:{kind}]") -> RedactionResult:
    """Strip credentials from arbitrary text. Idempotent."""
    if not text:
        return RedactionResult("", [])
    findings: list[dict[str, str]] = []
    out = text

    for kind, pat in _PATTERNS:
        def _sub(m: re.Match[str]) -> str:
            findings.append({"kind": kind, "length": str(len(m.group(0)))})
            if kind == "assignment" and m.lastindex and m.lastindex >= 2:
                return m.group(1) + placeholder.format(kind=kind)
            if kind == "url_credentials" and m.lastindex and m.lastindex >= 3:
                return m.group(1) + m.group(2) + ":***@"
            if kind == "private_key_block":
                return f"-----BEGIN PRIVATE KEY----- [REDACTED:{kind}]"
            return placeholder.format(kind=kind)

        out = pat.sub(_sub, out)

    if _ENTROPY_RE.search(out):
        def _ent(m: re.Match[str]) -> str:
            if _looks_secret(m.group(0)):
                findings.append({"kind": "high_entropy", "length": str(len(m.group(0)))})
                return placeholder.format(kind="high_entropy")
            return m.group(0)

        out = _ENTROPY_RE.sub(_ent, out)

    return RedactionResult(out, findings)


def redact_obj(obj: Any, max_depth: int = 12) -> Any:
    """Recursively redact strings inside dicts / lists."""
    if max_depth <= 0:
        return "[TRUNCATED]"
    if isinstance(obj, str):
        return redact(obj).text
    if isinstance(obj, dict):
        return {k: redact_obj(v, max_depth - 1) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [redact_obj(v, max_depth - 1) for v in obj]
    return obj


_SENSITIVE_KEYS = {"password", "passwd", "pwd", "secret", "token", "api_key", "apikey",
                   "authorization", "private_key", "client_secret", "access_key"}


def scrub_env(env: dict[str, str], denylist: set[str] | None = None) -> dict[str, str]:
    """Build a sanitized environment for child processes.

    Denylisted names never reach a subprocess, and values that look like
    credentials are masked so a tool that prints its own environment cannot
    exfiltrate them.
    """
    deny = denylist or _SENSITIVE_KEYS
    out: dict[str, str] = {}
    for k, v in env.items():
        if k.upper() in {d.upper() for d in deny}:
            continue
        if _looks_secret(v or "") or re.match(
            r"(?i)^(sk-|ghp_|xox|AIza|Bearer)", v or ""
        ):
            out[k] = "[REDACTED]"
        else:
            out[k] = v
    return out
