"""Command + filesystem policy.

The command policy is allowlist-first. A command must match a known-safe shape
*and* not match a deny pattern before it runs; anything unrecognised falls to
`HIGH` risk and needs approval rather than being silently allowed.
"""
from __future__ import annotations

import re
import shlex
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from ..core.schemas import RiskLevel, RISK_ORDER


# --------------------------------------------------------------------------- #
# command policy
# --------------------------------------------------------------------------- #

# Executables that are safe to run without prompting in BALANCED mode.
SAFE_EXECUTABLES = {
    "ls", "cat", "head", "tail", "wc", "echo", "pwd", "date", "whoami", "uname",
    "which", "type", "file", "stat", "du", "df", "tree", "find", "grep", "rg",
    "sed", "awk", "sort", "uniq", "cut", "diff", "basename", "dirname", "realpath",
    "env", "printenv", "id", "hostname", "uptime", "id", "ps", "top", "df", "free",
    "python", "python3", "pip", "pip3", "node", "npm", "npx", "yarn", "pnpm",
    "git", "pytest", "tox", "ruff", "flake8", "black", "isort", "mypy", "pylint",
    "cargo", "go", "rustc", "javac", "java", "mvn", "gradle", "make", "cmake",
    "tsc", "eslint", "prettier", "jest", "vitest", "next", "vite", "curl", "wget",
    "sqlite3", "jq", "tar", "zip", "unzip", "gzip",
}

# Never run, in any permission mode short of a full override.
FORBIDDEN_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("fork_bomb", re.compile(r":\s*\(\s*\)\s*\{.*\|.*&\s*\}\s*;?\s*:")),
    ("disk_write_raw", re.compile(r"\b(mkfs(\.\w+)?|fdisk|dd\s+if=|shred)\b")),
    ("shutdown", re.compile(r"\b(shutdown|reboot|halt|poweroff|init\s+0|init\s+6)\b")),
    ("remote_code_exec", re.compile(r"\b(curl|wget)\b[^|;]*\|\s*(sudo\s+)?(ba|z|k|)sh\b")),
    ("privilege_escalation", re.compile(r"\b(sudo|su\s+-|pkexec|doas)\b")),
    ("credential_file_read", re.compile(
        r"\b(cat|less|more|head|tail|cp|scp|curl|strings|xxd)\b[^|;&]*"
        r"(/etc/(shadow|sudoers)|\.ssh/|id_rsa|\.aws/credentials|\.netrc|"
        r"\.docker/config\.json|\.kube/config|\.npmrc|\.pypirc)\b"
    )),
    ("history_tamper", re.compile(r"\b(history\s+-c|unset\s+HISTFILE)\b")),
    ("system_config_write", re.compile(
        r"\b(echo|tee|printf|cat)\b[^|;]*>>?\s*(/etc/|/boot/|/sys/|/proc/sys/)"
    )),
    ("reverse_shell", re.compile(r"\b(nc|ncat|netcat)\b[^|;]*\s(-e|--exec)\b")),
    ("chmod_root", re.compile(r"\bchmod\s+(-R\s+)?(777|a\+rwx)\s+/(\s|$)")),
    ("package_registry_push", re.compile(r"\b(npm|yarn|pnpm)\s+publish\b|\btwine\s+upload\b")),
]

# Confirm in BALANCED; allow in AUTONOMOUS.
CONFIRM_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("recursive_delete", re.compile(r"\brm\s+(-[a-zA-Z]*\s+)*-?[a-zA-Z]*[rf][a-zA-Z]*\b")),
    ("force_push", re.compile(r"\bgit\s+push\b[^|;&]*(--force|-f)\b")),
    ("history_rewrite", re.compile(r"\bgit\s+(reset\s+--hard|clean\s+-[a-z]*f|rebase\s+-i)\b")),
    ("branch_delete", re.compile(r"\bgit\s+branch\s+-D\b")),
    ("package_install_global", re.compile(r"\b(pip|pip3)\s+install\b(?!.*(-r|--user))")),
    ("npm_global", re.compile(r"\bnpm\s+(install\s+-g|i\s+-g|add\s+-g)\b")),
    ("db_destructive", re.compile(r"\b(DROP\s+(TABLE|DATABASE)|TRUNCATE\s+TABLE)\b", re.I)),
    ("service_control", re.compile(r"\b(systemctl|service|launchctl)\s+(stop|restart|disable)\b")),
    ("kill", re.compile(r"\b(killall|pkill)\b")),
    ("large_download", re.compile(r"\b(curl|wget)\b.*\s(-O|--output)\s")),
]

# Read-only executables never mutate state, so they are promoted to READ risk.
READONLY_EXECUTABLES = {
    "ls", "cat", "head", "tail", "wc", "echo", "pwd", "date", "whoami", "uname",
    "which", "type", "file", "stat", "du", "df", "tree", "find", "grep", "rg",
    "diff", "basename", "dirname", "realpath", "printenv", "id", "hostname",
    "uptime", "ps", "free", "git", "pytest", "jq",
}

# Chained operators that make a "read" command able to write.
MUTATING_CHAIN_RE = re.compile(r"(?<![<>])(>>?|\btee\b|\bxargs\b\s+-I\s*\{\}\s*rm)")


@dataclass
class CommandDecision:
    allowed: bool
    risk: RiskLevel = RiskLevel.LOW
    reason: str = ""
    executable: str = ""
    needs_approval: bool = False
    matched: list[str] = field(default_factory=list)

    def __bool__(self) -> bool:
        return self.allowed


class CommandPolicy:
    def __init__(self, permission_mode: str = "BALANCED", forbidden: bool = True) -> None:
        self.mode = permission_mode.upper()
        self.forbidden = forbidden

    # ------------------------------------------------------------------ #
    def evaluate(self, command: str) -> CommandDecision:
        cmd = (command or "").strip()
        if not cmd:
            return CommandDecision(False, RiskLevel.LOW, "empty command")

        matched: list[str] = []

        # Hard blocks apply in every mode.
        for name, pat in FORBIDDEN_PATTERNS:
            if pat.search(cmd):
                matched.append(name)
        if matched:
            return CommandDecision(
                False, RiskLevel.DESTRUCTIVE,
                f"blocked by hard policy: {', '.join(matched)}",
                needs_approval=False, matched=matched,
            )
        if not self.forbidden:
            pass  # audit-only mode

        # Shell metacharacters: the command may be doing far more than it looks.
        has_chain = bool(re.search(r"[;&|]|&&|\|\||`|\$\(", cmd))
        redirect_write = bool(MUTATING_CHAIN_RE.search(cmd))

        try:
            tokens = shlex.split(cmd)
        except ValueError:
            tokens = cmd.split()
        executable = Path(tokens[0]).name if tokens else ""

        # Confirm-level patterns.
        confirm_hits: list[str] = []
        for name, pat in CONFIRM_PATTERNS:
            if pat.search(cmd):
                confirm_hits.append(name)

        # Determine base risk.
        if executable in READONLY_EXECUTABLES and not redirect_write:
            risk = RiskLevel.READ
        elif executable in SAFE_EXECUTABLES:
            risk = RiskLevel.LOW
        else:
            risk = RiskLevel.MEDIUM

        if executable not in SAFE_EXECUTABLES and executable not in READONLY_EXECUTABLES:
            risk = RiskLevel.HIGH
        if confirm_hits:
            risk = max(risk, RiskLevel.HIGH, key=lambda r: RISK_ORDER[r])
        if redirect_write:
            risk = max(risk, RiskLevel.MEDIUM, key=lambda r: RISK_ORDER[r])
        if has_chain and executable not in SAFE_EXECUTABLES:
            risk = max(risk, RiskLevel.HIGH, key=lambda r: RISK_ORDER[r])

        # Map risk + mode to the decision.
        needs_approval = False
        if self.mode == "LOCKED":
            if risk is not RiskLevel.READ:
                return CommandDecision(
                    False, risk, "LOCKED mode is read-only", executable, False, matched
                )
        elif self.mode == "SAFE":
            needs_approval = risk in (RiskLevel.MEDIUM, RiskLevel.HIGH, RiskLevel.DESTRUCTIVE)
        elif self.mode == "BALANCED":
            needs_approval = risk is RiskLevel.HIGH
        elif self.mode == "AUTONOMOUS":
            needs_approval = risk is RiskLevel.DESTRUCTIVE
        else:
            needs_approval = risk is RiskLevel.HIGH

        reason_parts: list[str] = [f"risk={risk.value}"]
        if confirm_hits:
            reason_parts.append(f"confirm:{','.join(confirm_hits)}")
        if not executable:
            reason_parts.append("no executable resolved")

        return CommandDecision(
            True, risk, "; ".join(reason_parts), executable, needs_approval,
            matched + confirm_hits,
        )


# --------------------------------------------------------------------------- #
# filesystem policy
# --------------------------------------------------------------------------- #

DEFAULT_IGNORED_DIRS = {
    ".git", "node_modules", "__pycache__", ".venv", "venv", "env", ".mypy_cache",
    ".pytest_cache", "dist", "build", ".next", "target", ".tox", ".idea", ".vscode",
    ".cache", "site-packages", ".gradle", "coverage", ".ruff_cache", ".DS_Store",
    ".spidy", "vendor", ".terraform", ".eggs", "*.egg-info",
}

# Never writable, never readable-through-the-agent, regardless of mode.
SYSTEM_PATHS_LINUX = {
    "/etc", "/boot", "/sys", "/proc", "/dev", "/root/.ssh", "/var/run",
    "/usr/bin", "/usr/sbin", "/bin", "/sbin", "/lib", "/lib64",
}
SYSTEM_PATHS_WIN = {
    "C:\\Windows", "C:\\Program Files", "C:\\Program Files (x86)",
    "C:\\ProgramData", "%SystemRoot%", "C:\\$Recycle.Bin",
}


@dataclass
class PathDecision:
    allowed: bool
    reason: str = ""
    path: Path | None = None
    risk: RiskLevel = RiskLevel.READ


class FilesystemPolicy:
    def __init__(
        self,
        workspace_root: Path | str,
        permission_mode: str = "BALANCED",
        allow_outside: bool | None = None,
        writable_extra: Iterable[Path | str] = (),
    ) -> None:
        self.root = Path(workspace_root).expanduser().resolve()
        self.mode = permission_mode.upper()
        # AUTONOMOUS may still work outside the root; other modes may not.
        self.allow_outside = (
            allow_outside if allow_outside is not None else (self.mode == "AUTONOMOUS")
        )
        self.extra_writable = [Path(p).expanduser().resolve() for p in writable_extra]
        self.system_paths = SYSTEM_PATHS_LINUX | SYSTEM_PATHS_WIN

    # ------------------------------------------------------------------ #
    def resolve(self, candidate: Path | str, must_exist: bool = False) -> Path:
        p = Path(candidate).expanduser()
        if not p.is_absolute():
            p = self.root / p
        # `.resolve()` collapses `..` so traversal cannot escape the check.
        try:
            return p.resolve()
        except (OSError, RuntimeError):
            return p.absolute()

    def _inside(self, path: Path, base: Path) -> bool:
        try:
            path.relative_to(base)
            return True
        except ValueError:
            return False

    # ------------------------------------------------------------------ #
    def check(self, candidate: Path | str, intent: str = "read",
              must_exist: bool = False) -> PathDecision:
        p = self.resolve(candidate)
        sp = str(p)

        if any(sp == s or sp.startswith(s + "/") or sp.startswith(s + "\\") for s in self.system_paths):
            return PathDecision(False, f"system path protected: {sp}", p, RiskLevel.HIGH)

        inside_root = self._inside(p, self.root)
        if not inside_root and not self.allow_outside:
            if not any(self._inside(p, e) for e in self.extra_writable):
                return PathDecision(
                    False, f"outside workspace root {self.root}", p, RiskLevel.HIGH
                )

        if intent == "write":
            if self.mode == "LOCKED":
                return PathDecision(False, "LOCKED mode is read-only", p, RiskLevel.HIGH)
            if not inside_root and self.mode != "AUTONOMOUS":
                if not any(self._inside(p, e) for e in self.extra_writable):
                    return PathDecision(
                        False, "write outside workspace requires AUTONOMOUS mode", p,
                        RiskLevel.HIGH,
                    )

        if must_exist and not p.exists():
            return PathDecision(False, f"path does not exist: {p}", p, RiskLevel.READ)

        risk = RiskLevel.READ if intent == "read" else RiskLevel.MEDIUM
        return PathDecision(True, "", p, risk)
