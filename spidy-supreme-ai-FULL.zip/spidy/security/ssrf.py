"""Network egress policy (SSRF + domain controls).

Every outbound request — web fetch, search, browser navigation, model provider,
MCP transport — passes through here. The default posture is deny for anything
that can reach the host's own network or a cloud metadata service.
"""
from __future__ import annotations

import ipaddress
import socket
from dataclasses import dataclass
from urllib.parse import urlparse

DEFAULT_ALLOWED_SCHEMES = {"http", "https"}

# Metadata / control-plane endpoints. These are the highest-value SSRF target
# and are blocked outright regardless of the rest of the URL.
METADATA_HOSTS = {
    "169.254.169.254", "169.254.170.2", "metadata.google.internal",
    "metadata.goog", "100.100.100.200", "169.254.169.253",
    "metadata.azure.com", "instance-data.ec2.internal",
}


@dataclass
class NetworkDecision:
    allowed: bool
    reason: str = ""
    host: str = ""
    resolved_ips: list[str] | None = None

    def __bool__(self) -> bool:
        return self.allowed


class SSRFPolicy:
    """Resolve-then-check. DNS is resolved before every decision because a
    hostname can be rebound between check and connect (DNS rebinding)."""

    def __init__(
        self,
        allow_network: bool = True,
        allowed_schemes: set[str] | None = None,
        domain_allowlist: set[str] | None = None,
        domain_blocklist: set[str] | None = None,
        allow_private: bool = False,
        allow_localhost: bool = False,
    ) -> None:
        self.allow_network = allow_network
        self.allowed_schemes = allowed_schemes or DEFAULT_ALLOWED_SCHEMES
        self.domain_allowlist = {d.lower() for d in (domain_allowlist or set())}
        self.domain_blocklist = {d.lower() for d in (domain_blocklist or set())}
        self.allow_private = allow_private
        self.allow_localhost = allow_localhost

    # ------------------------------------------------------------------ #
    def check(self, url: str) -> NetworkDecision:
        if not self.allow_network:
            return NetworkDecision(False, "network access disabled by policy", host=url)

        try:
            p = urlparse(url)
        except ValueError as exc:
            return NetworkDecision(False, f"malformed URL: {exc}", host=url)

        scheme = (p.scheme or "").lower()
        if scheme not in self.allowed_schemes:
            return NetworkDecision(
                False, f"scheme '{scheme}' not allowed (file/gopher/data are blocked)", host=url
            )

        host = (p.hostname or "").lower().rstrip(".")
        if not host:
            return NetworkDecision(False, "URL has no host", host=url)

        if host in METADATA_HOSTS:
            return NetworkDecision(False, f"cloud metadata endpoint blocked: {host}", host=host)

        for blocked in self.domain_blocklist:
            if host == blocked or host.endswith("." + blocked):
                return NetworkDecision(False, f"domain blocked by policy: {host}", host=host)

        if self.domain_allowlist:
            ok = any(host == d or host.endswith("." + d) for d in self.domain_allowlist)
            if not ok:
                return NetworkDecision(False, f"host not in allowlist: {host}", host=host)

        if host in ("localhost", "localhost.localdomain") or host.endswith(".localhost"):
            if not self.allow_localhost:
                return NetworkDecision(False, f"localhost blocked: {host}", host=host)

        # Literal IP?
        try:
            ip = ipaddress.ip_address(host)
        except ValueError:
            ip = None

        if ip is not None:
            return self._check_ip(ip, host)

        # Hostname — resolve and check every answer.
        try:
            infos = socket.getaddrinfo(host, None)
        except (socket.gaierror, UnicodeError) as exc:
            return NetworkDecision(False, f"DNS resolution failed: {exc}", host=host)

        resolved = sorted({i[4][0] for i in infos})
        for raw in resolved:
            try:
                decision = self._check_ip(ipaddress.ip_address(raw), host)
            except ValueError:
                continue
            if not decision.allowed:
                return NetworkDecision(
                    False, f"{decision.reason} (resolved {raw})", host=host, resolved_ips=resolved
                )
        return NetworkDecision(True, "", host=host, resolved_ips=resolved)

    # ------------------------------------------------------------------ #
    def _check_ip(self, ip: ipaddress._BaseAddress, host: str) -> NetworkDecision:
        if ip.is_loopback and not self.allow_localhost:
            return NetworkDecision(False, f"loopback address blocked: {ip}", host=host)
        if ip.is_link_local:
            return NetworkDecision(False, f"link-local address blocked: {ip}", host=host)
        if ip.is_multicast:
            return NetworkDecision(False, f"multicast address blocked: {ip}", host=host)
        if ip.is_reserved or ip.is_unspecified:
            return NetworkDecision(False, f"reserved address blocked: {ip}", host=host)
        if ip.is_private and not self.allow_private:
            return NetworkDecision(False, f"private address blocked: {ip}", host=host)
        return NetworkDecision(True, "", host=host)


def policy_from_settings(settings) -> SSRFPolicy:
    """Local model servers legitimately live on loopback, so allow that back."""
    return SSRFPolicy(
        allow_network=settings.allow_network,
        allow_localhost=True,      # needed for Ollama / llama.cpp
        allow_private=False,
    )
