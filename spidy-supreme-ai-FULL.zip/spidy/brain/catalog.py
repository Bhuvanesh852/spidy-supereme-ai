"""Model provider catalog.

One table describing every provider SPIDY can talk to: where it lives, which
env var holds its key, what it costs, and which models it serves by default.

Keeping this declarative is the point. Adding a provider should be one line
here, not a new class — and every field that differs (auth header, model
catalog, priority) is data rather than a code path someone has to remember to
test.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class ModelSpec:
    """One model, as advertised by a provider."""

    id: str
    context: int = 128_000
    tools: bool = True
    vision: bool = False
    reasoning: bool = True
    cost_per_1k: float = 0.0        # USD per 1k tokens, blended in/out
    note: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id, "context": self.context, "tools": self.tools,
            "vision": self.vision, "reasoning": self.reasoning,
            "cost_per_1k": self.cost_per_1k, "note": self.note,
        }


@dataclass(frozen=True)
class ProviderSpec:
    """Everything needed to register and use a provider."""

    slug: str
    label: str
    kind: str                          # "openai" | "anthropic" | "google"
    key_env: str
    key_field: str                     # Settings attribute holding the key
    base_url: str = ""
    priority: int = 8                  # lower wins when ranking
    docs: str = ""
    models: tuple[ModelSpec, ...] = field(default_factory=tuple)
    # Cheap, fast, or a deliberate bargain — used as the default when the
    # user hasn't pinned a model. Local-first providers pick the small one.
    default_model: str = ""

    @property
    def endpoint(self) -> str:
        return self.base_url.rstrip("/")

    def to_dict(self) -> dict[str, Any]:
        return {
            "slug": self.slug, "label": self.label, "kind": self.kind,
            "key_env": self.key_env, "configured": False, "reachable": False,
            "models": [m.to_dict() for m in self.models],
            "default_model": self.default_model or (self.models[0].id if self.models else ""),
            "docs": self.docs, "local": self.kind == "local",
        }


# --------------------------------------------------------------------------- #
# the catalog
# --------------------------------------------------------------------------- #

PROVIDERS: dict[str, ProviderSpec] = {p.slug: p for p in [

    # ---- local ---------------------------------------------------------- #
    ProviderSpec(
        slug="ollama", label="Ollama", kind="local",
        key_env="", key_field="", base_url="http://127.0.0.1:11434", priority=1,
        docs="https://ollama.com/library",
        models=(),
    ),
    ProviderSpec(
        slug="llamacpp", label="llama.cpp", kind="local",
        key_env="", key_field="", base_url="http://127.0.0.1:8080", priority=1,
        docs="https://github.com/ggml-org/llama.cpp",
        models=(),
    ),

    # ---- aggregators ---------------------------------------------------- #
    ProviderSpec(
        slug="openrouter", label="OpenRouter", kind="openai",
        key_env="OPENROUTER_API_KEY", key_field="openrouter_api_key",
        base_url="https://openrouter.ai/api/v1", priority=2,
        docs="https://openrouter.ai/models",
        default_model="anthropic/claude-sonnet-4.5",
        models=(
            ModelSpec("anthropic/claude-sonnet-4.5", 200_000, vision=True, cost_per_1k=0.006),
            ModelSpec("openai/gpt-4o", 128_000, vision=True, cost_per_1k=0.005),
            ModelSpec("google/gemini-2.5-pro", 1_048_576, vision=True, cost_per_1k=0.003),
            ModelSpec("meta-llama/llama-3.3-70b-instruct", 128_000, cost_per_1k=0.0002),
            ModelSpec("qwen/qwen-2.5-coder-32b-instruct", 32_768, cost_per_1k=0.0002),
            ModelSpec("deepseek/deepseek-chat", 64_000, cost_per_1k=0.0003),
        ),
    ),

    # ---- first-party ---------------------------------------------------- #
    ProviderSpec(
        slug="anthropic", label="Anthropic", kind="anthropic",
        key_env="ANTHROPIC_API_KEY", key_field="anthropic_api_key",
        base_url="https://api.anthropic.com", priority=4,
        docs="https://docs.anthropic.com/en/docs/about-claude/models",
        default_model="claude-sonnet-4-5",
        models=(
            ModelSpec("claude-opus-4-5", 200_000, vision=True, cost_per_1k=0.015,
                      note="strongest; expensive"),
            ModelSpec("claude-sonnet-4-5", 200_000, vision=True, cost_per_1k=0.006,
                      note="best balance for agents"),
            ModelSpec("claude-haiku-4-5", 200_000, vision=True, cost_per_1k=0.001,
                      note="fast, cheap"),
        ),
    ),
    ProviderSpec(
        slug="openai", label="OpenAI", kind="openai",
        key_env="OPENAI_API_KEY", key_field="openai_api_key",
        base_url="https://api.openai.com/v1", priority=5,
        docs="https://platform.openai.com/docs/models",
        default_model="gpt-4o",
        models=(
            ModelSpec("gpt-4o", 128_000, vision=True, cost_per_1k=0.005),
            ModelSpec("gpt-4o-mini", 128_000, vision=True, cost_per_1k=0.0002,
                      note="cheap workhorse"),
            ModelSpec("gpt-4.1", 1_047_576, vision=True, cost_per_1k=0.002,
                      note="large context"),
            ModelSpec("o3-mini", 200_000, reasoning=True, cost_per_1k=0.0015,
                      note="reasoning"),
        ),
    ),
    ProviderSpec(
        slug="google", label="Google AI Studio", kind="google",
        key_env="GOOGLE_API_KEY", key_field="google_api_key",
        base_url="https://generativelanguage.googleapis.com/v1beta", priority=5,
        docs="https://ai.google.dev/gemini-api/docs/models",
        default_model="gemini-2.5-flash",
        models=(
            ModelSpec("gemini-2.5-pro", 1_048_576, vision=True, cost_per_1k=0.0025,
                      note="longest context"),
            ModelSpec("gemini-2.5-flash", 1_048_576, vision=True, cost_per_1k=0.0003,
                      note="fast + very cheap"),
            ModelSpec("gemini-2.5-flash-lite", 1_048_576, vision=True,
                      cost_per_1k=0.0001, note="cheapest"),
        ),
    ),

    # ---- fast / cheap inference clouds ---------------------------------- #
    ProviderSpec(
        slug="groq", label="Groq", kind="openai",
        key_env="GROQ_API_KEY", key_field="groq_api_key",
        base_url="https://api.groq.com/openai/v1", priority=3,
        docs="https://console.groq.com/docs/models",
        default_model="llama-3.3-70b-versatile",
        models=(
            ModelSpec("llama-3.3-70b-versatile", 128_000, cost_per_1k=0.0006,
                      note="very low latency"),
            ModelSpec("qwen/qwen-2.5-32b", 32_768, cost_per_1k=0.0003),
            ModelSpec("moonshotai/kimi-k2-instruct", 128_000, cost_per_1k=0.001),
        ),
    ),
    ProviderSpec(
        slug="together", label="Together AI", kind="openai",
        key_env="TOGETHER_API_KEY", key_field="together_api_key",
        base_url="https://api.together.xyz/v1", priority=6,
        docs="https://docs.together.ai/docs/serverless-models",
        default_model="meta-llama/Llama-3.3-70B-Instruct-Turbo",
        models=(
            ModelSpec("meta-llama/Llama-3.3-70B-Instruct-Turbo", 128_000,
                      cost_per_1k=0.0008),
            ModelSpec("Qwen/Qwen2.5-72B-Instruct-Turbo", 32_768, cost_per_1k=0.0008),
        ),
    ),
    ProviderSpec(
        slug="deepseek", label="DeepSeek", kind="openai",
        key_env="DEEPSEEK_API_KEY", key_field="deepseek_api_key",
        base_url="https://api.deepseek.com/v1", priority=5,
        docs="https://api-docs.deepseek.com",
        default_model="deepseek-chat",
        models=(
            ModelSpec("deepseek-chat", 64_000, cost_per_1k=0.0002,
                      note="very cheap, good at code"),
            ModelSpec("deepseek-reasoner", 64_000, reasoning=True,
                      cost_per_1k=0.0006, note="chain-of-thought"),
        ),
    ),
    ProviderSpec(
        slug="mistral", label="Mistral", kind="openai",
        key_env="MISTRAL_API_KEY", key_field="mistral_api_key",
        base_url="https://api.mistral.ai/v1", priority=6,
        docs="https://docs.mistral.ai/getting-started/models",
        default_model="mistral-large-latest",
        models=(
            ModelSpec("mistral-large-latest", 128_000, cost_per_1k=0.002),
            ModelSpec("codestral-latest", 256_000, cost_per_1k=0.0003,
                      note="code specialised"),
        ),
    ),
    ProviderSpec(
        slug="xai", label="xAI (Grok)", kind="openai",
        key_env="XAI_API_KEY", key_field="xai_api_key",
        base_url="https://api.x.ai/v1", priority=5,
        docs="https://docs.x.ai/docs/models",
        default_model="grok-4",
        models=(
            ModelSpec("grok-4", 256_000, vision=True, cost_per_1k=0.003),
            ModelSpec("grok-3-mini", 131_072, cost_per_1k=0.0003),
        ),
    ),
    ProviderSpec(
        slug="fireworks", label="Fireworks AI", kind="openai",
        key_env="FIREWORKS_API_KEY", key_field="fireworks_api_key",
        base_url="https://api.fireworks.ai/inference/v1", priority=6,
        docs="https://docs.fireworks.ai/api-reference",
        default_model="accounts/fireworks/models/deepseek-v3",
        models=(
            ModelSpec("accounts/fireworks/models/deepseek-v3", 128_000,
                      cost_per_1k=0.0009),
            ModelSpec("accounts/fireworks/models/qwen2p5-coder-32b", 32_768,
                      cost_per_1k=0.0002),
        ),
    ),
    ProviderSpec(
        slug="cerebras", label="Cerebras", kind="openai",
        key_env="CEREBRAS_API_KEY", key_field="cerebras_api_key",
        base_url="https://api.cerebras.ai/v1", priority=3,
        docs="https://inference-docs.cerebras.ai/models/overview",
        default_model="llama-3.3-70b",
        models=(
            ModelSpec("llama-3.3-70b", 128_000, cost_per_1k=0.0006,
                      note="very low latency"),
            ModelSpec("qwen-3-235b-a22b-instruct-2507", 65_536, cost_per_1k=0.0006),
        ),
    ),

    # ---- the floor ------------------------------------------------------ #
    # Not a remote API: the deterministic engine that keeps the system working
    # with no key, no server, and no network. Listed so the UI can show it as
    # the always-available option rather than hiding the fact that it exists.
    ProviderSpec(
        slug="native", label="Native engine", kind="local",
        key_env="", key_field="", base_url="", priority=99,
        docs="",
        default_model="native",
        models=(ModelSpec("native", context=32_768, tools=True, note="no model required"),),
    ),
]}


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #


def get_provider(slug: str) -> ProviderSpec | None:
    return PROVIDERS.get(slug)


def list_providers() -> list[ProviderSpec]:
    return sorted(PROVIDERS.values(), key=lambda p: (p.priority, p.label))


def configured_providers(settings) -> list[ProviderSpec]:
    """Providers that have a key (or are local) and cloud use is permitted."""
    if not settings.allow_cloud or settings.offline_only:
        return [p for p in PROVIDERS.values() if p.kind == "local"]
    out = []
    for p in PROVIDERS.values():
        if p.kind == "local":
            out.append(p)
        elif getattr(settings, p.key_field, ""):
            out.append(p)
    return sorted(out, key=lambda p: (p.priority, p.label))


def default_model_for(settings, slug: str) -> str:
    """Resolve the model to use for a provider.

    Explicit pin wins, then whatever the provider is actually serving, then
    the catalog default. A model the account can't reach is worse than a
    slightly worse one it can.
    """
    pinned = (settings.provider_models or {}).get(slug)
    if pinned:
        return pinned
    spec = PROVIDERS.get(slug)
    if spec is None:
        return ""
    return spec.default_model or (spec.models[0].id if spec.models else "")


def model_capabilities(slug: str, model: str) -> dict[str, Any]:
    """Capability metadata for one model, falling back to sane defaults."""
    spec = PROVIDERS.get(slug)
    if spec is None:
        return {"context": 32_768, "tools": True, "vision": False,
                "cost_per_1k": 0.0}
    for m in spec.models:
        if m.id == model:
            return {"context": m.context, "tools": m.tools, "vision": m.vision,
                    "reasoning": m.reasoning, "cost_per_1k": m.cost_per_1k}
    # Unknown model on a known provider: assume modest but usable.
    return {"context": 32_768, "tools": True, "vision": False,
            "reasoning": True, "cost_per_1k": 0.0}


def context_window(slug: str, model: str) -> int:
    return int(model_capabilities(slug, model)["context"])
