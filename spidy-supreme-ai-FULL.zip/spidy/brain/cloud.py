"""Google Gemini (AI Studio) and Anthropic Claude providers.

These two do not speak the OpenAI wire format, so they get real
implementations rather than a base_url override. Everything else in the
catalog reuses `OpenAICompatibleProvider`.

Both follow the same contract as every provider here: never raise, always
return an `LLMResponse`, and put the failure in `.error`. A provider that
throws takes the whole task down; a provider that reports an error lets the
router move on to the next one.
"""
from __future__ import annotations

import json
import time
from typing import Any

import httpx

from ..core.schemas import LLMResponse, ModelCapability
from .providers import BaseProvider


def _short(exc: Exception, n: int = 200) -> str:
    return f"{type(exc).__name__}: {exc}"[:n]


def _tool_schemas(tools: list[dict[str, Any]] | None, fmt: str) -> list[dict[str, Any]]:
    """Translate SPIDY's tool schema into a provider-native one."""
    out: list[dict[str, Any]] = []
    for t in tools or []:
        params = t.get("input_schema") or t.get("parameters") or {}
        if fmt == "google":
            # Gemini declares parameters under functionDeclarations.
            out.append({
                "name": t["name"],
                "description": t.get("description", ""),
                "parameters": {
                    "type": "OBJECT",
                    "properties": {
                        k: {"type": _gemini_type(v)} for k, v in params.get("properties", {}).items()
                    } or {"type": "OBJECT"},
                    "required": params.get("required", []),
                },
            })
        else:  # anthropic
            out.append({
                "name": t["name"],
                "description": t.get("description", ""),
                "input_schema": {
                    "type": "object",
                    "properties": params.get("properties", {}),
                    "required": params.get("required", []),
                },
            })
    return out


_JSON_TO_GEMINI = {
    "string": "STRING", "integer": "INTEGER", "number": "NUMBER",
    "boolean": "BOOLEAN", "array": "ARRAY", "object": "OBJECT",
}


def _gemini_type(spec: dict[str, Any]) -> str:
    return _JSON_TO_GEMINI.get(str(spec.get("type", "string")).lower(), "STRING")


# --------------------------------------------------------------------------- #
# Google Gemini
# --------------------------------------------------------------------------- #


class GoogleProvider(BaseProvider):
    """Gemini via the Generative Language API (AI Studio or Vertex)."""

    name = "google"

    def __init__(self, settings, api_key: str = "", base_url: str = "",
                 priority: int = 5) -> None:
        super().__init__(settings)
        self.api_key = api_key
        self.base_url = (base_url or "https://generativelanguage.googleapis.com/v1beta").rstrip("/")
        self._priority = priority

    @property
    def available(self) -> bool:
        return bool(self.api_key) and not self.settings.offline_only \
            and self.settings.allow_cloud

    def capabilities(self, model: str) -> ModelCapability:
        from .catalog import model_capabilities
        caps = model_capabilities(self.name, model)
        return ModelCapability(
            name=model, provider=self.name, supports_tools=caps["tools"],
            supports_json_schema=True, supports_vision=caps.get("vision", True),
            context_window=caps["context"], priority=self._priority, local=False,
            cost_per_1k=caps.get("cost_per_1k", 0.0),
        )

    async def probe(self) -> tuple[bool, list[str]]:
        try:
            models = await asyncio_wait(self.list_models(), 6.0)
            return True, [m for m in models if m]
        except Exception as exc:  # noqa: BLE001
            return False, [str(exc)[:80]]

    async def list_models(self) -> list[str]:
        async with httpx.AsyncClient(timeout=6) as c:
            r = await c.get(f"{self.base_url}/models",
                            headers={"x-goog-api-key": self.api_key})
            r.raise_for_status()
            data = r.json()
        return [m["name"].split("/")[-1]
                for m in data.get("models", [])
                if m.get("name")]

    async def chat(self, messages, model, tools=None, temperature=0.2,
                   max_tokens=2048, json_mode=False) -> LLMResponse:
        start = time.perf_counter()
        # Gemini keys the key into the URL rather than a header, and the path
        # carries the model name.
        url = (f"{self.base_url}/models/{model}:generateContent"
               f"?key={self.api_key}")

        system = "\n\n".join(m.content for m in messages if m.role == "system")
        contents = [
            {"role": "model" if m.role == "assistant" else "user",
             "parts": [{"text": m.content}]}
            for m in messages if m.role != "system"
        ]
        gen: dict[str, Any] = {"temperature": temperature,
                               "maxOutputTokens": max_tokens}
        if json_mode:
            gen["responseMimeType"] = "application/json"
        payload: dict[str, Any] = {"contents": contents, "generationConfig": gen}
        if system:
            payload["systemInstruction"] = {"parts": [{"text": system}]}
        if tools:
            payload["tools"] = [{"functionDeclarations": _tool_schemas(tools, "google")}]

        try:
            async with httpx.AsyncClient(timeout=self.settings.request_timeout) as c:
                r = await c.post(url, json=payload)
                r.raise_for_status()
                data = r.json()
        except Exception as exc:  # noqa: BLE001
            return LLMResponse(error=f"google: {_short(exc)}", provider=self.name, model=model)

        text_parts: list[str] = []
        calls: list[dict[str, Any]] = []
        for cand in data.get("candidates", []) or []:
            for part in (cand.get("content", {}) or {}).get("parts", []) or []:
                if part.get("text"):
                    text_parts.append(part["text"])
                fc = part.get("functionCall")
                if fc:
                    calls.append({"name": fc.get("name", ""),
                                  "arguments": fc.get("args", {}) or {}})
        usage = data.get("usageMetadata", {}) or {}
        return LLMResponse(
            text="".join(text_parts), tool_calls=calls,
            provider=self.name, model=model,
            prompt_tokens=usage.get("promptTokenCount", 0),
            completion_tokens=usage.get("candidatesTokenCount", 0),
            latency_ms=int((time.perf_counter() - start) * 1000),
        )


# --------------------------------------------------------------------------- #
# Anthropic
# --------------------------------------------------------------------------- #


class AnthropicProvider(BaseProvider):
    """Claude via the Messages API."""

    name = "anthropic"

    def __init__(self, settings, api_key: str = "", base_url: str = "",
                 priority: int = 4) -> None:
        super().__init__(settings)
        self.api_key = api_key
        self.base_url = (base_url or "https://api.anthropic.com").rstrip("/")
        self.version = "2023-06-01"
        self._priority = priority

    @property
    def available(self) -> bool:
        return bool(self.api_key) and not self.settings.offline_only \
            and self.settings.allow_cloud

    def capabilities(self, model: str) -> ModelCapability:
        from .catalog import model_capabilities
        caps = model_capabilities(self.name, model)
        return ModelCapability(
            name=model, provider=self.name, supports_tools=caps["tools"],
            supports_json_schema=True, supports_vision=caps.get("vision", True),
            context_window=caps["context"], priority=self._priority, local=False,
            cost_per_1k=caps.get("cost_per_1k", 0.0),
        )

    async def probe(self) -> tuple[bool, list[str], str]:
        if not self.api_key:
            return False, [], "no API key"
        try:
            async with httpx.AsyncClient(timeout=8) as c:
                r = await c.get(f"{self.base_url}/v1/models", headers=self._headers())
        except Exception as exc:  # noqa: BLE001
            return False, [], f"unreachable: {_short(exc, 70)}"
        if r.status_code in (401, 403):
            return False, [], f"auth rejected ({r.status_code}) — check the key"
        if r.status_code >= 400:
            return False, [], f"HTTP {r.status_code}"
        try:
            data = r.json()
        except ValueError:
            return True, [], ""
        return True, [m.get("id", "") for m in data.get("data", [])
                      if m.get("id")], ""

    async def list_models(self) -> list[str]:
        usable, models, _ = await self.probe()
        return models if usable else []

    def _headers(self) -> dict[str, str]:
        return {
            "x-api-key": self.api_key,
            "anthropic-version": self.version,
            "content-type": "application/json",
        }

    async def chat(self, messages, model, tools=None, temperature=0.2,
                   max_tokens=2048, json_mode=False) -> LLMResponse:
        start = time.perf_counter()
        system = "\n\n".join(m.content for m in messages if m.role == "system")
        # Anthropic takes a bare alternating list — no 'system' role inline.
        convo = [{"role": m.role, "content": m.content}
                 for m in messages if m.role != "system"]

        payload: dict[str, Any] = {
            "model": model, "messages": convo,
            "max_tokens": max_tokens, "temperature": temperature,
        }
        if system:
            payload["system"] = system
        if tools:
            payload["tools"] = _tool_schemas(tools, "anthropic")
        if json_mode:
            # There's no JSON mode; steer it in the system prompt instead.
            payload["system"] = ((system + "\n\n") if system else "") + \
                "Respond with a single valid JSON object and nothing else."

        try:
            async with httpx.AsyncClient(timeout=self.settings.request_timeout) as c:
                r = await c.post(f"{self.base_url}/v1/messages",
                                 json=payload, headers=self._headers())
                r.raise_for_status()
                data = r.json()
        except Exception as exc:  # noqa: BLE001
            return LLMResponse(error=f"anthropic: {_short(exc)}", provider=self.name, model=model)

        text_parts: list[str] = []
        calls: list[dict[str, Any]] = []
        for block in data.get("content", []) or []:
            btype = block.get("type")
            if btype == "text":
                text_parts.append(block.get("text", ""))
            elif btype == "tool_use":
                calls.append({"name": block.get("name", ""),
                              "arguments": block.get("input", {}) or {}})
        usage = data.get("usage", {}) or {}
        return LLMResponse(
            text="".join(text_parts), tool_calls=calls,
            provider=self.name, model=model,
            prompt_tokens=usage.get("input_tokens", 0),
            completion_tokens=usage.get("output_tokens", 0),
            latency_ms=int((time.perf_counter() - start) * 1000),
        )


# --------------------------------------------------------------------------- #
# shared helper
# --------------------------------------------------------------------------- #


async def asyncio_wait(awaitable: Any, timeout: float):
    """Await with a timeout. Kept here so providers share one idiom."""
    import asyncio
    return await asyncio.wait_for(awaitable, timeout)
