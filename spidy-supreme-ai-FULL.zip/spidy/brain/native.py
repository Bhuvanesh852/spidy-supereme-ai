"""The native brain.

This is what makes SPIDY genuinely offline-capable. It is a real reasoning
engine — intent classification, task decomposition, tool selection, argument
inference, result summarization, failure diagnosis — implemented as
deterministic analysis rather than learned weights.

It is not a chatbot pretending to be an agent. It does the same work an LLM
would do for the mechanical parts of the loop, and it is always the last
resort so SPIDY never hard-fails when a model server is down.

What it does well: structure. Route the request, build a correct plan, choose
the right tool, fill in obvious arguments, summarize evidence honestly.
What it does not do: open-ended language generation. When a real model is
available it handles that.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any

from ..core.schemas import (
    LLMMessage, LLMResponse, ModelCapability, Plan, PlanStep, RiskLevel,
)

# --------------------------------------------------------------------------- #
# intent classification
# --------------------------------------------------------------------------- #

@dataclass
class Intent:
    kind: str                 # code | research | data | file | debug | explain | create | analyze
    confidence: float
    keywords: list[str] = field(default_factory=list)
    target_hint: str = ""
    needs_web: bool = False
    needs_code_exec: bool = False
    needs_files: bool = False
    mutating: bool = False
    complexity: int = 1       # 1 simple .. 5 very complex


INTENT_PATTERNS: list[tuple[str, list[str], float]] = [
    ("debug", ["fix", "bug", "error", "crash", "fails", "failing", "broken", "debug",
               "traceback", "exception", "regression", "not working", "why does",
               "stack trace", "segfault", "leak", "hang", "deadlock"], 0.9),
    ("code", ["implement", "refactor", "write a function", "add endpoint", "create a class",
              "migrate", "upgrade", "rewrite", "build a", "add feature", "implement",
              "scaffold", "integrate", "optimize", "optimise"], 0.85),
    ("research", ["research", "find out", "compare", "market", "landscape", "state of the art",
                  "latest", "recent", "news", "trend", "who is", "what is", "explain the",
                  "how does", "why", "history of", "pros and cons", "best practice"], 0.75),
    ("data", ["analyze", "analyse", "dataset", "csv", "statistics", "stats", "chart",
              "plot", "correlat", "distribution", "average", "regression", "classify",
              "cluster", "model", "train", "accuracy", "heatmap", "aggregate"], 0.8),
    ("security", ["vulnerab", "security", "exploit", "cve", "injection", "xss", "csrf",
                  "encrypt", "hardening", "audit", "permission", "auth bypass"], 0.85),
    ("create", ["create", "generate", "make", "scaffold", "draw", "image", "diagram",
                "chart", "render", "mockup", "design"], 0.7),
    ("file", ["open", "read", "find", "search", "list", "locate", "show me the file",
              "what files", "directory", "folder", "rename", "move", "copy"], 0.75),
    ("explain", ["explain", "what does", "how does", "meaning of", "walk me through",
                 "summarize", "summarise", "describe", "documentation for", "teach"], 0.8),
]

RESEARCH_MARKERS = re.compile(
    r"(?i)\b(latest|current|today|recent|news|as of \d{4}|20(2[4-9])|"
    r"market|price|stock|version \d|who (is|was)|compare|versus|vs\.?|best \w+ in)\b"
)
CODE_MARKERS = re.compile(
    r"(?i)\b(implement|refactor|debug|fix|build|compile|test|function|class|api|"
    r"endpoint|bug|error|migration|script|module|package|dependency)\b"
)
DATA_MARKERS = re.compile(
    r"(?i)\b(csv|excel|jsonl|parquet|dataset|dataframe|chart|plot|regression|"
    r"classification|cluster|analy[sz]e|statistics|mean|median|correlat)\b"
)


def classify_intent(request: str) -> Intent:
    """Score the request against intent families and pick the best."""
    text = request.lower()
    scores: dict[str, float] = {}
    hits: dict[str, list[str]] = {}
    for kind, keys, weight in INTENT_PATTERNS:
        found = [k for k in keys if k in text]
        if found:
            # More distinct matches = stronger signal, with diminishing returns.
            scores[kind] = weight * (1 - 0.7 ** len(found)) * min(len(found), 4) / 2
            hits[kind] = found

    for rx, kind, boost in ((RESEARCH_MARKERS, "research", 0.25),
                            (CODE_MARKERS, "code", 0.2),
                            (DATA_MARKERS, "data", 0.2)):
        if rx.search(text):
            scores[kind] = scores.get(kind, 0) + boost
            hits.setdefault(kind, []).append(rx.pattern[:20])

    if not scores:
        return Intent(kind="explain", confidence=0.35, complexity=2)

    kind = max(scores, key=lambda k: scores[k])
    conf = min(0.97, scores[kind] + 0.15)

    needs_web = bool(RESEARCH_MARKERS.search(text)) and kind in ("research", "explain")
    needs_code = bool(CODE_MARKERS.search(text)) or kind in ("code", "debug", "data")
    needs_files = kind in ("code", "debug", "file", "data")
    mutating = kind in ("code", "create") or bool(
        re.search(r"(?i)\b(fix|implement|add|remove|update|refactor|create|write|migrate)\b", text))

    # Complexity: explicit multi-step language, length, and conjunctions.
    steps = re.split(r"(?i)\b(?:and then|then|after that|also|, then|;\s*)\b", request)
    complexity = min(5, 1 + len([s for s in steps if s.strip()]) - 1 + (1 if conf > 0.8 else 0))
    if len(request) > 600:
        complexity = min(5, complexity + 1)
    if re.search(r"(?i)\b(across|entire|whole|all files|refactor the|end-to-end|migrate)\b", text):
        complexity = min(5, complexity + 1)

    return Intent(
        kind=kind, confidence=round(conf, 2), keywords=hits.get(kind, [])[:6],
        needs_web=needs_web, needs_code_exec=needs_code, needs_files=needs_files,
        mutating=mutating, complexity=max(1, complexity),
    )


# --------------------------------------------------------------------------- #
# planning
# --------------------------------------------------------------------------- #


def _decompose_by_verb(text: str, add, has) -> None:
    """Turn an explicit multi-clause request into one step per clause.

    Matched verbs are consumed as we go, so "read X and search for Y" yields two
    distinct steps instead of collapsing into one workspace_summary. Each verb
    maps to the narrowest tool that actually performs it.
    """
    # (regex over the request, tool, action, rationale)
    clauses = [
        (r"\bgit\s+(status|diff|log)\b", "git_status", "inspect", "check repo state"),
        (r"\b(search|grep|find\s+all|look\s+for|locate|scan)\b", "search_in_files",
         "inspect", "locate the content asked about"),
        (r"\b(read|open|show\s+me|cat|display|view)\b", "read_file",
         "read", "read the requested file"),
        (r"\b(list|ls)\b|\blist\s+(files|dir)\b", "list_files",
         "inspect", "list the directory"),
        (r"\b(run|execute)\s+(the\s+)?(tests?|test\s+suite)\b", "run_tests",
         "test", "prove it works"),
        (r"\b(git\s+diff|show\s+diff|what\s+changed)\b", "git_diff",
         "inspect", "review the diff"),
    ]
    for pattern, tool, action, why in clauses:
        if not has(tool):
            continue
        m = re.search(pattern, text)
        if not m:
            continue
        # Consume the matched span so a later clause can't re-fire the same verb.
        text = text[:m.start()] + text[m.end():]
        add(action, m.group(0).strip(), why, tool=tool)


def build_plan(request: str, intent: Intent, available_tools: set[str],
               max_steps: int = 24) -> Plan:
    """Deterministic plan synthesis.

    The design rule from the spec: smallest useful plan, reversible steps,
    explicit validation, no unnecessary tool usage. Every branch below is
    justified by something in the request, never speculative.
    """
    text = request.lower()
    steps: list[PlanStep] = []
    criteria: list[str] = []
    constraints: list[str] = []

    def add(action: str, target: str = "", rationale: str = "", *,
            tool: str = "", risk: RiskLevel = RiskLevel.READ, parallel: bool = True) -> None:
        if len(steps) >= max_steps:
            return
        if tool and tool not in available_tools:
            return
        steps.append(PlanStep(
            id=f"S{len(steps) + 1}", action=action, target=target,
            rationale=rationale, tool_hint=tool, risk=risk, parallel_safe=parallel,
        ))

    has = lambda t: t in available_tools  # noqa: E731

    # ---- 1. always understand the workspace when it matters ---------- #
    if intent.needs_files and has("workspace_summary"):
        add("inspect", ".", "map the project before changing anything",
            tool="workspace_summary", parallel=False)
    if intent.kind in ("code", "debug") and has("git_status"):
        add("inspect", "git", "know the current git state so changes are reversible",
            tool="git_status")

    # ---- 2. research branch ------------------------------------------- #
    if intent.needs_web:
        if has("search_web"):
            add("research", "current information", "gather up-to-date sources",
                tool="search_web", parallel=True)
        if has("fetch_url"):
            add("research", "primary sources", "read the sources, don't guess",
                tool="fetch_url", parallel=True)
        constraints.append("cite every factual claim; do not assert unverified facts")
        criteria.append("claims are backed by fetched sources")

    # ---- 3. RAG grounding --------------------------------------------- #
    if intent.kind in ("research", "explain", "data") and has("rag_search"):
        add("research", "private documents", "check indexed knowledge before guessing",
            tool="rag_search", parallel=True)

    # ---- 4. file inspection ------------------------------------------- #
    if intent.kind == "debug":
        if has("search_in_files"):
            add("inspect", "relevant symbols", "locate the code involved",
                tool="search_in_files")
        if has("file_stats"):
            add("inspect", "target file", "understand structure before editing",
                tool="file_stats")
        if has("run_command") and re.search(r"(?i)\b(run|reproduce|test|execute)\b", text):
            add("run", "reproduce the failure", "see the actual error before fixing",
                tool="run_command", risk=RiskLevel.MEDIUM)
    elif intent.kind in ("code",) and intent.mutating:
        if has("find_files"):
            add("inspect", "related files", "find the code to change", tool="find_files")
        if has("read_file"):
            add("read", "target file", "read before you edit", tool="read_file")
    elif intent.kind == "file":
        # A "file" request is whatever the user actually said — so decompose it
        # by verb rather than by bucket. Without this, "read main.py and search
        # for TODO, then show git status" collapses to workspace_summary alone.
        _decompose_by_verb(text, add, has)

    # ---- 5. data branch ----------------------------------------------- #
    if intent.kind == "data" and has("inspect_data"):
        add("inspect", "data file", "load and profile the data first", tool="inspect_data")
        add("run", "analysis", "compute the answer from the data", tool="run_python",
            risk=RiskLevel.MEDIUM)

    # ---- 6. image generation ------------------------------------------ #
    if intent.kind == "create" and re.search(r"(?i)\b(image|picture|photo|logo|icon|art|draw)\b", text):
        if has("generate_image"):
            add("create", "image", "generate the requested image", tool="generate_image",
                risk=RiskLevel.MEDIUM)

    # ---- 7. mutation -------------------------------------------------- #
    if intent.mutating and intent.kind in ("code", "debug"):
        if has("write_file") or has("edit_file"):
            add("edit", "target file", "make the smallest change that fixes the goal",
                tool="edit_file", risk=RiskLevel.MEDIUM, parallel=False)
        if has("run_lint"):
            add("verify", "static checks", "catch syntax/type errors cheaply", tool="run_lint",
                parallel=False)
        if has("run_tests"):
            add("test", "test suite", "prove the change works", tool="run_tests",
                risk=RiskLevel.MEDIUM, parallel=False)
            criteria.append("tests pass")
    elif intent.mutating and intent.kind == "create":
        if has("write_file"):
            add("create", "new artifact", "produce the requested output", tool="write_file",
                risk=RiskLevel.MEDIUM, parallel=False)

    # ---- 8. ML training ------------------------------------------------ #
    if re.search(r"(?i)\b(train|fit|model|classif|regress|neural|ml model)\b", text) \
            and has("train_model"):
        add("run", "train a model", "fit a real model on the provided data",
            tool="train_model", risk=RiskLevel.MEDIUM)
        criteria.append("model trained and evaluated with held-out data")

    # ---- 9. final verification ---------------------------------------- #
    if not steps:
        add("analyze", "request", "reason about the request directly")
        criteria.append("the question is answered directly and honestly")
    elif intent.kind in ("research", "explain", "data", "code", "debug"):
        add("verify", "final answer", "check every claim against gathered evidence",
            parallel=False)
        if not criteria:
            criteria.append("answer is grounded in the collected evidence")

    notes = ""
    if not intent.needs_web and intent.kind in ("research", "explain"):
        notes = ("No live sources are required for this request; SPIDY will answer from "
                 "local knowledge and indexed documents rather than fabricate citations.")
    if intent.confidence < 0.5:
        constraints.append("request is ambiguous — state the interpretation you used")

    return Plan(goal=request.strip()[:300], steps=steps, constraints=constraints,
                success_criteria=criteria, notes=notes)


# --------------------------------------------------------------------------- #
# argument inference
# --------------------------------------------------------------------------- #

_PATH_RE = re.compile(r"(?:^|[\s\"'`])([\w./\\-]+\.\w{1,12})(?:\b|$)")
_DIR_RE = re.compile(r"(?:^|\s)((?:[\w.-]+/){1,6}[\w.-]*)")
_IDENT_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]{2,})\b")
_URL_RE = re.compile(r"https?://[^\s\"'<>)\]]+")
_REGEX_RE = re.compile(r"/([^/\n]{2,80})/([gimsux]*)")
_FUNCTION_RE = re.compile(r"\b([a-z_][a-z0-9_]{2,})\s*\(")

STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "into", "please", "make",
    "find", "fix", "add", "create", "write", "read", "file", "files", "code", "test",
    "run", "check", "using", "use", "your", "you", "can", "should", "need", "want",
    "then", "also", "just", "now", "all", "any", "some", "how", "what", "why",
    "when", "where", "which", "does", "doesn", "not", "but", "has", "have", "was",
    "were", "will", "would", "could", "should", "there", "their", "them", "they",
    "about", "into", "over", "under", "out", "get", "set", "put", "let",
}

# Arguments that require genuine authorship (a model must write the content).
# A regex/pattern is NOT here — it's a mechanical extraction from the request.
_AUTHORSHIP_FIELDS = {
    "old_text", "new_text", "code", "script", "source_code", "body",
    "content", "text_body", "markdown", "prompt",
}


def infer_arguments(tool_name: str, request: str, tool_spec: dict[str, Any],
                    context: dict[str, Any] | None = None) -> dict[str, Any]:
    """Fill in a tool's required arguments from the request.

    This is where a small model wastes the most time; doing it deterministically
    both saves tokens and removes a whole class of failures.
    """
    schema = tool_spec.get("input_schema", {}) or tool_spec or {}
    props: dict[str, Any] = schema.get("properties", {}) or {}
    required: list[str] = schema.get("required", []) or []
    args: dict[str, Any] = dict((context or {}).get("prefilled", {}))
    text = request

    # Many tool schemas omit `required` entirely (every arg has a default). When
    # that happens the heuristic still has to fill the fillable args, or the tool
    # gets called with nothing and the plan step no-ops.
    if not required and props:
        required = [k for k in props
                    if k not in _AUTHORSHIP_FIELDS and k not in args]

    paths = _PATH_RE.findall(text)
    dirs = _DIR_RE.findall(text)
    urls = _URL_RE.findall(text)
    idents = [i for i in _IDENT_RE.findall(text) if i.lower() not in STOPWORDS]
    funcs = _FUNCTION_RE.findall(text)
    regexes = _REGEX_RE.findall(text)

    # Tools that operate on a directory, not a file. Feeding them a filename
    # turns "read main.py" into `workspace_summary(path="main.py")`, which then
    # globs inside a file. Only these take a path that may be a directory.
    _DIR_TOOLS = {"workspace_summary", "list_files", "find_files", "index_workspace",
                  "list_projects", "git_status", "git_add", "git_commit", "git_diff",
                  "git_log", "rag_search", "understand_project", "deep_research",
                  "search_in_files", "run_lint", "run_tests", "run_build", "run_python",
                  "run_node", "run_command"}
    _FILE_TOOLS = {"read_file", "edit_file", "write_file", "apply_patch", "file_diff",
                   "file_stats", "file_history", "move_file", "copy_file", "delete_file",
                   "analyze_image", "convert_document", "inspect_data", "train_model",
                   "predict", "query_data", "generate_chart"}

    def pick_path() -> str:
        wants_dir = tool_name not in _FILE_TOOLS
        if wants_dir:
            # A dir tool wants a directory. If the request named a bare
            # filename (no directory part), hand it the workspace root rather
            # than a file path it would then try to glob into.
            if dirs:
                return dirs[0].rstrip("/")
            return "."
        if paths:
            return paths[0]
        if dirs:
            return dirs[0].rstrip("/")
        return "."

    for key in required:
        typ = props.get(key, {}).get("type", "string")
        if key in args:
            continue
        # Never fabricate free-form content. If we can't confidently map the
        # request to a known argument name, leave it for the schema default.
        if key in _AUTHORSHIP_FIELDS:
            continue
        if key in ("path", "file", "filename", "source", "src", "file_path", "target_path"):
            args[key] = pick_path()
        elif key in ("directory", "dir", "cwd", "root", "path_prefix"):
            args[key] = dirs[0].rstrip("/") if dirs else "."
        elif key in ("url", "uri", "address", "link"):
            args[key] = urls[0] if urls else ""
        elif key in ("query", "question", "q", "text", "prompt", "search"):
            args[key] = request.strip()[:400]
        elif key == "regex":
            if regexes:
                args[key] = f"/{regexes[0][0]}/{regexes[0][1]}"
            else:
                # No explicit /pattern/ given. Search for the most salient
                # content word the user named ("search for TODO comments"),
                # which beats refusing the step outright.
                sal = [w for w in idents if len(w) > 2 and w.isupper() is False]
                caps = [w for w in re.findall(r"\b[A-Z][A-Z0-9_]{2,}\b", text)]
                word = (caps or sal or [None])[0]
                args[key] = re.escape(word) if word else ""
        elif key in ("pattern", "glob", "file_pattern"):
            args[key] = next((p for p in paths if "*" in p), "*")
        elif key in ("symbol", "identifier", "name", "function", "class_name", "var_name"):
            args[key] = (funcs or idents or ["main"])[0]
        elif key in ("paths", "files_list"):
            args[key] = paths[:20] or ["."]
        elif typ == "integer":
            args[key] = {"limit": 50, "count": 10, "max_results": 50,
                         "timeout": 60, "depth": 3, "n": 5, "top_k": 8,
                         "num_samples": 32, "epochs": 30}.get(key, 10)
        elif typ == "boolean":
            args[key] = True
        elif typ == "array":
            args[key] = paths[:10] or idents[:5]
        elif typ == "string" and key in ("query", "question", "q", "text", "search"):
            args[key] = request.strip()[:400]
        # Any other string is left unset: guessing a value the tool will act on
        # is worse than letting the schema default apply.

    # Never pass an obviously empty required string through.
    for k, v in list(args.items()):
        if isinstance(v, str) and not v.strip() and k in required:
            if k in ("path", "file", "source"):
                args[k] = "."
            elif k in ("url", "uri"):
                return {}
            elif k in _AUTHORSHIP_FIELDS:
                # These need real authorship. Returning None marks the tool as
                # un-plannable without a model, so the runtime skips the step
                # and reports the gap instead of thrashing on bad edits.
                return {}
            else:
                args[k] = request.strip()[:400]
    if any(not str(args.get(k, "x")).strip() for k in required if k in _AUTHORSHIP_FIELDS):
        return {}
    return {k: v for k, v in args.items() if k in props or not props}


# --------------------------------------------------------------------------- #
# tool selection
# --------------------------------------------------------------------------- #


def select_tool(intent: Intent, request: str, tools: dict[str, dict[str, Any]],
                done: set[str] | None = None) -> tuple[str, dict[str, Any]] | None:
    """Pick the single best next tool for the current situation."""
    done = done or set()
    text = request.lower()
    m = re.search(r"https?://[^\s\"'<>)\]]+", request)
    url = m.group(0) if m else None

    # An explicit URL in the request means fetch it.
    if url:
        for name in ("fetch_url", "open_url", "browser_navigate", "search_web"):
            if name in tools and name not in done:
                return name, infer_arguments(name, request, tools[name])

    ranking: list[tuple[float, str]] = []

    def consider(name: str, score: float) -> None:
        if name in tools and name not in done and score > 0:
            ranking.append((score, name))

    if intent.needs_web:
        consider("search_web", 0.9)
        consider("fetch_url", 0.7)
    if intent.kind == "debug":
        consider("run_command", 0.8)
        consider("search_in_files", 0.75)
        consider("run_tests", 0.6)
        consider("git_status", 0.5)
    if intent.needs_files:
        consider("workspace_summary", 0.6)
        consider("find_files", 0.55)
        consider("read_file", 0.5)
        consider("list_files", 0.4)
    if intent.kind == "data":
        consider("inspect_data", 0.85)
        consider("run_python", 0.6)
    if intent.kind == "create":
        consider("generate_image", 0.6)
        consider("write_file", 0.5)
    if intent.mutating:
        consider("edit_file", 0.55)
        consider("write_file", 0.45)
        consider("run_tests", 0.4)

    if not ranking:
        return None
    ranking.sort(reverse=True)
    name = ranking[0][1]
    return name, infer_arguments(name, request, tools[name])


# --------------------------------------------------------------------------- #
# synthesis
# --------------------------------------------------------------------------- #


def _readable_observation(obs: str) -> str:
    """Turn a raw ``tool(target): {json}`` observation into one human line.

    Tool results are structured data; pasting the JSON into the answer reads
    like a log, not a response. Pull out the field that actually matters for
    each tool, fall back to a compact one-liner, and never invent content.
    """
    m = re.match(r"^(\w+)\(([^)]*)\):\s*(.*)$", obs, re.S)
    if not m:
        return obs.replace("\n", " ")[:400]
    tool, target, rest = m.group(1), m.group(2), m.group(3).strip()

    # Try to parse the payload as JSON for a smarter summary.
    try:
        d = json.loads(rest)
    except (ValueError, TypeError):
        d = None

    try:
        return _format_tool_observation(tool, target, d, rest)
    except Exception:  # noqa: BLE001
        # Formatting must never fail a task. Fall back to a plain one-liner.
        return f"{tool}({target}): " + rest.replace("\n", " ")[:200]


def _format_tool_observation(tool: str, target: str, d: Any, rest: str) -> str:
    if tool == "read_file" and isinstance(d, dict):
        return f"read `{d.get('path', target)}` ({d.get('total_lines', '?')} lines, " \
               f"{d.get('language', 'text')})"
    if tool == "search_in_files" and isinstance(d, dict):
        return f"searched for matches — {d.get('count', 0)} hit(s) in " \
               f"{d.get('files', 0)} file(s)"
    if tool == "list_files" and isinstance(d, (dict, list)):
        # list_files reports {"entries": <int>, "tree": "<rendered>"}; older
        # shapes used a list. Accept either so the count is never a lie.
        if isinstance(d, dict) and isinstance(d.get("entries"), int):
            n = d["entries"]
        else:
            cand = d.get("entries", d) if isinstance(d, dict) else d
            n = len(cand) if isinstance(cand, (list, tuple, dict, str)) else 0
        return f"listed {n} entr{'y' if n == 1 else 'ies'} in `{target}`"
    if tool == "workspace_summary" and isinstance(d, dict):
        return f"mapped the workspace — {d.get('total_files', 0)} files, " \
               f"{d.get('total_bytes', 0)} bytes"
    if tool == "file_stats" and isinstance(d, dict):
        return f"inspected `{d.get('path', target)}` — " \
               f"{d.get('lines', '?')} lines"
    if tool == "find_files" and isinstance(d, dict):
        return f"found {d.get('count', 0)} file(s) matching `{target}`"
    if tool == "git_status" and isinstance(d, dict):
        if d.get("is_repo"):
            branch = d.get("branch", d.get("current_branch", "?"))
            return f"checked git state on `{branch}`"
        return "not a git repository (nothing to diff)"
    if tool in ("rag_search",) and isinstance(d, (dict, list)):
        return f"retrieved {len(d.get('results', d)) if isinstance(d, dict) else len(d)} chunk(s) from the index"
    if isinstance(d, dict):
        # Generic: name the first one or two informative fields.
        bits = []
        for k in ("output", "message", "summary", "result", "path", "count"):
            if k in d and d[k] not in (None, "", [], {}):
                v = d[k]
                v = str(v).replace("\n", " ") if not isinstance(v, (int, float)) else v
                bits.append(f"{k}={v[:60]}")
            if len(bits) >= 2:
                break
        if bits:
            return f"{tool}: " + "; ".join(bits)

    return f"{tool}({target}): " + rest.replace("\n", " ")[:200]


def synthesize(request: str, intent: Intent, observations: list[str],
               sources: list[dict[str, Any]], files: list[str],
               test_summary: dict[str, Any] | None = None) -> str:
    """Compose a final answer from evidence.

    Deliberately honest: states what was found, what was verified, and what
    was not. It never invents a finding it did not observe.
    """
    lines: list[str] = []
    kind_label = {
        "code": "Code task", "debug": "Debugging", "research": "Research",
        "data": "Data analysis", "file": "File task", "explain": "Explanation",
        "create": "Creation", "security": "Security review", "analyze": "Analysis",
    }.get(intent.kind, "Result")

    lines.append(f"**{kind_label}** — {request.strip()[:300]}")
    lines.append("")

    if test_summary:
        passed = test_summary.get("passed", 0)
        failed = test_summary.get("failed", 0) or test_summary.get("errors", 0)
        if passed or failed:
            verdict = "all green" if not failed else f"{failed} failing"
            lines.append(f"**Verification:** {passed} passed, {failed} failed — {verdict}.")
            lines.append("")
            for f in (test_summary.get("failures") or [])[:5]:
                lines.append(f"- {f}")
            if test_summary.get("failures") or failed:
                lines.append("")

    if files:
        lines.append("**Files touched**")
        for f in files[:12]:
            lines.append(f"- `{f}`")
        lines.append("")

    if observations:
        lines.append("**What SPIDY did**")
        for o in observations[-8:]:
            rendered = _readable_observation(o.strip())
            if rendered:
                lines.append(f"- {rendered[:400]}")
        lines.append("")

    if sources:
        lines.append("**Sources**")
        for s in sources[:8]:
            title = s.get("title") or s.get("url", "source")
            lines.append(f"- [{title}]({s.get('url', '')})")
        lines.append("")

    if not observations and not files and not sources:
        lines.append(
            "SPIDY completed this with its **native reasoning engine** — the "
            "deterministic planner, tool bus, and verification layer — with no "
            "language model running.\n\n"
            "That covers planning, searching, reading, running commands, and "
            "verifying. It does **not** cover open-ended writing: generating a "
            "code patch, drafting prose, or synthesizing novel analysis.\n\n"
            "**To enable full generative reasoning:**\n"
            "```\n"
            "ollama pull qwen2.5-coder:7b   # or gemma3:4b, llama3.1:8b\n"
            "ollama serve\n"
            "```\n"
            "SPIDY routes to it automatically on the next request. Everything "
            "already working — tools, RAG, CAG, security, verification — keeps "
            "working either way.")

    return "\n".join(lines).strip()


def diagnose_failure(tool: str, result_data: dict[str, Any],
                     error_message: str = "") -> tuple[str, str]:
    """Classify a failure and propose the next action. Used by the repair loop
    when no model is available to think about it."""
    blob = f"{error_message} {json.dumps(result_data, default=str)[:600]}".lower()
    rules: list[tuple[tuple[str, ...], str, str]] = [
        (("modulenotfounderror", "no module named", "cannot find module"),
         "missing_dependency", "install the missing package, then re-run"),
        (("filenotfounderror", "no such file", "not found"),
         "missing_file", "locate the correct path with find_files before re-running"),
        (("permission denied", "operation not permitted"),
         "permission", "adjust permissions or use an allowed path"),
        (("command not found", "is not recognized", "no such file or directory"),
         "missing_tool", "install the missing executable"),
        (("timed out", "timeout"),
         "timeout", "raise the timeout or reduce the workload"),
        (("connection refused", "econnrefused", "network is unreachable"),
         "provider_down", "start the local model server or fall back to native reasoning"),
        (("out of memory", "oom", "killed"),
         "memory", "reduce batch size or data volume"),
        (("syntaxerror", "invalid syntax", "unexpected token"),
         "syntax", "fix the syntax error at the reported line, then re-run"),
        (("importerror", "cannot import"),
         "import", "correct the import path or install the module"),
        (("test.*failed", "assertionerror", "assert"),
         "test_failure", "read the failing assertion and correct the implementation"),
        (("401", "403", "unauthorized", "invalid api key"),
         "auth", "check credentials or switch to a local provider"),
    ]
    for needles, cls, action in rules:
        if any(n in blob for n in needles):
            return cls, action
    if tool in ("read_file", "find_files", "list_files"):
        return "path_issue", "verify the path exists with list_files on its parent"
    if tool in ("run_command", "run_python", "run_node"):
        return "runtime_error", "re-run with a smaller reproduction to isolate the failure"
    return "unknown", "inspect the raw output and adjust the approach"


# --------------------------------------------------------------------------- #


class NativeProvider:
    """Drop-in provider so the router can always fall through to local logic."""

    name = "native"

    def __init__(self, settings=None) -> None:
        self.settings = settings

    @property
    def available(self) -> bool:
        return True

    async def probe(self) -> tuple[bool, list[str], str]:
        # Native is always here — that is the whole point of the floor.
        return True, ["native"], ""

    def capabilities(self, model: str = "native") -> ModelCapability:
        return ModelCapability(
            name="native", provider=self.name, supports_tools=True,
            supports_json_schema=True, supports_vision=False, supports_reasoning=True,
            supports_streaming=False, context_window=1_000_000, priority=99, local=True,
        )

    async def chat(self, messages: list[LLMMessage], model: str = "native",
                   tools: list[dict[str, Any]] | None = None, temperature: float = 0.2,
                   max_tokens: int = 2048, json_mode: bool = False) -> LLMResponse:
        """Handle the three structured jobs the runtime needs.

        Text generation is deliberately minimal — the native engine's value is
        in the deterministic planner, not in prose.
        """
        system = "\n".join(m.content for m in messages if m.role == "system")
        user = "\n".join(m.content for m in messages if m.role == "user")
        last = messages[-1].content if messages else ""
        tool_map = {t["name"]: t for t in (tools or [])}

        # Task: produce a plan.
        if "PLAN" in system.upper() and "goal" in user.lower() + system.lower():
            intent = classify_intent(user)
            plan = build_plan(user, intent, set(tool_map))
            return LLMResponse(
                text=json.dumps(plan.to_dict()), provider=self.name, model="native",
                prompt_tokens=len(user) // 4, completion_tokens=len(plan.to_dict()) // 4,
            )

        # Task: choose a tool.
        if tools and ("TOOL" in system.upper() or "tool" in system.lower()):
            intent = classify_intent(user)
            sel = select_tool(intent, user, tool_map)
            if sel:
                name, args = sel
                return LLMResponse(
                    text=json.dumps({"name": name, "arguments": args}),
                    provider=self.name, model="native",
                    prompt_tokens=len(user) // 4, completion_tokens=64,
                )
            return LLMResponse(
                text="No tool is appropriate for this step.",
                provider=self.name, model="native", prompt_tokens=len(user) // 4)

        # Task: final answer.
        # The runtime wraps evidence in a non-overridable policy preamble and
        # fences untrusted content. Both are scaffolding, not user content.
        from ..security.guard import UNTRUSTED_CLOSE, UNTRUSTED_OPEN

        def _clean(t: str) -> str:
            t = re.sub(r"(?is)\[SYSTEM POLICY.*?\]", "", t)
            t = re.sub(r"(?is)<UNTRUSTED_SOURCE.*?</UNTRUSTED_SOURCE>", "", t)
            if UNTRUSTED_OPEN in t and UNTRUSTED_CLOSE in t:
                t = t.split(UNTRUSTED_CLOSE)[-1]
            return t.strip()

        last_clean = _clean(last)
        user_clean = _clean(user)

        # Evidence (findings, sources, verification) lives inside the fenced
        # untrusted block, so parse it before the policy scaffolding is removed.
        findings_block = ""
        if UNTRUSTED_OPEN in last and UNTRUSTED_CLOSE in last:
            findings_block = last.split(UNTRUSTED_OPEN, 1)[1].rsplit(UNTRUSTED_CLOSE, 1)[0]
        if not findings_block:
            findings_block = last_clean

        fm = re.search(r"(?is)Findings:\s*\n(.*?)(?:\n\s*\nSources:|\Z)", findings_block)
        obs = [ln.strip(" -\t") for ln in (fm.group(1) if fm else "").splitlines()
               if ln.strip(" -\t")]

        # The runtime appends "User request: <text>\n\nAnswer:" — recover the text.
        m = re.search(r"User request:\s*(.+?)(?:\n\s*\n\s*Answer:|\Z)", user_clean, re.S)
        request = (m.group(1).strip() if m else user_clean.strip())[:2000]

        intent = classify_intent(request)
        srcs = [{"url": u} for u in re.findall(r"https?://[^\s\"'<>)\]]+", findings_block)][:8]
        files = re.findall(r"File:\s*(\S+)", findings_block)
        tm = re.search(r'"detail":\s*"(\d+)\s+passed,\s*(\d+)\s+failed"', findings_block)
        test_summary = {"passed": int(tm.group(1)), "failed": int(tm.group(2))} if tm else None
        text = synthesize(request, intent, obs, srcs, files, test_summary)
        return LLMResponse(
            text=text, provider=self.name, model="native",
            prompt_tokens=len(user) // 4, completion_tokens=len(text) // 4,
        )
