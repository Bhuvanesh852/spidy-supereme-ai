"""Model router.

Selects a provider + model per call based on capability, health, cost, and
policy. Degrades cleanly: if every remote provider fails, the native brain
answers rather than the task failing.
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any

from ..core.schemas import LLMMessage, LLMResponse, ModelCapability
from .native import NativeProvider, classify_intent
from .providers import BaseProvider, build_providers


@dataclass
class Health:
    consecutive_failures: int = 0
    last_error: str = ""
    last_ok: float = 0.0
    total_calls: int = 0
    total_failures: int = 0
    avg_latency_ms: float = 0.0

    @property
    def degraded(self) -> bool:
        # Three strikes and a provider is benched for a minute.
        return self.consecutive_failures >= 3 and (time.time() - self.last_ok) < 60

    def record_ok(self, latency_ms: int) -> None:
        self.consecutive_failures = 0
        self.last_ok = time.time()
        self.total_calls += 1
        self.avg_latency_ms = (
            latency_ms if not self.total_calls else
            self.avg_latency_ms * 0.8 + latency_ms * 0.2
        )

    def record_fail(self, error: str) -> None:
        self.consecutive_failures += 1
        self.total_failures += 1
        self.last_error = error[:200]


class ModelRouter:
    def __init__(self, settings) -> None:
        self.settings = settings
        self.providers: dict[str, BaseProvider] = {
            p.name: p for p in build_providers(settings)
        }
        self.health: dict[str, Health] = {n: Health() for n in self.providers}
        self.stats: dict[str, dict[str, Any]] = {
            n: {"calls": 0, "failures": 0, "tokens": 0, "latency_ms": 0} for n in self.providers
        }
        self._ollama_models: list[str] | None = None
        self._probe_cache: dict[str, tuple[float, bool, list[str], str]] = {}

    # ------------------------------------------------------------------ #
    def register(self, provider: BaseProvider) -> None:
        self.providers[provider.name] = provider
        self.health.setdefault(provider.name, Health())
        self.stats.setdefault(provider.name, {"calls": 0, "failures": 0,
                                              "tokens": 0, "latency_ms": 0})

    def capabilities(self) -> list[ModelCapability]:
        caps: list[ModelCapability] = []
        for name, p in self.providers.items():
            # Resolve per provider: a role pin is provider-scoped, so using one
            # name for every provider mislabels every capability table.
            caps.append(p.capabilities(self.model_for(name)))
        return caps

    # ------------------------------------------------------------------ #
    def role_for(self, task: str, request: str = "") -> str:
        """Pick a role (reasoning/coding/fast/vision) from the task shape."""
        intent = classify_intent(request) if request else None
        if intent is None:
            return "fast"
        if intent.kind in ("code", "debug"):
            return "coding"
        if intent.kind in ("research", "explain", "security") and intent.complexity >= 4:
            return "reasoning"
        if "image" in request.lower() or intent.kind == "create":
            return "vision"
        return "fast"

    def model_for(self, provider_name: str, role: str = "fast") -> str:
        """Which model to ask this provider for.

        Role pins are provider-scoped and may be written as "provider:model".
        A bare "model" only applies to local providers, so a leftover
        `SPIDY_MODEL_FAST=gemma3:4b` can't be sent to OpenAI or Anthropic —
        that 404s on every call and then silently degrades the whole run.

        Order: matching role pin, then provider pin, then catalog default.
        """
        roles = self.settings.model_roles or {}
        local = provider_name in ("ollama", "llamacpp")
        from .catalog import PROVIDERS
        for key in (role, "fast"):
            val = roles.get(key)
            if not val:
                continue
            # "provider:model" scopes the pin. Ollama tags look the same
            # ("gemma3:4b"), so a prefix only counts when it names a provider
            # in the *catalog* — not merely one that happens to be registered,
            # or a pin for a keyed-but-absent provider would read as a tag.
            head, sep, tail = val.partition(":")
            if sep and head.strip().lower() in PROVIDERS:
                # A pin aimed at one provider must not be served to another,
                # local runtimes included: "groq:llama-3.3" is not an Ollama tag.
                if head.strip().lower() == provider_name.lower():
                    return tail.strip()
                continue
            if local:
                return val.strip()
        from .catalog import default_model_for
        return default_model_for(self.settings, provider_name)

    # ------------------------------------------------------------------ #
    async def complete(
        self,
        messages: list[LLMMessage],
        role: str = "fast",
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.2,
        max_tokens: int = 2048,
        json_mode: bool = False,
        prefer_local: bool | None = None,
    ) -> LLMResponse:
        """Try providers in policy order until one answers."""
        if prefer_local is None:
            prefer_local = self.settings.offline_only or not self.settings.has_cloud_keys()

        order = self._order(tools, prefer_local)
        errors: list[str] = []

        for provider_name in order:
            p = self.providers.get(provider_name)
            if p is None:
                continue
            h = self.health.setdefault(provider_name, Health())
            if h.degraded and provider_name != "native":
                continue
            if not getattr(p, "available", True):
                continue

            model = "native" if provider_name == "native" else self.model_for(provider_name, role)
            try:
                resp = await p.chat(messages, model, tools=tools, temperature=temperature,
                                    max_tokens=max_tokens, json_mode=json_mode)
            except Exception as exc:  # noqa: BLE001
                h.record_fail(str(exc))
                errors.append(f"{provider_name}: {exc}")
                continue

            s = self.stats.setdefault(provider_name, {"calls": 0, "failures": 0,
                                                      "tokens": 0, "latency_ms": 0})
            s["calls"] += 1
            s["latency_ms"] += resp.latency_ms
            if resp.error:
                h.record_fail(resp.error)
                s["failures"] += 1
                errors.append(resp.error)
                continue
            h.record_ok(resp.latency_ms)
            s["tokens"] += resp.total_tokens
            return resp

        # Everything failed. Native is in `order`, so this means native itself
        # errored — return a structured failure rather than raising.
        return LLMResponse(
            error="; ".join(errors[-3:]) or "no provider available",
            provider="none", model="none", finish_reason="error")

    def _order(self, tools: list[dict[str, Any]] | None,
               prefer_local: bool) -> list[str]:
        need_tools = bool(tools)
        scored: list[tuple[int, str]] = []
        for name, p in self.providers.items():
            if name == "native":
                continue
            if not getattr(p, "available", True):
                continue
            if self.health.get(name, Health()).degraded:
                continue
            cap = p.capabilities(self.model_for(name))
            score = cap.priority
            if prefer_local and cap.local:
                score -= 100
            if not prefer_local and not cap.local:
                score -= 20
            if need_tools and not cap.supports_tools:
                score += 50
            scored.append((score, name))
        scored.sort()
        return [n for _, n in scored] + ["native"]

    # ------------------------------------------------------------------ #
    async def discover_models(self) -> dict[str, list[str]]:
        ollama = self.providers.get("ollama")
        out: dict[str, list[str]] = {}
        if isinstance(ollama, object) and hasattr(ollama, "list_models"):
            out["ollama"] = await ollama.list_models()  # type: ignore[attr-defined]
        return out

    def reconfigure(self) -> list[str]:
        """Rebuild providers from the current settings.

        Called after a key or model pin changes at runtime. It adds and drops
        providers but keeps the health counters for ones that survive, so a
        user pasting a key doesn't reset the health of everything else.
        """
        from .providers import build_providers

        fresh = {p.name: p for p in build_providers(self.settings)}
        added: list[str] = []
        for name, provider in fresh.items():
            if name not in self.providers:
                self.providers[name] = provider
                self.health[name] = Health()
                self.stats[name] = {"calls": 0, "failures": 0, "tokens": 0,
                                    "latency_ms": 0}
                self._probe_cache.pop(name, None)
                added.append(name)
        for name in list(self.providers):
            if name not in fresh:
                del self.providers[name]
                self.health.pop(name, None)
                self.stats.pop(name, None)
                self._probe_cache.pop(name, None)
        return added

    def health_report(self) -> dict[str, Any]:
        return {
            name: {
                **self.stats.get(name, {}),
                "consecutive_failures": self.health.get(name, Health()).consecutive_failures,
                "last_error": self.health.get(name, Health()).last_error,
                "degraded": self.health.get(name, Health()).degraded,
            }
            for name in self.providers
        }

    async def probe(self) -> dict[str, dict[str, Any]]:
        out: dict[str, dict[str, Any]] = {}

        # A key may have been set on the settings object without a
        # reconfigure() yet. Probe those too, so the UI reports the truth
        # ("auth rejected") instead of silently omitting the provider.
        from .catalog import PROVIDERS
        for name, spec in PROVIDERS.items():
            provider = self.providers.get(name)
            if provider is None:
                key = getattr(self.settings, spec.key_field, "")
                if not key or self.settings.offline_only or \
                        not getattr(self.settings, "allow_cloud", True):
                    continue
                # Build it just for the probe so health reflects a key that was
                # added but not yet wired into the router.
                from .cloud import AnthropicProvider, GoogleProvider
                from .providers import OpenAICompatibleProvider
                base = getattr(self.settings, f"{name}_base_url", "") or spec.base_url
                if spec.kind == "anthropic":
                    provider = AnthropicProvider(self.settings, key, base, spec.priority)
                elif spec.kind == "google":
                    provider = GoogleProvider(self.settings, key, base, spec.priority)
                else:
                    provider = OpenAICompatibleProvider(
                        self.settings, name, base, key, spec.priority)

            h = self.health.get(name, Health())
            entry: dict[str, Any] = {
                "configured_available": bool(getattr(provider, "available", False)),
                "degraded": h.degraded,
                "last_error": h.last_error,
                "reachable": False,
                "models": [],
            }

            cached = self._probe_cache.get(name)
            if cached and (time.time() - cached[0]) < 30.0:
                entry["reachable"], entry["models"] = cached[1], cached[2]
                # The reason is cached too, or a bad key would look like an
                # unexplained failure on every page refresh.
                if len(cached) > 3 and cached[3]:
                    entry["error"] = cached[3]
            else:
                try:
                    result = await asyncio.wait_for(provider.probe(), timeout=10.0)
                except Exception as exc:  # noqa: BLE001
                    result = (False, [], f"{type(exc).__name__}: {exc}"[:120])
                # Providers return (usable, models, error); older ones return
                # a 2-tuple. Normalise so one bad provider can't break health.
                usable, models = result[0], (result[1] or [])
                err = result[2] if len(result) > 2 else ""
                entry["reachable"] = bool(usable)
                entry["models"] = [m for m in models if m]
                if err:
                    entry["error"] = err
                self._probe_cache[name] = (
                    time.time(), entry["reachable"], entry["models"],
                    entry.get("error", ""))
            out[name] = entry
        return out

    def describe(self) -> dict[str, Any]:
        return {
            "providers": [
                {
                    "name": n,
                    "available": bool(getattr(p, "available", False)),
                    "local": p.capabilities(self.model_for(n)).local,
                    "supports_tools": p.capabilities(self.model_for(n)).supports_tools,
                }
                for n, p in self.providers.items()
            ],
            "roles": self.settings.model_roles,
            "order": self._order(None, self.settings.offline_only or
                                 not self.settings.has_cloud_keys()),
            "offline_only": self.settings.offline_only,
        }
