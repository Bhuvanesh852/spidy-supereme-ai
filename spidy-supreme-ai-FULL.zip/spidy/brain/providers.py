"""LLM provider clients.

Every provider returns the same `LLMResponse`, so the runtime never knows which
one answered. Providers degrade to `error` rather than raising, and the router
falls through to the next candidate — or to the native brain.
"""
from __future__ import annotations

import json
import re
import asyncio
import time
from typing import Any

import httpx

from ..core.schemas import LLMMessage, LLMResponse, ModelCapability, ToolResult


class BaseProvider:
    name = "base"

    def __init__(self, settings) -> None:
        self.settings = settings

    @property
    def available(self) -> bool:
        """Subclasses override. Base is available so ordering never crashes."""
        return True

    async def probe(self) -> tuple[bool, list[str]]:
        """Return (reachable, installed_model_names).

        `available` means "not blocked by config" — a local Ollama with no
        server still reports True. The UI needs to know whether a model can
        actually be reached, so this actively pings the endpoint. Reachable and
        has-models are different facts: a server that's up but has pulled
        nothing is reachable but not usable, and only the second earns the
        "no offline badge" state.
        """
        return bool(getattr(self, "available", True)), []

    def capabilities(self, model: str) -> ModelCapability:
        return ModelCapability(name=model, provider=self.name)

    async def chat(
        self,
        messages: list[LLMMessage],
        model: str,
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.2,
        max_tokens: int = 2048,
        json_mode: bool = False,
    ) -> LLMResponse:
        raise NotImplementedError

    # ------------------------------------------------------------------ #
    @staticmethod
    def _extract_tool_calls(text: str) -> list[dict[str, Any]]:
        """Recover tool calls from models that emit them as text.

        Local models frequently do this even with tool schemas attached, so the
        parser is deliberately forgiving: fenced JSON, bare JSON, or a
        `TOOL_CALL:` line.
        """
        calls: list[dict[str, Any]] = []
        candidates: list[str] = []
        for m in re.finditer(r"```(?:json)?\s*(.+?)```", text, re.S):
            candidates.append(m.group(1))
        candidates.append(text)
        for blob in candidates:
            for m in re.finditer(r"\{.*?\}(?=\s*[\[{]|\s*$|\n)", blob, re.S):
                pass
            try:
                parsed = json.loads(blob.strip())
            except (json.JSONDecodeError, ValueError):
                parsed = _find_json_objects(blob)
            for obj in parsed if isinstance(parsed, list) else [parsed]:
                if not isinstance(obj, dict):
                    continue
                name = obj.get("name") or obj.get("tool") or obj.get("function")
                if not name:
                    continue
                args = (obj.get("arguments") or obj.get("args")
                        or obj.get("parameters") or obj.get("input") or {})
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except (json.JSONDecodeError, ValueError):
                        args = {"_raw": args}
                calls.append({"name": str(name), "arguments": args if isinstance(args, dict) else {}})
            if calls:
                break
        # de-duplicate on (name, args)
        seen: set[str] = set()
        out: list[dict[str, Any]] = []
        for c in calls:
            k = c["name"] + json.dumps(c["arguments"], sort_keys=True, default=str)
            if k not in seen:
                seen.add(k)
                out.append(c)
        return out[:12]

    @staticmethod
    def _strip_tool_json(text: str) -> str:
        return re.sub(r"```(?:json)?\s*\{.*?\}\s*```", "", text, flags=re.S).strip()


def _find_json_objects(blob: str) -> list[dict[str, Any]]:
    """Scan for balanced JSON objects even when surrounded by prose."""
    out: list[dict[str, Any]] = []
    depth = 0
    start = -1
    in_str = False
    esc = False
    for i, ch in enumerate(blob):
        if esc:
            esc = False
            continue
        if ch == "\\":
            esc = True
            continue
        if ch == '"':
            in_str = not in_str
            continue
        if in_str:
            continue
        if ch == "{":
            if depth == 0:
                start = i
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0 and start >= 0:
                try:
                    obj = json.loads(blob[start:i + 1])
                    if isinstance(obj, dict):
                        out.append(obj)
                except (json.JSONDecodeError, ValueError):
                    pass
                start = -1
    return out


# --------------------------------------------------------------------------- #


class OllamaProvider(BaseProvider):
    name = "ollama"

    @property
    def available(self) -> bool:
        if self.settings.offline_only:
            return True   # local, always "available"; failures degrade gracefully
        return True

    def capabilities(self, model: str) -> ModelCapability:
        return ModelCapability(
            name=model, provider=self.name, supports_tools=True,
            supports_json_schema=True, supports_vision=True, supports_reasoning=True,
            context_window=32768, priority=1, local=True,
        )

    async def list_models(self) -> list[str]:
        try:
            async with httpx.AsyncClient(timeout=5) as c:
                r = await c.get(f"{self.settings.ollama_endpoint.rstrip('/')}/api/tags")
                r.raise_for_status()
                return [m.get("name", "") for m in r.json().get("models", [])]
        except Exception:
            return []

    async def probe(self) -> tuple[bool, list[str], str]:
        import httpx
        try:
            async with httpx.AsyncClient(timeout=3) as c:
                r = await c.get(f"{self.settings.ollama_endpoint.rstrip('/')}/api/tags")
        except Exception as exc:  # noqa: BLE001
            return False, [], f"not running ({_short(exc, 40)})"
        if r.status_code >= 400:
            return False, [], f"HTTP {r.status_code}"
        try:
            data = r.json()
        except ValueError:
            return True, [], ""
        models = [m.get("name", "") for m in data.get("models", [])]
        if not models:
            return True, [], "running, but no models pulled"
        return True, models, ""

    async def chat(self, messages, model, tools=None, temperature=0.2,
                   max_tokens=2048, json_mode=False) -> LLMResponse:
        start = time.perf_counter()
        payload: dict[str, Any] = {
            "model": model,
            "messages": [m.to_dict() for m in messages],
            "stream": False,
            "options": {"temperature": temperature, "num_predict": max_tokens},
        }
        if tools:
            payload["tools"] = [
                {"type": "function", "function": {
                    "name": t["name"], "description": t["description"],
                    "parameters": t.get("input_schema", {}),
                }} for t in tools
            ]
        if json_mode:
            payload["format"] = "json"
        try:
            async with httpx.AsyncClient(timeout=self.settings.request_timeout) as c:
                r = await c.post(
                    f"{self.settings.ollama_endpoint.rstrip('/')}/api/chat", json=payload)
                r.raise_for_status()
                data = r.json()
        except Exception as exc:  # noqa: BLE001
            return LLMResponse(error=f"ollama: {_short(exc)}", provider=self.name, model=model)

        msg = data.get("message", {}) or {}
        text = msg.get("content", "") or ""
        calls: list[dict[str, Any]] = []
        for tc in msg.get("tool_calls", []) or []:
            fn = tc.get("function", {}) or {}
            args = fn.get("arguments", {}) or {}
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except (json.JSONDecodeError, ValueError):
                    args = {}
            calls.append({"name": fn.get("name", ""), "arguments": args})
        if not calls and text:
            calls = self._extract_tool_calls(text)
            if calls:
                text = self._strip_tool_json(text)
        return LLMResponse(
            text=text, tool_calls=calls, provider=self.name, model=model,
            prompt_tokens=data.get("prompt_eval_count", 0),
            completion_tokens=data.get("eval_count", 0),
            latency_ms=int((time.perf_counter() - start) * 1000),
            finish_reason=data.get("done_reason", "stop"),
        )


class LlamaCppProvider(BaseProvider):
    name = "llamacpp"

    async def probe(self) -> tuple[bool, list[str], str]:
        import httpx
        try:
            async with httpx.AsyncClient(timeout=3) as c:
                r = await c.get(f"{self.settings.llamacpp_base_url.rstrip('/')}/v1/models")
        except Exception as exc:  # noqa: BLE001
            return False, [], f"not running ({_short(exc, 40)})"
        if r.status_code >= 400:
            return False, [], f"HTTP {r.status_code}"
        try:
            data = r.json()
        except ValueError:
            return True, [], ""
        return True, [m.get("id", "") for m in data.get("data", []) if m.get("id")], ""

    def capabilities(self, model: str) -> ModelCapability:
        return ModelCapability(
            name=model, provider=self.name, supports_tools=True,
            supports_json_schema=True, supports_vision=False, context_window=16384,
            priority=2, local=True,
        )

    async def chat(self, messages, model, tools=None, temperature=0.2,
                   max_tokens=2048, json_mode=False) -> LLMResponse:
        start = time.perf_counter()
        payload: dict[str, Any] = {
            "messages": [m.to_dict() for m in messages],
            "temperature": temperature, "max_tokens": max_tokens, "stream": False,
        }
        if tools:
            payload["tools"] = tools
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
        try:
            async with httpx.AsyncClient(timeout=self.settings.request_timeout) as c:
                r = await c.post(
                    f"{self.settings.llamacpp_base_url.rstrip('/')}/v1/chat/completions",
                    json=payload)
                r.raise_for_status()
                data = r.json()
        except Exception as exc:  # noqa: BLE001
            return LLMResponse(error=f"llamacpp: {_short(exc)}", provider=self.name, model=model)

        choices = data.get("choices") or [{}]
        msg = choices[0].get("message", {}) or {}
        text = msg.get("content", "") or ""
        calls = []
        for tc in msg.get("tool_calls", []) or []:
            fn = tc.get("function", {}) or {}
            args = fn.get("arguments", {}) or {}
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except (json.JSONDecodeError, ValueError):
                    args = {}
            calls.append({"name": fn.get("name", ""), "arguments": args})
        if not calls and text:
            calls = self._extract_tool_calls(text)
            if calls:
                text = self._strip_tool_json(text)
        usage = data.get("usage", {}) or {}
        return LLMResponse(
            text=text, tool_calls=calls, provider=self.name, model=model,
            prompt_tokens=usage.get("prompt_tokens", 0),
            completion_tokens=usage.get("completion_tokens", 0),
            latency_ms=int((time.perf_counter() - start) * 1000),
        )


class OpenAICompatibleProvider(BaseProvider):
    """Any OpenAI-shaped endpoint: OpenAI, OpenRouter, Groq, Together, …

    The wire format is shared, so one class covers nine providers. What differs
    per provider — base URL, auth, default model, capability table — comes from
    the catalog, so adding one is a data change, not a class.
    """

    name = "openai"

    def __init__(self, settings, name: str = "openai", base_url: str = "",
                 api_key: str = "", priority: int = 8) -> None:
        super().__init__(settings)
        self.name = name
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self._priority = priority

    @property
    def available(self) -> bool:
        return bool(self.api_key) and not self.settings.offline_only \
            and getattr(self.settings, "allow_cloud", True)

    def capabilities(self, model: str) -> ModelCapability:
        from .catalog import model_capabilities
        caps = model_capabilities(self.name, model)
        return ModelCapability(
            name=model, provider=self.name, supports_tools=caps.get("tools", True),
            supports_json_schema=True, supports_vision=caps.get("vision", False),
            context_window=caps.get("context", 128_000),
            priority=self._priority, local=False,
            cost_per_1k=caps.get("cost_per_1k", 0.0),
        )

    def _headers(self) -> dict[str, str]:
        headers = {"Authorization": f"Bearer {self.api_key}",
                   "Content-Type": "application/json"}
        # OpenRouter attributes requests to an app; it also rejects requests
        # with no Referer when rate limited, so send both.
        if self.name == "openrouter":
            headers["HTTP-Referer"] = "https://github.com/spidy-ai"
            headers["X-Title"] = "SPIDY Supreme AI"
        return headers

    async def probe(self) -> tuple[bool, list[str], str]:
        """Distinguish "no key", "bad key", and "no listing".

        Returns (usable, models, error). This distinction matters: an
        OpenAI-shaped endpoint answers 401 for a bad key, which is not an
        exception, so a naive probe reports it as reachable and the UI shows a
        catalog of models that cannot actually be called. A green light that
        lies is worse than a red one.
        """
        if not self.api_key:
            return False, [], "no API key"
        try:
            async with httpx.AsyncClient(timeout=8) as c:
                r = await c.get(f"{self.base_url}/models", headers=self._headers())
        except Exception as exc:  # noqa: BLE001
            return False, [], f"unreachable: {_short(exc, 80)}"

        if r.status_code in (401, 403):
            return False, [], f"auth rejected ({r.status_code}) — check the key"
        if r.status_code == 404:
            # Gateway is up but doesn't publish a catalog. Usable, just unknown.
            return True, [], ""
        if r.status_code >= 400:
            return False, [], f"HTTP {r.status_code}"

        try:
            data = r.json()
        except ValueError:
            return True, [], ""
        items = data.get("data", data.get("models", []))
        return True, [m.get("id") or m.get("name") or ""
                      for m in items if isinstance(m, dict)], ""

    async def list_models(self) -> list[str]:
        usable, models, _ = await self.probe()
        return models if usable else []

    async def chat(self, messages, model, tools=None, temperature=0.2,
                   max_tokens=2048, json_mode=False) -> LLMResponse:
        start = time.perf_counter()
        headers = self._headers()
        payload: dict[str, Any] = {
            "model": model, "messages": [m.to_dict() for m in messages],
            "temperature": temperature, "max_tokens": max_tokens, "stream": False,
        }
        if tools:
            payload["tools"] = [{"type": "function", "function": {
                "name": t["name"], "description": t["description"],
                "parameters": t.get("input_schema", {}),
            }} for t in tools]
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
        try:
            async with httpx.AsyncClient(timeout=self.settings.request_timeout) as c:
                r = await c.post(f"{self.base_url}/chat/completions", json=payload, headers=headers)
                r.raise_for_status()
                data = r.json()
        except Exception as exc:  # noqa: BLE001
            return LLMResponse(error=f"{self.name}: {_short(exc)}", provider=self.name, model=model)

        choices = data.get("choices") or [{}]
        msg = choices[0].get("message", {}) or {}
        text = msg.get("content", "") or ""
        calls = []
        for tc in msg.get("tool_calls", []) or []:
            fn = tc.get("function", {}) or {}
            args = fn.get("arguments", {}) or {}
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except (json.JSONDecodeError, ValueError):
                    args = {}
            calls.append({"name": fn.get("name", ""), "arguments": args})
        usage = data.get("usage", {}) or {}
        return LLMResponse(
            text=text, tool_calls=calls, provider=self.name, model=model,
            prompt_tokens=usage.get("prompt_tokens", 0),
            completion_tokens=usage.get("completion_tokens", 0),
            latency_ms=int((time.perf_counter() - start) * 1000),
        )


def build_providers(settings) -> list[BaseProvider]:
    """Assemble the provider set from settings. Native is never absent.

    Driven by the catalog: a provider is registered when it has a key (or is
    local), and the class is chosen by its `kind`. Adding a cloud provider is a
    catalog entry, not a new branch here.
    """
    from .catalog import PROVIDERS
    from .cloud import AnthropicProvider, GoogleProvider
    from .native import NativeProvider

    out: list[BaseProvider] = [
        OllamaProvider(settings),
        LlamaCppProvider(settings),
    ]

    cloud_ok = not settings.offline_only and getattr(settings, "allow_cloud", True)
    if cloud_ok:
        # Local first so the offline floor stays ahead of anything remote.
        for spec in sorted(PROVIDERS.values(), key=lambda p: (p.priority, p.slug)):
            if spec.kind == "local":
                continue
            key = getattr(settings, spec.key_field, "")
            if not key:
                continue
            # A user-supplied `<slug>_base_url` wins over the catalog default,
            # so any OpenAI-shaped gateway slots in without code.
            override = getattr(settings, f"{spec.slug}_base_url", "")
            base = override or spec.base_url
            if spec.kind == "anthropic":
                out.append(AnthropicProvider(settings, key, base, spec.priority))
            elif spec.kind == "google":
                out.append(GoogleProvider(settings, key, base, spec.priority))
            else:
                out.append(OpenAICompatibleProvider(
                    settings, spec.slug, base, key, spec.priority))

    out.append(NativeProvider(settings))
    return out


def _short(exc: Exception, n: int = 200) -> str:
    s = f"{type(exc).__name__}: {exc}"
    return s[:n]
