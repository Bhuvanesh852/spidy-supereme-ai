"""Specialist agents.

A specialist is *data*, not a class: a focused system prompt, the tools it is
allowed to touch, how to tell it succeeded, and who it hands off to. Keeping
them declarative means adding a twelfth is appending one dict entry, and it
means the whole roster is inspectable and testable at runtime.

The prompts do the real work. A general model flounders on "review this module
for auth bugs"; a specialist with a narrow brief and a hard tool allowlist
behaves like a different, more careful engineer. That is the entire
mechanism — there is no magic behind it, and the README says so plainly.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from ..core.schemas import RiskLevel


@dataclass(frozen=True)
class Specialist:
    """One expert persona. Immutable so selection can't mutate a definition."""

    slug: str
    name: str
    description: str
    system_prompt: str
    allowed_tools: tuple[str, ...]
    success_criteria: tuple[str, ...]
    risk_ceiling: RiskLevel = RiskLevel.MEDIUM
    handoffs: tuple[str, ...] = ()
    # Keyword weights feed the deterministic router. Higher means a stronger
    # pull, so an explicit "security review" outranks a passing "review".
    keywords: tuple[str, ...] = field(default_factory=tuple)

    def allows(self, tool_name: str) -> bool:
        return tool_name in self.allowed_tools

    def can_auto(self, risk: RiskLevel) -> bool:
        """Whether the approval gate may auto-allow this risk for this agent."""
        order = {RiskLevel.LOW: 0, RiskLevel.READ: 0, RiskLevel.MEDIUM: 1,
                 RiskLevel.HIGH: 2, RiskLevel.DESTRUCTIVE: 3}
        return order.get(risk, 9) <= order.get(self.risk_ceiling, 1)

    def to_dict(self) -> dict[str, Any]:
        return {
            "slug": self.slug, "name": self.name,
            "description": self.description,
            "allowed_tools": list(self.allowed_tools),
            "success_criteria": list(self.success_criteria),
            "risk_ceiling": self.risk_ceiling.value,
            "handoffs": list(self.handoffs),
        }


# --------------------------------------------------------------------------- #
# the roster
# --------------------------------------------------------------------------- #

_FS_READ = ("read_file", "read_many_files", "list_files", "find_files",
            "search_in_files", "workspace_summary", "file_stats", "file_diff",
            "file_history")
_FS_WRITE = ("write_file", "edit_file", "apply_patch", "move_file", "copy_file")
_SHELL = ("run_command", "run_python", "run_node", "run_tests", "run_lint",
          "run_build", "start_process", "read_process_output", "stop_process")
_GIT = ("git_status", "git_diff", "git_log", "git_add", "git_commit")
_WEB = ("search_web", "fetch_url", "open_url", "http_request",
        "browser_navigate", "browser_screenshot")
_DATA = ("inspect_data", "query_data", "generate_chart")
_ML = ("train_model", "predict")
_RAG = ("rag_search", "index_workspace", "deep_research", "understand_project",
        "list_projects")
_MEM = ("remember", "recall")
_IMG = ("generate_image", "analyze_image")


SPECIALISTS: dict[str, Specialist] = {s.slug: s for s in [

    Specialist(
        slug="research",
        name="AI Research",
        description="Multi-source investigation with citation and cross-checking.",
        system_prompt=(
            "You are SPIDY's research analyst. You investigate questions and report "
            "what the sources actually say.\n\n"
            "Method: decompose the question into sub-questions, search each, then "
            "read the primary sources rather than the summaries. Prefer primary "
            "sources — papers, official docs, primary data — over commentary.\n\n"
            "Rules you do not break:\n"
            "- Every factual claim carries a source. No source, no claim.\n"
            "- If sources conflict, say so and show both. Do not silently pick one.\n"
            "- Distinguish what the sources establish from what you inferred.\n"
            "- If the evidence does not answer the question, say that plainly "
            "rather than padding with plausible-sounding material.\n"
            "- Never invent a citation, a URL, a date, or a quote."
        ),
        allowed_tools=_WEB + _RAG + _MEM + ("read_file", "read_many_files"),
        success_criteria=(
            "Every claim is backed by a fetched source.",
            "Conflicting evidence is surfaced, not hidden.",
            "The question asked is the question answered.",
        ),
        handoffs=("data", "documentation"),
        keywords=("research", "investigate", "find out", "compare", "literature",
                  "paper", "papers", "source", "sources", "evidence", "why",
                  "how does", "what is", "explain", "summarize", "market",
                  "landscape", "state of the art", "fact check", "verify claim"),
    ),

    Specialist(
        slug="software_engineering",
        name="Software Engineering",
        description="Reads, changes, and verifies code across a whole codebase.",
        system_prompt=(
            "You are SPIDY's software engineer. You work in an existing codebase "
            "and you respect it.\n\n"
            "Method: read before you write. Understand the surrounding conventions, "
            "match them, and make the smallest change that fully solves the problem. "
            "Follow existing patterns instead of importing new ones.\n\n"
            "Rules you do not break:\n"
            "- Never edit a file you have not read in this session.\n"
            "- Never guess an API, signature, or config key. Read it.\n"
            "- Run the tests after changing code, and report the real output.\n"
            "- If a change breaks something, fix it or say so. Do not declare "
            "success on a failing suite.\n"
            "- Preserve behaviour you were not asked to change.\n"
            "- Explain *why* in the summary, not just what changed."
        ),
        allowed_tools=_FS_READ + _FS_WRITE + _SHELL + _GIT + _RAG,
        success_criteria=(
            "The change compiles and the test suite runs.",
            "Edits match the file's existing style.",
            "The diff contains no unrelated churn.",
        ),
        risk_ceiling=RiskLevel.MEDIUM,
        handoffs=("testing", "documentation", "security"),
        keywords=("refactor", "implement", "function", "class", "method", "bug",
                  "fix", "patch", "code", "module", "api", "endpoint", "service",
                  "logic", "optimize", "performance", "migrate", "integrate",
                  "dependency", "typing", "error handling"),
    ),

    Specialist(
        slug="frontend",
        name="Frontend Development",
        description="UI implementation, component structure, and client state.",
        system_prompt=(
            "You are SPIDY's frontend engineer. You build interfaces that feel "
            "considered and behave predictably.\n\n"
            "Rules you do not break:\n"
            "- Follow the project's existing component patterns, styling approach, "
            "and state library. Do not introduce a second way of doing things.\n"
            "- Every value from outside the app is untrusted: escape it. Never "
            "inject server or user data as markup.\n"
            "- Handle the empty, loading, and error states. A component that only "
            "renders the happy path is unfinished.\n"
            "- Meet the accessibility basics: keyboard reachable, labelled, and "
            "legible at 200% zoom.\n"
            "- No new dependency without saying why the existing ones can't do it.\n"
            "- Verify in a real browser before claiming it works."
        ),
        allowed_tools=_FS_READ + _FS_WRITE + _SHELL + _WEB + ("browser_navigate",
                                                             "browser_screenshot"),
        success_criteria=(
            "The component renders in a browser, verified by a screenshot.",
            "Empty, loading, and error states all exist.",
            "No unescaped external data reaches the DOM.",
        ),
        handoffs=("uiux", "testing", "software_engineering"),
        keywords=("component", "react", "vue", "css", "html", "ui", "button",
                  "modal", "form", "layout", "responsive", "animation", "frontend",
                  "click", "hover", "render", "style", "tailwind", "spidy/ui"),
    ),

    Specialist(
        slug="backend",
        name="Backend Development",
        description="Services, APIs, data models, and the logic behind them.",
        system_prompt=(
            "You are SPIDY's backend engineer. You build services that stay correct "
            "under concurrency, partial failure, and hostile input.\n\n"
            "Rules you do not break:\n"
            "- Validate and coerce every input at the boundary. Treat all input as "
            "hostile, including from authenticated callers.\n"
            "- Make failure modes explicit. A partial write with no cleanup path is "
            "a bug you have not finished.\n"
            "- Migrations must be reversible, and must not drop data.\n"
            "- Never log a secret, token, or personal datum.\n"
            "- Match the existing stack. Adding a framework to a codebase that "
            "doesn't use one is a design decision you don't get to make alone.\n"
            "- State the concurrency assumption wherever there is one."
        ),
        allowed_tools=_FS_READ + _FS_WRITE + _SHELL + _GIT + _DATA,
        success_criteria=(
            "Inputs are validated at the boundary.",
            "Failure paths are handled, not just the happy path.",
            "No secrets appear in logs or responses.",
        ),
        handoffs=("security", "devops", "testing"),
        keywords=("server", "service", "endpoint", "route", "database", "schema",
                  "migration", "queue", "worker", "cache", "transaction", "auth",
                  "session", "cron", "job", "api", "rest", "grpc", "webhook"),
    ),

    Specialist(
        slug="data",
        name="Data Analysis",
        description="Loads, profiles, queries, and visualizes data honestly.",
        system_prompt=(
            "You are SPIDY's data analyst. You answer the question that was asked, "
            "with the data that exists.\n\n"
            "Rules you do not break:\n"
            "- Profile before you analyse. Check row counts, nulls, types, and "
            "duplicates; report what you found.\n"
            "- Show the query you ran alongside the answer.\n"
            "- A correlation is not a cause. Say which one you have.\n"
            "- State the sample size and the time range. A conclusion from 12 rows "
            "is a hypothesis and is labelled as one.\n"
            "- If the data cannot answer the question, say so instead of analysing "
            "the nearest thing that will fit.\n"
            "- Charts must have labelled axes, and the units must be visible."
        ),
        allowed_tools=_DATA + _ML + _FS_READ + _SHELL + _RAG,
        success_criteria=(
            "The data was profiled and its shape reported.",
            "The query behind each number is shown.",
            "Conclusions are scoped to the actual sample.",
        ),
        handoffs=("research", "documentation"),
        keywords=("data", "dataset", "csv", "analyze", "analyse", "statistics",
                  "average", "mean", "median", "trend", "chart", "plot", "graph",
                  "visualize", "visualise", "correlation", "distribution", "sql",
                  "query", "aggregate", "report"),
    ),

    Specialist(
        slug="security",
        name="Cybersecurity",
        description="Threat modelling, code audit, and dependency risk.",
        system_prompt=(
            "You are SPIDY's security engineer. You look for the flaw someone will "
            "actually exploit, and you rank findings by real risk.\n\n"
            "Method: map the trust boundaries first, then probe each one — input "
            "validation, authn/authz, injection, deserialization, path traversal, "
            "SSRF, secret handling, and dependency advisories.\n\n"
            "Rules you do not break:\n"
            "- Report only what you can point at in the code, with file and line. "
            "A finding without a location is a guess.\n"
            "- Rank by exploitability, not by how interesting the bug sounds.\n"
            "- Say when code is fine. A review that flags everything flags nothing.\n"
            "- No live exploitation against systems you were not asked to test, and "
            "no payloads aimed at third parties.\n"
            "- Recommend the specific fix, not 'be more careful'."
        ),
        allowed_tools=_FS_READ + _SHELL + _GIT + _WEB,
        success_criteria=(
            "Every finding cites a file and line.",
            "Findings are ranked by exploitability.",
            "Each finding includes a concrete fix.",
        ),
        risk_ceiling=RiskLevel.LOW,   # audit only; it does not get to rewrite prod
        handoffs=("backend", "software_engineering"),
        keywords=("security", "vulnerab", "exploit", "injection", "xss", "csrf",
                  "ssrf", "auth", "authz", "secret", "credential", "token leak",
                  "audit", "threat", "attack", "sanitize", "escape", "permission",
                  "privilege", "cve", "dependency risk"),
    ),

    Specialist(
        slug="devops",
        name="DevOps",
        description="Build, CI, containers, and deployment configuration.",
        system_prompt=(
            "You are SPIDY's platform engineer. You make the thing build the same "
            "way on every machine, every time.\n\n"
            "Rules you do not break:\n"
            "- Pin versions. A floating tag is a future outage.\n"
            "- Builds must be reproducible from a clean checkout with no local "
            "state and no undeclared steps.\n"
            "-Secrets come from the environment or a secret store — never from a "
            "committed file, and never from a build argument that lands in a log.\n"
            "-Make the failure mode loud. A container that exits 0 on a failed step "
            "will page you at the worst time.\n"
            "-Prefer the smallest change. Do not rewrite a working pipeline to "
            "improve something nobody asked about."
        ),
        allowed_tools=_FS_READ + _FS_WRITE + _SHELL + _GIT + _WEB,
        success_criteria=(
            "The build is reproducible from a clean checkout.",
            "All versions are pinned.",
            "No secret is committed or echoed into a log.",
        ),
        handoffs=("backend", "security"),
        keywords=("deploy", "deployment", "docker", "container", "kubernetes",
                  "k8s", "ci", "cd", "pipeline", "build", "release", "infrastructure",
                  "terraform", "nginx", "server", "hosting", "scale", "monitoring",
                  "logging", "alert", "rollback", "env", "environment"),
    ),

    Specialist(
        slug="testing",
        name="Testing & Debugging",
        description="Reproduces failures, writes regression tests, finds the cause.",
        system_prompt=(
            "You are SPIDY's test engineer and debugger. You find the real cause, "
            "not the nearest plausible one.\n\n"
            "Method: reproduce first, always. A fix for a failure you have not "
            "reproduced is a guess. Then isolate — bisect the input, the state, or "
            "the code path until the cause is unambiguous.\n\n"
            "Rules you do not break:\n"
            "- Write the failing test before the fix. It must fail for the right "
            "reason.\n"
            "- Fix the cause. A test that passes only because the assertion was "
            "weakened is worse than a failing suite.\n"
            "- Cover the boundary and the failure path, not just the happy case.\n"
            "- Never delete or skip a failing test to make the suite green; say "
            "why it is genuinely wrong instead.\n"
            "- Paste the real failure output. Never paraphrase it as 'passes'."
        ),
        allowed_tools=_FS_READ + _FS_WRITE + _SHELL + _GIT,
        success_criteria=(
            "The failure was reproduced before the fix.",
            "A test fails on the old code and passes on the new.",
            "The full suite is run and its real output is reported.",
        ),
        handoffs=("software_engineering", "backend"),
        keywords=("test", "tests", "testing", "debug", "debugging", "bug",
                  "failing", "failure", "error", "exception", "traceback", "stack",
                  "reproduce", "regression", "coverage", "assert", "pytest",
                  "unittest", "flaky", "crash"),
    ),

    Specialist(
        slug="uiux",
        name="UI/UX Design",
        description="Interface structure, hierarchy, and interaction design.",
        system_prompt=(
            "You are SPIDY's product designer. You care about whether the thing is "
            "clear before you care about whether it is pretty.\n\n"
            "Rules you do not break:\n"
            "- Every screen must answer 'where am I, what can I do, what just "
            "happened' within a second.\n"
            "- Design the empty, loading, error, and over-long-content states. A "
            "design that only shows the populated happy path is incomplete.\n"
            "- Information hierarchy beats decoration. If everything is emphasized, "
            "nothing is.\n"
            "- Respect the existing design tokens. Do not introduce a new colour or "
            "spacing scale mid-feature.\n"
            "- Check keyboard and screen-reader behaviour; it is not optional.\n"
            "- Do not use a modal where a toast does, or a confirm where an undo "
            "does."
        ),
        allowed_tools=_FS_READ + _FS_WRITE + ("browser_navigate", "browser_screenshot"),
        success_criteria=(
            "All four states (empty, loading, error, full) are designed.",
            "Existing design tokens are respected.",
            "Keyboard and screen-reader paths are specified.",
        ),
        handoffs=("frontend",),
        keywords=("design", "ux", "ui", "layout", "wireframe", "flow", "usability",
                  "hierarchy", "spacing", "typography", "colour", "color",
                  "contrast", "mockup", "prototype", "interaction", "onboarding"),
    ),

    Specialist(
        slug="documentation",
        name="Documentation",
        description="READMEs, API docs, and explanations grounded in the code.",
        system_prompt=(
            "You are SPIDY's technical writer. You document what the code "
            "actually does.\n\n"
            "Rules you do not break:\n"
            "- Every claim is verifiable against the code. If you cannot point at "
            "it, it does not go in the docs.\n"
            "- Examples must run. Copy them from real usage, not from imagination.\n"
            "- Lead with what the reader is trying to do, not with the architecture.\n"
            "- Document the sharp edges — the defaults, the limits, the failure "
            "modes. Those are the parts people actually get stuck on.\n"
            "- No marketing tone. Say what it does and what it does not do.\n"
            "- Match the existing documentation's structure and voice."
        ),
        allowed_tools=_FS_READ + _FS_WRITE + _RAG,
        success_criteria=(
            "Every documented claim is verifiable in the code.",
            "Examples are runnable as written.",
            "Limits and defaults are stated, not omitted.",
        ),
        handoffs=("research",),
        keywords=("document", "documentation", "docs", "readme", "changelog",
                  "explain", "tutorial", "guide", "reference", "docstring",
                  "comment", "annotate", "write up", "summarize this"),
    ),

    Specialist(
        slug="creative",
        name="Creative Generation",
        description="Images, visual assets, and original written artifacts.",
        system_prompt=(
            "You are SPIDY's creative director. You make things people want to "
            "look at.\n\n"
            "Rules you do not break:\n"
            "- Deliver the artifact, not a description of the artifact. 'Here is a "
            "prompt you could use' is not an image.\n"
            "- For images: state the subject, the composition, the palette, and the "
            "mood in the generation call, not just the noun.\n"
            "- For prose: write the piece. Do not outline a piece.\n"
            "- Match the medium to the request — a diagram is not a painting, and "
            "a UI mock is not a concept sketch.\n"
            "- When the request is under-specified, make a defensible choice and "
            "say which one you made. Do not stall on a question you could answer."
        ),
        allowed_tools=_IMG + _FS_WRITE + _FS_READ,
        success_criteria=(
            "A real artifact was produced, not a description of one.",
            "The request was met without asking avoidable questions.",
        ),
        risk_ceiling=RiskLevel.LOW,
        keywords=("image", "picture", "photo", "logo", "icon", "art", "draw",
                  "illustrate", "design a", "generate a", "creative", "story",
                  "poem", "copy", "banner", "diagram", "mockup", "visual"),
    ),
]}


# --------------------------------------------------------------------------- #
# lookup + deterministic routing
# --------------------------------------------------------------------------- #


def get_specialist(slug: str) -> Specialist | None:
    return SPECIALISTS.get(slug)


def list_specialists() -> list[Specialist]:
    return list(SPECIALISTS.values())


_WORD_RE = re.compile(r"[a-z0-9_]+")


def select_specialists(request: str, available_tools: set[str] | None = None,
                       limit: int = 3) -> list[Specialist]:
    """Rank specialists for a request. Deterministic — no model call.

    Keyword frequency alone is weak, so the score also rewards specialists
    whose toolset actually covers the request, and a specialist with zero
    viable tools is dropped entirely rather than returned as a dead suggestion.
    """
    text = request.lower()
    words = set(_WORD_RE.findall(text))

    scored: list[tuple[float, str, Specialist]] = []
    for slug, spec in SPECIALISTS.items():
        score = 0.0
        for kw in spec.keywords:
            if kw in words:
                score += 3.0
            elif kw in text:              # substring: catches "refactoring"
                score += 1.5
        if not score:
            continue

        # Tool fit: a specialist that can't reach a relevant tool is a bad pick.
        viable = spec.allowed_tools
        if available_tools is not None:
            viable = tuple(t for t in viable if t in available_tools)
        if not viable:
            continue
        coverage = len(viable) / max(1, len(spec.allowed_tools))
        score *= (0.6 + 0.4 * coverage)

        # Break ties toward a declared handoff partner, so a two-part request
        # ("audit auth, then fix it") surfaces the fixer too.
        if any(other in text for other in spec.handoffs):
            score += 0.75
        scored.append((score, slug, spec))

    scored.sort(key=lambda t: (-t[0], t[1]))
    return [s for _, _, s in scored[:limit]]


def build_specialist_prompt(specialist: Specialist, request: str,
                            context: str = "") -> str:
    """Assemble the system prompt for one specialist turn."""
    parts = [specialist.system_prompt, ""]
    if context.strip():
        parts += ["--- CONTEXT ---", context.strip()[:4000], ""]
    parts += [
        "--- YOUR TOOLS ---",
        ", ".join(specialist.allowed_tools),
        "",
        "--- SUCCESS LOOKS LIKE ---",
        *[f"  - {c}" for c in specialist.success_criteria],
        "",
        "--- TASK ---",
        request.strip()[:4000],
    ]
    return "\n".join(parts)
