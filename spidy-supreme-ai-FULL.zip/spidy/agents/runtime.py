"""The agent runtime.

This is the closed loop from the spec:

    INTAKE → UNDERSTAND → PLAN → [APPROVAL] → CONTEXT → ACT → OBSERVE
           → VERIFY? → RECOVER/REPAIR → … → VERIFY → FINALIZE

Every step emits an event, writes a checkpoint, and meters tokens, so a task is
observable, resumable, and interruptible at any point.
"""
from __future__ import annotations

import asyncio
import json
import time
from typing import Any, Callable

from ..brain.native import (
    build_plan, classify_intent, diagnose_failure, infer_arguments,
    select_tool, synthesize,
)
from ..brain.router import ModelRouter
from ..cag.cache import SemanticCache
from ..core.events import BUS, EventBus
from ..core.schemas import (
    AgentPhase, AgentState, ErrorClass, LLMMessage, Plan, PlanStep, RiskLevel,
    TaskResult, TaskStatus, ToolResult, ToolStatus,
)
from ..core.store import Database, get_db
from ..core.token_budget import (
    TokenBudget, compress_observations, dedupe_tool_output, estimate_tokens,
)
from ..security.guard import as_untrusted_context
from ..tools.base import ToolContext, ToolRegistry

SYSTEM_PLAN_PROMPT = """\
You are SPIDY's planner. Convert the user's request into the SMALLEST plan that
actually achieves it.

Rules:
- Prefer reversible steps. Inspect before you edit.
- Every plan that changes something must end with explicit verification.
- Do not add steps "just in case". No speculative tool use.
- Independent read-only steps may run in parallel; dependent steps may not.
- Mark risky steps so the user can approve them.

Reply with ONLY a JSON object:
{"goal": str, "steps": [{"id","action","target","rationale","tool_hint","risk"}],
 "constraints": [str], "success_criteria": [str]}

Actions: inspect | search | read | edit | create | run | test | research |
         verify | analyze
Risks: READ | LOW | MEDIUM | HIGH | DESTRUCTIVE

User request:
"""

SYSTEM_ACT_PROMPT = """\
You are SPIDY's executor. Choose exactly ONE next tool for the current step.

Rules:
- Use a tool only when it produces information or progress you need.
- Fill every required argument. Never invent a path you have not seen.
- If no tool is needed, say so plainly.

Reply with ONLY: {"name": tool_name, "arguments": {...}}
"""

SYSTEM_FINAL_PROMPT = """\
You are SPIDY's verifier and synthesizer.

Ground every claim in the evidence below. If the evidence does not support a
claim, say so — do not fill the gap. State what was verified and what was not.
Be concise and concrete. Reference files and sources by name.
"""


class AgentRuntime:
    def __init__(
        self,
        settings,
        registry: ToolRegistry,
        router: ModelRouter,
        db: Database | None = None,
        retriever: Any = None,
        cache: SemanticCache | None = None,
        events: EventBus | None = None,
    ) -> None:
        self.settings = settings
        self.registry = registry
        self.router = router
        self.db = db or get_db()
        self.retriever = retriever
        self.cache = cache
        self.events = events or BUS
        self._cancelled: set[str] = set()
        self._approvals: dict[str, asyncio.Future] = {}
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------ #
    def cancel(self, task_id: str) -> None:
        self._cancelled.add(task_id)

    def is_cancelled(self, task_id: str) -> bool:
        return task_id in self._cancelled

    async def request_approval(self, task_id: str, request: dict[str, Any],
                               timeout: float = 300) -> bool:
        fut: asyncio.Future = asyncio.get_running_loop().create_future()
        self._approvals[task_id] = fut
        await self.events.emit("approval.required", task_id=task_id, request=request)
        try:
            return await asyncio.wait_for(fut, timeout=timeout)
        except asyncio.TimeoutError:
            return False
        finally:
            self._approvals.pop(task_id, None)

    def resolve_approval(self, task_id: str, approved: bool) -> None:
        fut = self._approvals.get(task_id)
        if fut and not fut.done():
            fut.set_result(approved)

    # ------------------------------------------------------------------ #
    def tool_context(self, state: AgentState,
                     approval_granted: bool = False) -> ToolContext:
        from ..security.policy import CommandPolicy, FilesystemPolicy
        from ..security.ssrf import policy_from_settings

        return ToolContext(
            workspace_root=self.settings.workspace_root,
            permission_mode=self.settings.permission_mode,
            task_id=state.task_id, session_id=state.session_id,
            budget=TokenBudget(
                total=self.settings.task_token_budget,
                model=self.settings.model_token_budget,
                tool_result=self.settings.tool_result_token_budget,
                rag=self.settings.rag_token_budget,
                memory=self.settings.memory_token_budget,
                output=self.settings.output_token_budget,
            ),
            db=self.db, settings=self.settings,
            policy=FilesystemPolicy(self.settings.workspace_root,
                                    self.settings.permission_mode),
            command_policy=CommandPolicy(self.settings.permission_mode),
            network_policy=policy_from_settings(self.settings),
            artifacts_dir=self.settings.artifact_dir,
            allow_network=self.settings.allow_network,
            extra={"approval_granted": approval_granted},
        )

    # ------------------------------------------------------------------ #
    async def run_task(
        self,
        request: str,
        session_id: str = "",
        project_root: str | None = None,
        task_id: str = "",
        context: dict[str, Any] | None = None,
    ) -> TaskResult:
        start = time.perf_counter()
        state = AgentState(
            task_id=task_id or state_id(),
            session_id=session_id or self.db.create_session(request[:80]),
            user_request=request,
            project_root=project_root or str(self.settings.workspace_root),
        )
        self.events.bind(state.task_id)
        budget = TokenBudget(
            total=self.settings.task_token_budget,
            model=self.settings.model_token_budget,
            tool_result=self.settings.tool_result_token_budget,
            rag=self.settings.rag_token_budget,
            memory=self.settings.memory_token_budget,
            output=self.settings.output_token_budget,
        )
        ctx = self.tool_context(state)
        ctx.budget = budget
        seen_output: dict[str, str] = {}

        try:
            await self.events.emit("task.created", task_id=state.task_id,
                                   session_id=state.session_id, request=request[:400])
            self.db.save_task(state)

            # ---- 1. UNDERSTAND ---------------------------------------- #
            state.phase = AgentPhase.UNDERSTAND
            intent = classify_intent(request)
            state.model_route = self.router.role_for(intent.kind, request)
            await self.events.emit(
                "agent.understood", task_id=state.task_id, intent=intent.kind,
                confidence=intent.confidence, complexity=intent.complexity,
                needs_web=intent.needs_web, role=state.model_route)

            # ---- 2. CONTEXT (RAG + memory) ----------------------------- #
            state.phase = AgentPhase.CONTEXT
            await self._gather_context(state, request, intent, budget)

            # ---- 3. PLAN ----------------------------------------------- #
            state.phase = AgentPhase.PLAN
            plan = await self._plan(state, request, intent, budget)
            plan = _drop_useless_steps(self, state, plan)
            state.set_plan_steps(plan.steps)
            state.goal = plan.goal
            state.constraints = plan.constraints
            await self.events.emit("plan.created", task_id=state.task_id,
                                   goal=plan.goal, steps=[s.to_dict() for s in plan.steps])

            # approval gate for the riskiest step
            risky = [s for s in plan.steps if s.risk in (RiskLevel.HIGH, RiskLevel.DESTRUCTIVE)]
            approval_granted = True
            if risky and self.settings.permission_mode in ("SAFE", "BALANCED"):
                state.phase = AgentPhase.APPROVAL
                state.approval_required = True
                state.status = TaskStatus.WAITING_FOR_APPROVAL
                self.db.save_task(state)
                approval_granted = await self.request_approval(state.task_id, {
                    "reason": "plan contains high-risk steps",
                    "steps": [s.to_dict() for s in risky],
                })
                state.approval_status = "approved" if approval_granted else "denied"
                if not approval_granted:
                    state.phase = AgentPhase.FINALIZE
                    state.status = TaskStatus.CANCELLED
                    return await self._finalize(
                        state, "Plan was not approved by the user.", budget, start,
                        error="approval_denied")
            ctx = self.tool_context(state, approval_granted)
            ctx.budget = budget

            # ---- 4. EXECUTE ------------------------------------------- #
            state.status = TaskStatus.RUNNING
            self.db.save_task(state)
            await self._execute_plan(state, plan, intent, ctx, budget, seen_output)

            # ---- 5. VERIFY --------------------------------------------- #
            state.phase = AgentPhase.VERIFY
            verification = await self._verify(state, plan, intent, ctx, budget)
            state.verification = verification
            await self.events.emit("task.verified", task_id=state.task_id,
                                   **verification)

            # ---- 6. FINALIZE ------------------------------------------- #
            state.phase = AgentPhase.FINALIZE
            answer = await self._synthesize(state, request, intent, budget)
            result = await self._finalize(state, answer, budget, start,
                                          verification=verification)
            return result

        except asyncio.CancelledError:
            state.status = TaskStatus.CANCELLED
            await self.events.emit("task.cancelled", task_id=state.task_id)
            self.db.save_task(state)
            return await self._finalize(state, "Task cancelled.", budget, start,
                                        error="cancelled")
        except Exception as exc:  # noqa: BLE001
            state.status = TaskStatus.FAILED
            state.errors.append({"type": type(exc).__name__,
                                 "message": str(exc)[:600] or repr(exc),
                                 "at": time.time()})
            import traceback as _tb
            await self.events.emit("task.failed", task_id=state.task_id,
                                   error=f"{type(exc).__name__}: {exc}",
                                   traceback=_tb.format_exc()[-2500:])
            self.db.save_task(state)
            return await self._finalize(
                state, f"Task failed: {type(exc).__name__}: {exc or repr(exc)}",
                budget, start, error=f"{type(exc).__name__}: {exc}"[:400])
        finally:
            self._cancelled.discard(state.task_id)

    # ------------------------------------------------------------------ #
    # context
    # ------------------------------------------------------------------ #
    async def _gather_context(self, state: AgentState, request: str,
                              intent: Any, budget: TokenBudget) -> None:
        if self.retriever is not None:
            hits = self.retriever.search(
                request, top_k=self.settings.rag_top_k,
                candidates=self.settings.rag_candidate_k,
                project=Path_project(state.project_root),
                budget=budget)
            for h in hits:
                state.retrieved_sources.append({
                    "source": h.source, "uri": h.uri, "score": h.score,
                    "chunk_id": h.chunk_id, "signals": h.signals,
                })
            if hits:
                await self.events.emit("rag.retrieved", task_id=state.task_id,
                                       chunks=len(hits),
                                       sources=[h.source for h in hits[:5]])
                state.retrieved_sources  # keep for context compilation

        # memory: episodic + semantic for this project
        try:
            project = Path_project(state.project_root)
            for scope in ("semantic", "episodic", "preference"):
                rows = self.db.recall(scope=scope, project=project, limit=5)
                for r in rows:
                    state.memory_refs.append(f"{scope}:{r['content'][:200]}")
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    # plan
    # ------------------------------------------------------------------ #
    async def _plan(self, state: AgentState, request: str, intent: Any,
                    budget: TokenBudget) -> Plan:
        prompt = SYSTEM_PLAN_PROMPT + request

        # Deterministic plan first — it is free and usually correct.
        native = build_plan(request, intent, set(self.registry.names()),
                            self.settings.max_plan_steps)

        # Ask a model to improve on it only when the request is genuinely
        # ambiguous or complex enough to benefit.
        if intent.confidence >= 0.5 and intent.complexity <= 3:
            return native

        tools = self.registry.schemas_for_model()
        messages = [LLMMessage(role="user", content=prompt)]
        tool_hint = "\nAvailable tools: " + ", ".join(
            sorted({t["name"] for t in tools})[:60])
        messages[0].content += tool_hint
        resp = await self.router.complete(
            messages, role="reasoning", max_tokens=1400, json_mode=True,
            temperature=0.1)
        budget.spend("model", resp.total_tokens, "plan")

        parsed = _parse_plan(resp.text)
        if parsed and len(parsed.steps) >= 1:
            # Trust the model only for steps whose tool actually exists.
            valid = [s for s in parsed.steps
                     if not s.tool_hint or s.tool_hint in self.registry]
            if len(valid) >= max(1, len(native.steps) // 2):
                merged = parsed
                merged.steps = valid or native.steps
                if not merged.success_criteria:
                    merged.success_criteria = native.success_criteria
                return merged
        return native

    # ------------------------------------------------------------------ #
    # execute
    # ------------------------------------------------------------------ #
    async def _execute_plan(self, state: AgentState, plan: Plan, intent: Any,
                            ctx: ToolContext, budget: TokenBudget,
                            seen: dict[str, str]) -> None:
        steps = plan.steps
        idx = 0
        max_rounds = len(steps) * 2 + 6   # allows for repair attempts

        while idx < len(steps) and max_rounds > 0:
            max_rounds -= 1
            if self.is_cancelled(state.task_id):
                state.status = TaskStatus.CANCELLED
                return

            step = steps[idx]
            state.current_step = idx
            state.phase = AgentPhase.ACT
            await self.events.emit("step.started", task_id=state.task_id,
                                   step=step.id, action=step.action, target=step.target)

            if step.action in ("analyze",) or not step.tool_hint:
                # A pure reasoning step: let the model think, or answer natively.
                result = await self._reasoning_step(state, step, intent, budget)
                if result:
                    step.done = True
                    step.result_summary = result
                    # A reasoning step can itself produce a full synthesized
                    # answer (the native brain falls back that way with no
                    # model). Recording that as a "finding" makes the final
                    # answer quote a previous answer, which then gets quoted
                    # again — visibly recursive and useless.
                    if not _is_synthesized_answer(result):
                        state.record_observation(result, step.id)
                    await self.events.emit("step.finished", task_id=state.task_id,
                                           step=step.id, summary=result[:300])
                idx += 1
                self._persist(state, budget)
                continue

            ok = await self._run_step(state, step, intent, ctx, budget, seen)
            if ok:
                idx += 1
            else:
                # Repair loop: same step, adjusted.
                state.repair_count += 1
                if state.repair_count > self.settings.max_repair_rounds:
                    state.record_observation(
                        f"Step {step.id} failed repeatedly; continuing without it.", step.id)
                    idx += 1
                else:
                    state.phase = AgentPhase.REPAIR
                    await self.events.emit("repair.started", task_id=state.task_id,
                                           step=step.id,
                                           attempt=state.repair_count)

            self._persist(state, budget)

    async def _run_step(self, state: AgentState, step: PlanStep, intent: Any,
                        ctx: ToolContext, budget: TokenBudget,
                        seen: dict[str, str]) -> bool:
        # Cache first — this is where the token savings come from.
        if self.cache is not None and self.settings.cag_enabled:
            cached = self.cache.get_tool_result(
                step.tool_hint, {"target": step.target, "goal": state.goal})
            if cached is not None:
                step.done = True
                step.result_summary = f"{step.tool_hint} (cache hit)"
                state.record_tool(step.tool_hint, cached)
                state.record_observation(
                    f"{step.tool_hint}: {cached.render(500)}", step.id)
                await self.events.emit("tool.finished", task_id=state.task_id,
                                       tool=step.tool_hint, cached=True,
                                       summary=step.result_summary)
                return True

        args = self._args_for(step, state)
        if args is None:
            # The step needs a model to author its arguments. Say so plainly
            # rather than emitting a broken edit and thrashing.
            step.done = True
            step.result_summary = "needs model"
            note = (f"Skipped {step.tool_hint}: this step requires a language model to "
                    f"author its arguments. Everything SPIDY can do without one has "
                    f"been done.")
            state.record_observation(note, step.id)
            await self.events.emit("step.skipped", task_id=state.task_id, step=step.id,
                                   tool=step.tool_hint, reason="requires_model")
            return True

        await self.events.emit("tool.started", task_id=state.task_id,
                               tool=step.tool_hint, arguments=_preview_args(args))

        result = await self.registry.execute(step.tool_hint, args, ctx)

        if result.status is ToolStatus.NEEDS_APPROVAL:
            approved = await self.request_approval(state.task_id, {
                "tool": step.tool_hint, "arguments": _preview_args(args),
                "reason": result.message})
            if not approved:
                state.record_observation(
                    f"User declined {step.tool_hint}; skipping.", step.id)
                step.done = True
                return True
            ctx.extra["approval_granted"] = True
            result = await self.registry.execute(step.tool_hint, args, ctx)
            ctx.extra["approval_granted"] = False

        state.record_tool(step.tool_hint, result)
        if self.cache is not None and self.settings.cag_enabled:
            self.cache.cache_tool_result(step.tool_hint, args, result)

        if result.ok:
            rendered = dedupe_tool_output(result.render(2000), seen)
            step.done = True
            step.result_summary = result.render(300)
            # Record the finding for any tool that produced content. Most tools
            # return structured `data` and leave `stdout` empty — gating on
            # stdout alone meant their findings never reached the synthesizer
            # and every answer came back as "(none)".
            if rendered and not rendered.startswith("[output identical"):
                state.record_observation(
                    f"{step.tool_hint}({step.target or '.'}): {rendered}", step.id)
                _track_files(state, result, step)
            else:
                state.record_observation(
                    f"{step.tool_hint} completed: {step.result_summary[:300]}", step.id)
            await self.events.emit("tool.finished", task_id=state.task_id,
                                   tool=step.tool_hint, ok=True,
                                   duration_ms=result.duration_ms,
                                   summary=result.render(300))
            return True

        # failure path
        err_class = classify_error(result)
        state.phase = AgentPhase.RECOVER
        await self.events.emit("tool.finished", task_id=state.task_id,
                               tool=step.tool_hint, ok=False,
                               error_type=result.error_type,
                               message=result.message[:300])

        if err_class is ErrorClass.NON_RECOVERABLE:
            state.record_observation(
                f"{step.tool_hint} blocked: {result.message} — skipping step.", step.id)
            step.done = True
            return True

        # Adapt the step for the next attempt.
        category, action = diagnose_failure(step.tool_hint, result.data, result.message)
        if category in ("missing_file", "path_issue", "missing_tool"):
            step.target = "."
            step.rationale = f"retry after {category}: {action}"
        elif category == "provider_down":
            step.tool_hint = ""
            step.rationale = "model provider unavailable — answering natively"
            state.model_route = "native"
        elif category == "timeout":
            step.rationale = "retry with a narrower scope"
            step.target = "."
        else:
            step.rationale = f"retry after {category}: {action}"
        state.retry_count += 1
        state.record_observation(
            f"{step.tool_hint} failed ({category}): {result.message[:200]}", step.id)
        return False

    def _args_for(self, step: PlanStep, state: AgentState) -> dict[str, Any] | None:
        """Return None when the step needs model authorship the native engine
        cannot provide. The caller then reports the gap instead of failing."""
        tool = self.registry.get(step.tool_hint)
        if tool is None:
            return None
        spec = tool.spec.to_model_schema()
        return infer_arguments(step.tool_hint, state.user_request, spec,
                               {"prefilled": {"target": step.target} if step.target else {}}) \
            or None

    async def _reasoning_step(self, state: AgentState, step: PlanStep,
                              intent: Any, budget: TokenBudget) -> str:
        ctx_text = compress_observations(state.observations)
        sources = "\n".join(
            f"- {s.get('source','')} {s.get('uri','')}" for s in state.retrieved_sources[:8])
        prompt = (
            f"Goal: {state.goal or state.user_request}\n"
            f"Current step: {step.action} {step.target}\n"
            f"Findings so far:\n{ctx_text or '(none)'}\n"
            f"Sources:\n{sources or '(none)'}\n\n"
            "Give the direct answer or next concrete action. Be specific."
        )
        messages = [LLMMessage(role="user", content=prompt)]
        resp = await self.router.complete(messages, role="reasoning", max_tokens=900,
                                          temperature=0.2)
        budget.spend("model", resp.total_tokens, f"step:{step.id}")
        if resp.error or not resp.text.strip():
            return ""
        return resp.text.strip()[:2000]

    # ------------------------------------------------------------------ #
    # verify
    # ------------------------------------------------------------------ #
    async def _verify(self, state: AgentState, plan: Plan, intent: Any,
                      ctx: ToolContext, budget: TokenBudget) -> dict[str, Any]:
        checks: list[dict[str, Any]] = []

        # 1. structural: did the plan complete?
        steps = plan.steps
        done = sum(1 for s in steps if s.done)
        checks.append({
            "name": "plan_completion", "passed": done == len(steps),
            "detail": f"{done}/{len(steps)} steps completed",
        })

        # 2. tests, if the task ran them
        test_results = [o for o in state.observations if "run_tests" in o["text"]]
        if test_results:
            import re
            blob = " ".join(o["text"] for o in test_results)
            m = re.search(r"(\d+)\s+passed", blob)
            f = re.search(r"(\d+)\s+failed", blob)
            passed = int(m.group(1)) if m else 0
            failed = int(f.group(1)) if f else 0
            checks.append({
                "name": "tests", "passed": failed == 0 and passed > 0,
                "detail": f"{passed} passed, {failed} failed",
            })
            state.tests.append({"passed": passed, "failed": failed})

        # 3. errors
        fatal = [e for e in state.errors
                 if e.get("type") not in ("nonzero_exit",) and
                 not str(e.get("message", "")).startswith("User declined")]
        checks.append({
            "name": "no_unhandled_errors", "passed": not fatal,
            "detail": f"{len(fatal)} unresolved error(s)" if fatal else "clean",
        })

        # 4. grounding: research/explain claims need sources
        if intent.kind in ("research", "explain") and intent.needs_web:
            checks.append({
                "name": "grounded_in_sources", "passed": bool(state.retrieved_sources),
                "detail": f"{len(state.retrieved_sources)} source(s) retrieved",
            })

        # 5. files actually changed
        if intent.mutating:
            changed = state.modified_files + state.created_files
            checks.append({
                "name": "work_performed", "passed": bool(changed) or not intent.needs_files,
                "detail": f"{len(state.created_files)} created, "
                          f"{len(state.modified_files)} modified",
            })

        passed_all = all(c["passed"] for c in checks)
        return {
            "passed": passed_all, "checks": checks,
            "failed_checks": [c["name"] for c in checks if not c["passed"]],
        }

    # ------------------------------------------------------------------ #
    # finalize
    # ------------------------------------------------------------------ #
    async def _synthesize(self, state: AgentState, request: str,
                          intent: Any, budget: TokenBudget) -> str:
        # Cache lookup on the final answer — repeated questions cost nothing.
        if self.cache is not None and self.settings.cag_enabled:
            hit = self.cache.lookup_answer(request, budget)
            if hit.hit and hit.entry:
                prev = hit.entry.payload.get("answer", "")
                if prev:
                    return f"{prev}\n\n_(served from semantic cache, " \
                           f"{int(hit.similarity * 100)}% match, " \
                           f"~{hit.entry.tokens} tokens saved)_"

        observations = [o["text"] for o in state.observations]
        sources = [{"title": s.get("source", ""), "url": s.get("uri", "")}
                   for s in state.retrieved_sources]
        files = state.created_files + state.modified_files
        test_summary = state.tests[-1] if state.tests else None

        evidence = (
            f"Goal: {state.goal or request}\n\n"
            f"Findings:\n" + "\n".join(f"- {o[:600]}" for o in observations[-14:] or ["(none)"]) +
            "\n\nSources:\n" + "\n".join(f"- {s['title']} {s['url']}".strip()
                                          for s in sources) +
            "\n\nVerification: " + json.dumps(state.verification)[:800]
        )
        untrusted = as_untrusted_context(evidence, "task_evidence", max_chars=9000)
        messages = [
            LLMMessage(role="system", content=SYSTEM_FINAL_PROMPT),
            LLMMessage(role="user", content=untrusted +
                       f"\n\nUser request: {request}\n\nAnswer:"),
        ]
        resp = await self.router.complete(messages, role="reasoning",
                                          max_tokens=self.settings.output_token_budget,
                                          temperature=0.25)
        budget.spend("model", resp.total_tokens, "final")
        if resp.error or not resp.text.strip():
            answer = synthesize(request, intent, observations, sources, files, test_summary)
        else:
            answer = resp.text.strip()

        if self.cache is not None and self.settings.cag_enabled:
            self.cache.cache_answer(request, answer,
                                    {"intent": intent.kind, "task_id": state.task_id})
        return answer

    async def _finalize(self, state: AgentState, answer: str, budget: TokenBudget,
                        start: float, verification: dict[str, Any] | None = None,
                        error: str | None = None) -> TaskResult:
        state.phase = AgentPhase.DONE
        if state.status not in (TaskStatus.CANCELLED, TaskStatus.FAILED):
            state.status = TaskStatus.COMPLETED
        self._persist(state, budget)
        # Final checkpoint: the periodic one only fires every 3 steps, so a
        # short task would otherwise never get a complete state written.
        try:
            self.db.checkpoint(state.task_id, state, label="final",
                               files=state.modified_files)
        except Exception:
            pass

        result = TaskResult(
            task_id=state.task_id, goal=state.goal or state.user_request,
            status=state.status.value, answer=answer,
            plan=state.plan, files_changed=state.created_files + state.modified_files,
            sources=state.retrieved_sources, verification=verification or state.verification,
            timeline=self.events.history(120),
            token_usage=budget.summary(), cache=budget.summary(),
            error=error, duration_ms=int((time.perf_counter() - start) * 1000),
        )
        self.db.finish_task(state.task_id, result)
        if self.db is not None and answer:
            try:
                self.db.add_message(state.session_id, "assistant", answer, state.task_id,
                                    {"tokens": budget.total_spent()})
            except Exception:
                pass
        self.db.audit("task.finished", target=state.task_id, outcome=state.status.value,
                      detail={"tokens": budget.total_spent(), "error": error})
        await self.events.emit(
            "task.completed" if state.status is TaskStatus.COMPLETED else "task.failed",
            task_id=state.task_id, status=state.status.value,
            tokens=budget.total_spent(), saved=budget.saved_total())
        return result

    # ------------------------------------------------------------------ #
    def _persist(self, state: AgentState, budget: TokenBudget) -> None:
        try:
            self.db.save_task(state, budget.total_spent(), budget.saved_total())
            if state.current_step and state.current_step % 3 == 0:
                self.db.checkpoint(state.task_id, state,
                                   label=f"step-{state.current_step}",
                                   files=state.modified_files)
        except Exception:
            pass


# --------------------------------------------------------------------------- #


def state_id() -> str:
    from ..core.schemas import new_id
    return new_id("task_")


def Path_project(root: str | None) -> str:
    """Project key for RAG/memory scoping. Empty string means global."""
    if not root:
        return ""
    from pathlib import Path
    try:
        return Path(root).name
    except (OSError, ValueError):
        return ""


def classify_error(result: ToolResult) -> ErrorClass:
    t = (result.error_type or "").lower()
    m = (result.message or "").lower()
    if t in ("policy_denied", "permission_denied", "unknown_tool"):
        return ErrorClass.NON_RECOVERABLE
    if t in ("timeout",):
        return ErrorClass.TRANSIENT
    if t in ("invalid_arguments", "unknown_tool"):
        return ErrorClass.RECOVERABLE
    if result.retryable:
        return ErrorClass.TRANSIENT
    if "connection" in m or "refused" in m or "temporarily" in m:
        return ErrorClass.TRANSIENT
    if t in ("nonzero_exit", "no_match", "ambiguous_match", "not_found", "syntax_error"):
        return ErrorClass.RECOVERABLE
    return ErrorClass.RECOVERABLE


def _parse_plan(text: str) -> Plan | None:
    if not text:
        return None
    blob = text.strip()
    start = blob.find("{")
    if start < 0:
        return None
    depth = 0
    end = -1
    in_str = False
    esc = False
    for i in range(start, len(blob)):
        c = blob[i]
        if esc:
            esc = False
            continue
        if c == "\\":
            esc = True
            continue
        if c == '"':
            in_str = not in_str
            continue
        if in_str:
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                end = i + 1
                break
    if end < 0:
        return None
    try:
        data = json.loads(blob[start:end])
    except (json.JSONDecodeError, ValueError):
        return None
    if not isinstance(data, dict):
        return None
    steps: list[PlanStep] = []
    for i, s in enumerate(data.get("steps", []) or []):
        if not isinstance(s, dict):
            continue
        try:
            risk = RiskLevel(str(s.get("risk", "LOW")).upper())
        except ValueError:
            risk = RiskLevel.LOW
        steps.append(PlanStep(
            id=str(s.get("id", f"S{i + 1}")),
            action=str(s.get("action", "inspect")),
            target=str(s.get("target", "")),
            rationale=str(s.get("rationale", ""))[:300],
            tool_hint=str(s.get("tool_hint", s.get("tool", ""))),
            risk=risk,
        ))
    if not steps:
        return None
    return Plan(
        goal=str(data.get("goal", ""))[:300], steps=steps,
        constraints=[str(c)[:200] for c in (data.get("constraints") or [])][:10],
        success_criteria=[str(c)[:200] for c in (data.get("success_criteria") or [])][:10],
    )


def _track_files(state: AgentState, result: ToolResult, step: PlanStep) -> None:
    data = result.data or {}
    p = data.get("path")
    if isinstance(p, str):
        if data.get("action") == "created":
            if p not in state.created_files:
                state.created_files.append(p)
        elif data.get("action") in ("edited", "patched", "copied", "moved", "overwrote"):
            if p not in state.modified_files:
                state.modified_files.append(p)
    for key in ("files_changed", "modified"):
        v = data.get(key)
        if isinstance(v, list):
            for f in v:
                if isinstance(f, str) and f not in state.modified_files:
                    state.modified_files.append(f)


def _drop_useless_steps(runtime, state: AgentState, plan: Plan) -> Plan:
    """Remove planned steps that cannot produce anything.

    Retrieval against an empty index always returns zero chunks, so the
    step adds a "retrieved 0 chunks" line and a wasted call. When the
    workspace hasn't been indexed, drop it and let the answer be honest
    about what it actually looked at.
    """
    if runtime.retriever is None:
        return plan
    try:
        stats = runtime.retriever.stats()
        has_index = int(stats.get("chunks") or stats.get("documents") or 0) > 0
    except Exception:
        return plan
    if has_index:
        return plan
    kept = [s for s in plan.steps if s.tool_hint != "rag_search"]
    if len(kept) != len(plan.steps):
        plan.steps = kept
        plan.notes = (plan.notes + " " if plan.notes else "") + (
            "Retrieval was skipped: this workspace has no indexed content yet.")
    return plan


_EVIDENCE_ECHO_MARKERS = (
    "Current step:", "Findings so far:", "Sources:", "— Goal:", "Goal: ",
    "What SPIDY did",
)


def _is_synthesized_answer(text: str) -> bool:
    """True when a string is a composed answer, not a raw finding.

    Two shapes show up and neither is evidence:
      * a full composed answer ("**File task** — ...\n\n**What SPIDY did**")
      * an echo of the reasoning prompt's own scaffolding ("- Current step: ...")

    Recording either as a finding makes the final answer quote a previous
    answer, which then gets quoted again — visibly recursive and useless.
    """
    t = (text or "").strip()
    if not t:
        return True
    if t.startswith("**") and "\n\n" in t:
        return True
    if t.startswith("**What SPIDY did**"):
        return True
    lines = [ln.strip(" -\t") for ln in t.splitlines() if ln.strip()]
    if not lines:
        return True
    # If the text is mostly scaffolding headers, it is the prompt talking back.
    echoes = sum(1 for ln in lines
                 if any(ln.startswith(m) for m in _EVIDENCE_ECHO_MARKERS))
    return echoes > len(lines) / 2


def _preview_args(args: dict[str, Any]) -> dict[str, Any]:
    """Never stream a whole file body into the event log."""
    out: dict[str, Any] = {}
    for k, v in args.items():
        if isinstance(v, str) and len(v) > 220:
            out[k] = v[:220] + f"...[{len(v)} chars]"
        else:
            out[k] = v
    return out
