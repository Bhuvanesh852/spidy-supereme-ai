"""Multi-specialist orchestration.

The runtime answers one request in one context. This runs several specialists
in parallel over a dependency DAG, isolates their failures, and synthesizes
the results — which is what turns "an assistant" into "a team".

The concurrency here is real: independent specialists run under
`asyncio.gather`, because the expensive part of an agent turn is waiting on a
model or a subprocess, and serializing that is pure waste.
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, TYPE_CHECKING

from ..core.schemas import LLMMessage
from .specialists import (Specialist,
                          get_specialist, list_specialists, select_specialists)

if TYPE_CHECKING:  # pragma: no cover
    from ..app import Spidy


@dataclass
class TeamStep:
    """One specialist's assignment inside a team run."""

    id: str
    specialist: str
    goal: str
    depends_on: list[str] = field(default_factory=list)
    tools: list[str] = field(default_factory=list)
    status: str = "pending"      # pending | running | done | failed | skipped
    output: str = ""
    error: str = ""
    duration_ms: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id, "specialist": self.specialist, "goal": self.goal,
            "depends_on": self.depends_on, "tools": self.tools,
            "status": self.status, "output": self.output[:4000],
            "error": self.error, "duration_ms": self.duration_ms,
        }


@dataclass
class TeamPlan:
    goal: str
    steps: list[TeamStep] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {"goal": self.goal, "steps": [s.to_dict() for s in self.steps]}


@dataclass
class TeamResult:
    goal: str
    steps: list[TeamStep] = field(default_factory=list)
    answer: str = ""
    ok_steps: int = 0
    failed_steps: int = 0
    duration_ms: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "goal": self.goal,
            "answer": self.answer,
            "ok_steps": self.ok_steps,
            "failed_steps": self.failed_steps,
            "duration_ms": self.duration_ms,
            "steps": [s.to_dict() for s in self.steps],
        }


class TeamRunner:
    """Plans and runs a set of specialists against one goal."""

    def __init__(self, app: "Spidy") -> None:
        self.app = app

    # ------------------------------------------------------------------ #
    # planning
    # ------------------------------------------------------------------ #
    def plan(self, goal: str, limit: int = 3) -> TeamPlan:
        """Choose specialists and give each a slice of the goal.

        Specialists are independent by construction, so the DAG starts flat.
        Handoffs are recorded on each step and resolved after the first pass,
        which keeps planning to one deterministic call.
        """
        available = set(self.app.registry.names())
        chosen = select_specialists(goal, available, limit=limit)
        if not chosen:
            # Nothing matched by keyword: fall back to the general engineer
            # rather than returning an empty plan the caller can't act on.
            fallback = get_specialist("software_engineering")
            chosen = [fallback] if fallback else []

        steps = [
            TeamStep(
                id=f"T{i + 1}",
                specialist=spec.slug,
                goal=self._slice(goal, spec),
                tools=[t for t in spec.allowed_tools if t in available],
            )
            for i, spec in enumerate(chosen)
        ]
        return TeamPlan(goal=goal, steps=steps)

    @staticmethod
    def _slice(goal: str, spec: Specialist) -> str:
        """Narrow the shared goal to what this specialist is responsible for."""
        return (f"{goal}\n\n"
                f"Focus as the {spec.name} specialist: {spec.description} "
                f"Report findings as {spec.name.lower()} conclusions.")

    # ------------------------------------------------------------------ #
    # execution
    # ------------------------------------------------------------------ #
    async def run(self, goal: str, plan: TeamPlan | None = None,
                  limit: int = 3) -> TeamResult:
        started = time.perf_counter()
        plan = plan or self.plan(goal, limit=limit)
        result = TeamResult(goal=goal, steps=plan.steps)

        remaining = list(plan.steps)
        done_ids: set[str] = set()

        # Wave-based scheduling: run everything whose dependencies are met,
        # concurrently, then advance. A wave is the right unit here because
        # specialists are independent and the DAG is shallow.
        while remaining:
            wave = [s for s in remaining if set(s.depends_on) <= done_ids]
            if not wave:
                # A dependency cycle or a step whose deps all failed: break it
                # rather than spinning forever.
                for s in remaining:
                    s.status = "skipped"
                    s.error = "unreachable dependency"
                break

            results = await asyncio.gather(
                *(self._run_step(s) for s in wave), return_exceptions=True)
            for step, res in zip(wave, results):
                if isinstance(res, BaseException):
                    step.status = "failed"
                    step.error = f"{type(res).__name__}: {res}"
                elif res:
                    step.status = "done"
                    done_ids.add(step.id)
                else:
                    step.status = "failed"

            remaining = [s for s in remaining if s.status == "pending"]

        result.ok_steps = sum(1 for s in plan.steps if s.status == "done")
        result.failed_steps = sum(1 for s in plan.steps if s.status != "done")
        result.duration_ms = int((time.perf_counter() - started) * 1000)
        result.answer = await self.synthesize(goal, plan.steps)
        return result

    async def _run_step(self, step: TeamStep) -> bool:
        """Run one specialist. Never raises — failure is recorded, not thrown."""
        spec = get_specialist(step.specialist)
        if spec is None:
            step.status = "failed"
            step.error = f"unknown specialist: {step.specialist}"
            return False

        step.status = "running"
        t0 = time.perf_counter()
        try:
            step.output = await self.delegate(spec, step.goal, step.tools)
            step.duration_ms = int((time.perf_counter() - t0) * 1000)
            return True
        except Exception as exc:  # noqa: BLE001
            step.status = "failed"
            step.error = f"{type(exc).__name__}: {exc}"[:400]
            step.duration_ms = int((time.perf_counter() - t0) * 1000)
            return False

    # ------------------------------------------------------------------ #
    # the primitive everything else is built from
    # ------------------------------------------------------------------ #
    async def delegate(self, spec: Specialist, goal: str,
                       tools: list[str] | None = None) -> str:
        """Run one specialist as a focused sub-task and return its answer.

        This is the seam a specialist registry is for: a narrower prompt, a
        restricted toolset, and a single deliverable.

        The system prompt carries the brief; the *user* message carries only
        the task. Handing a model the full assembled prompt as user text
        invites it to echo the instructions back, which is exactly what the
        deterministic fallback does.
        """
        tool_schemas = [
            s.to_model_schema() for s in self.app.registry.specs()
            if s.name in spec.allowed_tools
            and (tools is None or s.name in tools)
        ]
        messages = [
            LLMMessage(role="system", content=spec.system_prompt),
            LLMMessage(role="user", content=goal.strip()[:4000]),
        ]
        resp = await self.app.router.complete(
            messages, role="reasoning", tools=tool_schemas or None,
            max_tokens=self.app.settings.output_token_budget, temperature=0.3)

        if getattr(resp, "error", None) or not (resp.text or "").strip():
            # No model, or the model failed: fall back to the native brain so
            # the team still produces something. Degraded beats empty — but say
            # what was and wasn't done rather than implying analysis happened.
            return (f"Ran on the native engine — no model was reachable, so this is "
                    f"a tool-execution trace, not a reviewed judgement.\n\n"
                    f"Scope assigned: {goal.strip()[:200]}")
        return resp.text.strip()

    # ------------------------------------------------------------------ #
    async def synthesize(self, goal: str, steps: list[TeamStep]) -> str:
        """Merge the specialists' outputs into one answer.

        Attribution is preserved deliberately: the reader should be able to
        tell which conclusion came from which specialist, and which ones
        failed, rather than reading a confident blend of partial work.
        """
        done = [s for s in steps if s.status == "done"]
        failed = [s for s in steps if s.status != "done"]

        if not done:
            reasons = "; ".join(f"{s.specialist}: {s.error or s.status}"
                                for s in failed) or "no specialist ran"
            return (f"**Team run produced no result.**\n\n"
                    f"Goal: {goal}\n\nEvery specialist failed: {reasons}\n\n"
                    f"This usually means no model provider is reachable and the "
                    f"goal needed generation rather than tool execution.")

        lines = [f"**Team result** — {goal}", ""]
        for s in done:
            spec = get_specialist(s.specialist)
            name = spec.name if spec else s.specialist
            # A step marked done should hold a string, but a misbehaving
            # delegate must not crash the summary of an otherwise good run.
            output = s.output if isinstance(s.output, str) else str(s.output)
            lines.append(f"**{name}** ({s.duration_ms}ms)")
            lines.append(output.strip()[:2500])
            lines.append("")
        if failed:
            names = ", ".join(s.specialist for s in failed)
            lines.append("---")
            lines.append(f"⚠ {names} did not complete. Treat their scope as "
                         f"uncovered rather than as clean.")
        return "\n".join(lines).strip()

    # ------------------------------------------------------------------ #
    def roster(self) -> list[dict[str, Any]]:
        return [s.to_dict() for s in list_specialists()]
