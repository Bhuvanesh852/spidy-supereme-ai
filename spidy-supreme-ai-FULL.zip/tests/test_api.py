"""HTTP surface: routes, tenancy, SSE, and the offline-first guarantees.

The bar for every test here is that the API behaves the same with zero models
running as it does with one — degraded must look intentional, and a failing
task must never become an HTTP 500.
"""
from __future__ import annotations

import time

import pytest


# --------------------------------------------------------------------------- #
# metadata
# --------------------------------------------------------------------------- #


def test_health_reports_truthfully_with_no_models(client, clean_env):
    d = client.get("/api/health").json()
    assert d["status"] == "ok"
    assert d["tools"] >= 45
    # The offline badge is driven by this flag, so it must be a real probe:
    # with no LLM reachable it is True, and the native floor is still up.
    assert d["offline_mode"] is True
    assert d["native_floor"] is True
    # A provider that is merely "not blocked by config" must not claim reachable.
    assert d["providers"]["ollama"]["reachable"] is False


def test_tools_endpoint_lists_the_registry(client):
    d = client.get("/api/tools").json()
    assert len(d) >= 45
    for t in d[:5]:
        assert {"name", "description", "risk_level", "tags", "input_schema"} <= set(t)


def test_models_endpoint_flags_unreachable_providers(client):
    d = client.get("/api/models").json()
    by = {m["slug"]: m for m in d}
    # The native floor is always usable; a cloud provider with no key must not
    # claim to be reachable.
    assert by["native"]["reachable"] is True
    assert by["openai"]["configured"] is False
    assert by["ollama"]["reachable"] is False


# --------------------------------------------------------------------------- #
# files
# --------------------------------------------------------------------------- #


def test_files_roundtrip(client, sample_project):
    listed = client.get("/api/files").json()
    assert any(f["path"] == "main.py" for f in listed)

    read = client.get("/api/files/content?path=main.py").json()
    assert "def add" in read["content"]

    client.put("/api/files/content", json={"path": "notes.txt", "content": "hello"})
    again = client.get("/api/files/content?path=notes.txt").json()
    assert again["content"] == "hello"


def test_files_refuse_to_escape_the_workspace(client):
    r = client.get("/api/files/content?path=../../etc/passwd")
    assert r.status_code == 403
    assert r.json()["error"]["code"] == "policy_denied"


# --------------------------------------------------------------------------- #
# chat + tasks
# --------------------------------------------------------------------------- #


def _wait(client, task_id, tries=80):
    for _ in range(tries):
        r = client.get(f"/api/tasks/{task_id}")
        if r.status_code == 200:
            d = r.json()
            if d.get("status") in ("completed", "failed", "cancelled"):
                return d
        time.sleep(0.15)
    return client.get(f"/api/tasks/{task_id}").json()


def test_chat_completes_offline_with_native_brain(client, sample_project, clean_env):
    r = client.post("/api/chat", json={"message": "read main.py and list its functions"})
    assert r.status_code == 200
    tid = r.json()["task_id"]

    d = _wait(client, tid)
    assert d["status"] == "completed", d
    # The point of the whole exercise: real tools ran and produced real output.
    assert d["observations"], "expected recorded observations"
    assert "main.py" in d["answer"]


def test_task_run_records_observations(client, sample_project, clean_env):
    tid = client.post("/api/chat",
                      json={"message": "read main.py and search for TODO"}).json()["task_id"]
    d = _wait(client, tid)
    assert d["observations"]
    assert any("TODO" in o["text"] for o in d["observations"])


def test_unknown_task_is_404_with_error_envelope(client):
    r = client.get("/api/tasks/does-not-exist")
    assert r.status_code == 404
    assert r.json()["error"]["code"] == "not_found"


# --------------------------------------------------------------------------- #
# SSE
# --------------------------------------------------------------------------- #


@pytest.fixture()
def live_server(app):
    """A real uvicorn server on a background thread.

    SSE needs a genuine streaming connection; the in-process TestClient
    buffers and never yields frames for a stream that stays open.
    """
    import socket
    import threading
    import uvicorn
    from spidy.api.server import create_app

    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()

    server = uvicorn.Server(uvicorn.Config(
        create_app(), host="127.0.0.1", port=port, log_level="critical"))
    t = threading.Thread(target=server.run, daemon=True)
    t.start()
    for _ in range(120):
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                break
        except OSError:
            time.sleep(0.1)
    yield port
    server.should_exit = True
    t.join(timeout=5)


def _curl_stream(port, path, out, seconds):
    """Run `curl -N` against the stream and write frames to `out`.

    curl handles chunked decoding, which is the one thing a hand-rolled
    socket reader keeps getting wrong. This tests the bytes a browser sees.
    """
    import subprocess
    subprocess.run(
        ["curl", "-sN", "--max-time", str(seconds),
         f"http://127.0.0.1:{port}{path}"],
        stdout=out, stderr=subprocess.DEVNULL, timeout=seconds + 10)


def test_sse_streams_task_events(live_server, sample_project, clean_env, tmp_path):
    """A live task must reach the browser as ordered SSE frames."""
    import json as _json
    import urllib.request
    import subprocess

    out = (tmp_path / "sse.txt").open("wb")
    reader = subprocess.Popen(
        ["curl", "-sN", "--max-time", "25",
         f"http://127.0.0.1:{live_server}/api/events/stream"],
        stdout=out, stderr=subprocess.DEVNULL)
    time.sleep(1.0)   # let the stream attach before the task emits

    req = urllib.request.Request(
        f"http://127.0.0.1:{live_server}/api/chat",
        data=_json.dumps({"message": "read main.py"}).encode(),
        headers={"content-type": "application/json"})
    urllib.request.urlopen(req, timeout=15).read()

    deadline = time.time() + 25
    text = ""
    while time.time() < deadline:
        time.sleep(0.4)
        text = out.name and (tmp_path / "sse.txt").read_text(errors="replace")
        if "task.completed" in text or reader.poll() is not None:
            break
    reader.terminate()
    try:
        out.close()
    except Exception:
        pass

    names = [l.split(":", 1)[1].strip()
             for l in text.splitlines() if l.startswith("event:")]
    assert "task.created" in names, names
    assert "plan.created" in names, names
    assert any(n.startswith("tool.") for n in names), names
    # Ordering matters: the plan exists before any tool runs.
    assert names.index("plan.created") < min(
        i for i, n in enumerate(names) if n.startswith("tool."))


def test_sse_replays_persisted_events(live_server, sample_project, clean_env, tmp_path):
    """Refreshing mid-task must not lose the trail: events were persisted."""
    import json as _json
    import urllib.request
    import subprocess

    req = urllib.request.Request(
        f"http://127.0.0.1:{live_server}/api/chat",
        data=_json.dumps({"message": "read main.py"}).encode(),
        headers={"content-type": "application/json"})
    task_id = _json.loads(urllib.request.urlopen(req, timeout=15).read())["task_id"]

    for _ in range(150):
        with urllib.request.urlopen(
                f"http://127.0.0.1:{live_server}/api/tasks/{task_id}", timeout=10) as r:
            if _json.loads(r.read()).get("status") in ("completed", "failed"):
                break
        time.sleep(0.2)

    out = (tmp_path / "replay.txt").open("wb")
    subprocess.run(
        ["curl", "-sN", "--max-time", "6",
         f"http://127.0.0.1:{live_server}/api/events/stream?replay={task_id}"],
        stdout=out, stderr=subprocess.DEVNULL, timeout=20)
    out.close()
    text = (tmp_path / "replay.txt").read_text(errors="replace")

    names = [l.split(":", 1)[1].strip()
             for l in text.splitlines() if l.startswith("event:")]
    assert "task.created" in names, names
    assert '"replay": true' in text, "replayed frames should be marked for the client"


# --------------------------------------------------------------------------- #
# tenancy
# --------------------------------------------------------------------------- #


class _Req:
    def __init__(self, headers):
        self.headers = headers


def test_local_mode_needs_no_auth(home, monkeypatch):
    from spidy.api.tenancy import resolve_tenant
    monkeypatch.delenv("SPIDY_MODE", raising=False)
    assert resolve_tenant(_Req({})).tenant_id == "local"


def test_server_mode_rejects_missing_token(home, monkeypatch):
    from spidy.api.tenancy import ApiError, resolve_tenant
    monkeypatch.setenv("SPIDY_MODE", "server")
    monkeypatch.setenv("SPIDY_TOKENS", "secret:alice")
    with pytest.raises(ApiError) as ei:
        resolve_tenant(_Req({}))
    assert ei.value.status == 401


def test_server_mode_maps_token_to_tenant(home, monkeypatch):
    from spidy.api.tenancy import resolve_tenant
    monkeypatch.setenv("SPIDY_MODE", "server")
    monkeypatch.setenv("SPIDY_TOKENS", "secret:alice,other:bob")
    ctx = resolve_tenant(_Req({"authorization": "Bearer secret"}))
    assert ctx.tenant_id == "alice"
    assert resolve_tenant(_Req({"authorization": "Bearer other"})).tenant_id == "bob"


def test_server_mode_fails_closed_for_shell_without_container(home, monkeypatch):
    from spidy.api.tenancy import ApiError, TenantContext, assert_shell_allowed
    monkeypatch.setenv("SPIDY_SANDBOX", "local")
    ctx = TenantContext(tenant_id="alice", mode="server", sandbox_kind="local")
    with pytest.raises(ApiError) as ei:
        assert_shell_allowed(ctx)
    assert ei.value.status == 403
    assert ei.value.code == "sandbox_unavailable"


def test_local_mode_allows_shell(home, monkeypatch):
    from spidy.api.tenancy import TenantContext, assert_shell_allowed
    monkeypatch.setenv("SPIDY_SANDBOX", "local")
    assert_shell_allowed(TenantContext("local", "local", "local"))


def test_rate_limit_returns_429(home, monkeypatch):
    from spidy.api.tenancy import ApiError, TenantContext, rate_limit
    ctx = TenantContext(tenant_id="x", mode="local", sandbox_kind="local", limit_per_min=2)
    rate_limit(ctx); rate_limit(ctx)
    with pytest.raises(ApiError) as ei:
        rate_limit(ctx)
    assert ei.value.status == 429


# --------------------------------------------------------------------------- #
# settings
# --------------------------------------------------------------------------- #


def test_settings_redacts_secrets(client, app, monkeypatch):
    # Settings fields bind their defaults at import time, so patch the live
    # object rather than the environment — this is the value the API serializes.
    monkeypatch.setattr(app.settings, "anthropic_api_key", "sk-ant-super-secret-value-123456")
    d = client.get("/api/settings").json()
    assert d["anthropic_api_key"] == "***redacted***"
    assert "sk-ant-super-secret" not in str(d)


def test_settings_never_expose_raw_secrets(client, app):
    d = client.get("/api/settings").json()
    for key, value in d.items():
        if any(h in key.lower() for h in ("key", "token", "secret", "password")):
            if value:
                assert value == "***redacted***", f"{key} leaked: {value!r}"


def test_settings_patch_rejects_paths(client):
    r = client.patch("/api/settings", json={"workspace_root": "/etc"}).json()
    assert "workspace_root" in r["rejected"]


# --------------------------------------------------------------------------- #
# UI delivery
# --------------------------------------------------------------------------- #


def test_ui_is_served(client):
    r = client.get("/")
    assert r.status_code == 200
    assert "SPIDY" in r.text
    assert "app.js" in r.text


def test_ui_assets_are_served(client):
    assert client.get("/app.js").status_code == 200
    assert client.get("/app.css").status_code == 200


def test_ui_has_no_external_references():
    """The offline guarantee is the product; a CDN link would break it.

    XML namespace URIs (xmlns) are identifiers, not fetches, so they are
    allowed. What must not appear is a resource the browser would go get:
    a script/link/img source pointing at a live host.
    """
    import re
    from pathlib import Path
    ui = Path(__file__).resolve().parent.parent / "spidy" / "ui"
    assert ui.is_dir()

    for f in ui.glob("*"):
        if f.suffix not in (".html", ".css", ".js"):
            continue
        text = f.read_text(encoding="utf-8")

        # No @import / url() pointing at a host.
        for m in re.finditer(r"@import\s+[\"']?(https?://[^\"'\s)]+)", text):
            raise AssertionError(f"{f.name}: CSS @import {m.group(1)}")
        for m in re.finditer(r"url\(\s*[\"']?(https?://[^\"'\s)]+)", text):
            raise AssertionError(f"{f.name}: CSS url() {m.group(1)}")

        # No tag that causes a fetch to a remote origin.
        for m in re.finditer(
                r"<(?:script|img|iframe|link|source|video|audio)\b[^>]*"
                r"[\"']\s*(?:src|href)\s*=\s*[\"']([^\"']+)", text, re.I):
            url = m.group(1)
            assert not url.startswith(("http://", "https://", "//")), \
                f"{f.name}: external resource {url}"

        # In JS/HTML, a literal absolute URL outside a comment would mean a
        # fetch. XML namespace URIs are identifiers the browser never
        # retrieves, so they are exempt.
        NAMESPACES = ("http://www.w3.org/2000/svg",
                      "http://www.w3.org/1999/xhtml",
                      "http://www.w3.org/1999/xlink")
        for m in re.finditer(r"[\"'`](https?://[^\"'`\s]+)", text):
            if m.group(1).startswith(NAMESPACES):
                continue
            raise AssertionError(f"{f.name}: absolute URL literal {m.group(1)}")
