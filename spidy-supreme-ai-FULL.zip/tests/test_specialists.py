"""Specialist registry and team orchestration.

The most important test here is `test_every_allowed_tool_exists`: a typo'd tool
name in a specialist's allowlist is a silent production bug — the agent
believes it can call a tool that was never registered, and nothing complains
until a real task needs it.
"""
from __future__ import annotations

import asyncio

import pytest

from spidy.agents.specialists import (SPECIALISTS, build_specialist_prompt,
                                      get_specialist, list_specialists,
                                      select_specialists)
from spidy.agents.team import TeamRunner, TeamStep
from spidy.core.schemas import RiskLevel

EXPECTED_SLUGS = {
    "research", "software_engineering", "frontend", "backend", "data",
    "security", "devops", "testing", "uiux", "documentation", "creative",
}


# --------------------------------------------------------------------------- #
# registry
# --------------------------------------------------------------------------- #


def test_all_eleven_specialists_register():
    assert set(SPECIALISTS) == EXPECTED_SLUGS
    assert len(list_specialists()) == 11


def test_every_allowed_tool_exists_in_the_real_registry(app):
    """A name in an allowlist that isn't registered is a silent failure."""
    real = set(app.registry.names())
    missing = [
        (spec.slug, tool)
        for spec in SPECIALISTS.values()
        for tool in spec.allowed_tools
        if tool not in real
    ]
    assert not missing, f"allowlists reference unregistered tools: {missing}"


def test_every_specialist_is_fully_specified():
    for spec in SPECIALISTS.values():
        assert spec.name and spec.description
        assert len(spec.system_prompt) > 200, f"{spec.slug}: prompt too thin"
        assert spec.allowed_tools, f"{spec.slug}: no tools"
        assert spec.success_criteria, f"{spec.slug}: no success criteria"
        assert spec.keywords, f"{spec.slug}: unroutable without keywords"


def test_risk_ceilings_are_sane():
    # An auditor must not be able to rewrite production.
    assert get_specialist("security").risk_ceiling == RiskLevel.LOW
    assert get_specialist("creative").risk_ceiling == RiskLevel.LOW
    # An engineer is allowed to edit.
    assert get_specialist("software_engineering").can_auto(RiskLevel.MEDIUM)
    assert not get_specialist("software_engineering").can_auto(RiskLevel.DESTRUCTIVE)


def test_specialists_are_immutable():
    spec = get_specialist("testing")
    with pytest.raises(Exception):
        spec.name = "changed"          # type: ignore[misc]


# --------------------------------------------------------------------------- #
# deterministic routing
# --------------------------------------------------------------------------- #


@pytest.mark.parametrize("request_,expected", [
    ("find and compare recent papers on retrieval augmentation", "research"),
    ("fix the failing test in test_api.py", "testing"),
    ("check this endpoint for SQL injection vulnerabilities", "security"),
    ("analyze sales.csv and plot the trend", "data"),
    ("generate a logo for a coffee shop", "creative"),
    ("write a README for this module", "documentation"),
    ("set up docker and a CI pipeline", "devops"),
    ("build a responsive navbar component", "frontend"),
    ("add a REST endpoint for user profiles", "backend"),
    ("redesign the onboarding flow", "uiux"),
    ("refactor this function to be faster", "software_engineering"),
])
def test_routing_picks_the_right_specialist(request_, expected):
    assert select_specialists(request_, limit=1)[0].slug == expected


def test_routing_is_deterministic():
    req = "audit the auth module for injection risks and fix what you find"
    a = [s.slug for s in select_specialists(req)]
    b = [s.slug for s in select_specialists(req)]
    assert a == b


def test_routing_drops_specialists_with_no_viable_tools():
    # If only `write_file` exists, `security` (audit-only) can't do its job.
    picked = select_specialists("security vulnerability audit", {"write_file"}, limit=3)
    assert "security" not in [s.slug for s in picked]


def test_routing_returns_nothing_for_unrelated_text():
    assert select_specialists("zzzz qqqq", {"read_file"}) == []


# --------------------------------------------------------------------------- #
# prompt assembly
# --------------------------------------------------------------------------- #


def test_prompt_includes_brief_tools_and_criteria():
    spec = get_specialist("security")
    p = build_specialist_prompt(spec, "audit auth", context="src/auth.py")
    assert spec.system_prompt[:60] in p
    assert "read_file" in p
    assert "audit auth" in p
    assert "src/auth.py" in p
    assert any(c in p for c in spec.success_criteria)


# --------------------------------------------------------------------------- #
# team runner
# --------------------------------------------------------------------------- #


def test_plan_assigns_specialists_to_one_goal(app):
    plan = app.team.plan("review the auth module for injection bugs and fix them")
    assert plan.steps
    assert all(s.specialist in SPECIALISTS for s in plan.steps)
    assert all(s.tools for s in plan.steps), "each step needs at least one live tool"


def test_plan_falls_back_when_nothing_matches(app):
    plan = app.team.plan("zzzz qqqq")
    assert plan.steps, "a plan must always be actionable"


def test_team_runs_offline_with_no_models(app):
    """Zero models must still produce a team result, degraded but honest."""
    result = asyncio.run(app.team.run(
        "review the code for bugs and document what you find", limit=3))
    assert result.steps
    assert result.ok_steps + result.failed_steps == len(result.steps)
    # Every step reaches a terminal state — nothing left 'running'.
    assert all(s.status in ("done", "failed", "skipped") for s in result.steps)
    assert result.answer


def test_one_failing_specialist_does_not_abort_the_run(app, monkeypatch):
    runner = app.team
    original = runner.delegate
    calls = {"n": 0}

    async def flaky(spec, goal, tools=None):
        calls["n"] += 1
        if calls["n"] == 1:
            raise RuntimeError("specialist exploded")
        return await original(spec, goal, tools)

    monkeypatch.setattr(runner, "delegate", flaky)
    result = asyncio.run(runner.run("fix bugs and document the fix", limit=3))

    assert calls["n"] > 1, "the run stopped at the first failure"
    assert any(s.status == "failed" for s in result.steps)
    assert result.answer, "a partial result is still a result"


def test_team_run_isolates_a_hard_exception(app, monkeypatch):
    async def boom(spec, goal, tools=None):
        raise ValueError("nope")
    monkeypatch.setattr(app.team, "delegate", boom)
    result = asyncio.run(app.team.run("anything", limit=2))
    assert result.failed_steps == len(result.steps)
    assert "produced no result" in result.answer.lower()


def test_cycle_does_not_hang(app):
    """A step whose dependency never resolves must be skipped, not spin."""
    goal = "review the auth module for injection risks and fix them"
    plan = app.team.plan(goal, limit=3)
    assert len(plan.steps) >= 2, "need a multi-step plan to test this"
    for s in plan.steps:
        s.depends_on = ["T99"]          # unresolvable id
    result = asyncio.run(app.team.run(goal, plan=plan))
    assert result.duration_ms < 30_000
    assert all(s.status != "pending" for s in result.steps)
    assert all(s.status == "skipped" for s in result.steps)


def test_synthesis_preserves_attribution_and_flags_failures(app):
    steps = [
        TeamStep(id="T1", specialist="research", goal="g", status="done",
                 output="Findings: the paper says X", duration_ms=12),
        TeamStep(id="T2", specialist="security", goal="g", status="failed",
                 error="timeout"),
    ]
    out = asyncio.run(app.team.synthesize("goal", steps))
    assert "AI Research" in out
    assert "the paper says X" in out
    assert "security" in out
    assert "did not complete" in out


def test_delegate_uses_only_the_specialists_tools(app):
    spec = get_specialist("creative")
    captured = {}

    async def fake_complete(messages, **kw):
        captured["tools"] = kw.get("tools")
        class R:
            text = "made a thing"
            error = None
        return R()

    app.router.complete = fake_complete
    asyncio.run(app.team.delegate(spec, "make a logo"))
    names = {t["name"] for t in (captured["tools"] or [])}
    assert names <= set(spec.allowed_tools), f"leaked tools: {names - set(spec.allowed_tools)}"
    assert names, "expected at least one tool in the schema list"
