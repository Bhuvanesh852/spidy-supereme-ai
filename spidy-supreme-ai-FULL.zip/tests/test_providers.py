"""Multi-provider support: catalog, registration, routing, and API surface.

The failure mode these guard against is a provider that *claims* to be usable
and then 404s at call time, or a key that leaks through /api/settings. Both
are worse than a provider simply being absent.
"""
from __future__ import annotations

import os

import pytest

from conftest import fresh_settings

from spidy.brain.catalog import (PROVIDERS, ProviderSpec, configured_providers,
                                 context_window, default_model_for,
                                 get_provider, list_providers, model_capabilities)

# Providers that must exist and be wired to an env var.
CLOUD_SLUGS = ["openai", "anthropic", "google", "openrouter", "groq",
               "together", "deepseek", "mistral", "xai", "fireworks", "cerebras"]


# --------------------------------------------------------------------------- #
# catalog
# --------------------------------------------------------------------------- #


def test_every_expected_provider_is_in_the_catalog():
    for slug in CLOUD_SLUGS + ["ollama", "llamacpp"]:
        assert get_provider(slug) is not None, f"missing provider: {slug}"


def test_each_provider_declares_a_key_env_and_a_base_url():
    for slug in CLOUD_SLUGS:
        p = get_provider(slug)
        assert p.key_env, f"{slug} has no key_env"
        assert p.base_url.startswith("https://"), f"{slug} base_url is not https"
        assert p.kind in ("openai", "anthropic", "google")


def test_every_cloud_provider_advertises_at_least_one_model():
    for slug in CLOUD_SLUGS:
        p = get_provider(slug)
        assert p.models, f"{slug} has no models"
        assert p.default_model in {m.id for m in p.models}, \
            f"{slug}: default_model is not in its catalog"


def test_default_models_are_globally_unique_per_provider():
    """A default that isn't served by that provider 404s at call time."""
    for slug in CLOUD_SLUGS:
        p = get_provider(slug)
        assert p.default_model in {m.id for m in p.models}


def test_provider_priority_orders_local_first():
    order = [p.slug for p in list_providers()]
    local_idx = min(order.index("ollama"), order.index("llamacpp"))
    for slug in CLOUD_SLUGS:
        assert order.index(slug) > local_idx, \
            f"{slug} is ranked ahead of the local providers"


def test_capabilities_report_sane_context_windows():
    for slug in CLOUD_SLUGS:
        p = get_provider(slug)
        for m in p.models:
            assert m.context >= 4096, f"{slug}/{m.id} context too small"
    # The longest-context provider should be a real one, not a typo'd number.
    assert max(context_window(s, get_provider(s).models[0].id) for s in CLOUD_SLUGS) > 100_000


# --------------------------------------------------------------------------- #
# registration
# --------------------------------------------------------------------------- #


def test_no_keys_means_only_local_providers(home, monkeypatch):
    for var in list(os.environ):
        if var.endswith("_API_KEY"):
            monkeypatch.delenv(var, raising=False)
    from spidy.app import Spidy, reset_app
    app = Spidy(fresh_settings())
    assert set(app.router.providers) == {"ollama", "llamacpp", "native"}
    app.close(); reset_app()


@pytest.mark.parametrize("env,slug", [
    ("OPENAI_API_KEY", "openai"),
    ("ANTHROPIC_API_KEY", "anthropic"),
    ("GOOGLE_API_KEY", "google"),
    ("OPENROUTER_API_KEY", "openrouter"),
    ("GROQ_API_KEY", "groq"),
    ("TOGETHER_API_KEY", "together"),
    ("DEEPSEEK_API_KEY", "deepseek"),
    ("MISTRAL_API_KEY", "mistral"),
    ("XAI_API_KEY", "xai"),
    ("FIREWORKS_API_KEY", "fireworks"),
    ("CEREBRAS_API_KEY", "cerebras"),
])
def test_each_key_registers_exactly_its_provider(home, monkeypatch, env, slug):
    monkeypatch.setenv(env, "test-key-value")
    from spidy.app import Spidy, reset_app
    app = Spidy(fresh_settings())
    assert slug in app.router.providers
    assert app.router.providers[slug].available is True
    # Native is always the last resort, never removed.
    assert "native" in app.router.providers
    app.close(); reset_app()


def test_offline_only_forbids_cloud_even_with_keys(home, monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "x")
    monkeypatch.setenv("SPIDY_OFFLINE_ONLY", "true")
    from spidy.app import Spidy, reset_app
    app = Spidy(fresh_settings())
    assert "openai" not in app.router.providers
    app.close(); reset_app()


def test_allow_cloud_false_forbids_cloud(home, monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "x")
    monkeypatch.setenv("SPIDY_ALLOW_CLOUD", "false")
    from spidy.app import Spidy, reset_app
    app = Spidy(fresh_settings())
    assert "openai" not in app.router.providers
    app.close(); reset_app()


def test_gemini_api_key_alias_works(home, monkeypatch):
    monkeypatch.setenv("GEMINI_API_KEY", "x")
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
    assert fresh_settings().google_api_key == "x"


def test_explicit_google_key_beats_the_gemini_alias(home, monkeypatch):
    monkeypatch.setenv("GOOGLE_API_KEY", "winner")
    monkeypatch.setenv("GEMINI_API_KEY", "loser")
    assert fresh_settings().google_api_key == "winner"


def test_base_url_override_is_honoured(home, monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "x")
    monkeypatch.setenv("OPENAI_BASE_URL", "http://127.0.0.1:9999/v1")
    from spidy.app import Spidy, reset_app
    app = Spidy(fresh_settings())
    assert app.router.providers["openai"].base_url == "http://127.0.0.1:9999/v1"
    app.close(); reset_app()


# --------------------------------------------------------------------------- #
# model resolution
# --------------------------------------------------------------------------- #


def test_model_for_is_provider_specific(app):
    """Sending OpenAI's model name to Anthropic would 404."""
    for slug in CLOUD_SLUGS:
        got = app.router.model_for(slug)
        p = get_provider(slug)
        assert got == p.default_model, slug


def test_pinned_model_wins_over_catalog_default(home, monkeypatch):
    monkeypatch.setenv("SPIDY_PROVIDER_MODELS", "groq=llama-3.3-70b-versatile")
    assert default_model_for(fresh_settings(), "groq") == "llama-3.3-70b-versatile"


def test_role_pin_is_scoped_to_its_provider(app):
    """An unscoped pin must not leak to a provider that can't serve it."""
    app.settings.model_roles = {"fast": "groq:llama-3.3-70b-versatile"}
    assert app.router.model_for("groq") == "llama-3.3-70b-versatile"
    # Anthropic must not be handed a Groq model name.
    assert app.router.model_for("anthropic") == get_provider("anthropic").default_model


def test_bare_role_pin_applies_to_local_providers_only(home, monkeypatch):
    from spidy.app import Spidy, reset_app
    app = Spidy(fresh_settings())
    app.settings.model_roles = {"fast": "gemma3:4b"}
    assert app.router.model_for("ollama") == "gemma3:4b"
    assert app.router.model_for("openai") == get_provider("openai").default_model
    app.close(); reset_app()


def test_legacy_default_does_not_leak_to_cloud(app):
    """The old default was a bare Ollama name for every role — guard it."""
    for slug in ("openai", "anthropic", "google", "groq", "deepseek"):
        got = app.router.model_for(slug)
        assert got == get_provider(slug).default_model, slug
        assert "gemma" not in got, f"{slug} was handed {got!r}"


def test_env_map_parses_and_drops_junk(monkeypatch):
    from spidy.core.config import _env_map
    monkeypatch.setenv("T_MAP", "a=1, b = 2 ,bad,=x,")
    assert _env_map("T_MAP") == {"a": "1", "b": "2"}


# --------------------------------------------------------------------------- #
# provider classes
# --------------------------------------------------------------------------- #


def test_google_provider_uses_its_own_wire_format(home):
    from spidy.brain.cloud import GoogleProvider
    p = GoogleProvider(fresh_settings(), api_key="k", base_url="https://x/v1beta")
    assert p.api_key == "k"
    assert p.base_url.endswith("/v1beta")
    assert p.available is True


def test_anthropic_provider_sends_version_header(home):
    from spidy.brain.cloud import AnthropicProvider
    p = AnthropicProvider(fresh_settings(), api_key="k")
    assert p._headers()["anthropic-version"]
    assert p._headers()["x-api-key"] == "k"


def test_tool_schema_translation_per_provider():
    from spidy.brain.cloud import _tool_schemas
    tools = [{"name": "read_file", "description": "read",
              "input_schema": {"type": "object", "properties": {
                  "path": {"type": "string"}, "n": {"type": "integer"}},
                  "required": ["path"]}}]
    g = _tool_schemas(tools, "google")[0]
    a = _tool_schemas(tools, "anthropic")[0]
    assert g["parameters"]["properties"]["path"]["type"] == "STRING"
    assert g["parameters"]["properties"]["n"]["type"] == "INTEGER"
    assert a["input_schema"]["required"] == ["path"]


def test_unreachable_provider_reports_unreachable(home):
    """A provider that can't be probed must say so, not claim it works."""
    import asyncio
    from spidy.app import Spidy, reset_app
    app = Spidy(fresh_settings())
    p = app.router.providers["ollama"]
    reachable, models = asyncio.run(p.probe())[:2]
    assert reachable is False and models == []
    app.close(); reset_app()


def test_env_var_set_after_import_is_still_read(home, monkeypatch):
    """Settings must not snapshot the environment at import time."""
    import spidy.core.config as cfg      # module already imported
    monkeypatch.setenv("OPENAI_API_KEY", "set-after-import")
    assert cfg.Settings().openai_api_key == "set-after-import"


# --------------------------------------------------------------------------- #
# secret hygiene
# --------------------------------------------------------------------------- #


def test_no_provider_key_ever_leaks_from_settings(home, monkeypatch):
    for env in ("OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GOOGLE_API_KEY",
                "OPENROUTER_API_KEY", "GROQ_API_KEY", "DEEPSEEK_API_KEY",
                "XAI_API_KEY", "MISTRAL_API_KEY", "FIREWORKS_API_KEY",
                "TOGETHER_API_KEY", "CEREBRAS_API_KEY"):
        monkeypatch.setenv(env, "sk-super-secret-value-1234")
    from spidy.core.config import Settings
    d = Settings().to_dict()
    blob = repr(d)
    assert "sk-super-secret" not in blob
    for k, v in d.items():
        if "key" in k.lower() and v:
            assert v == "***set***", f"{k} leaked: {v!r}"


def test_api_settings_never_returns_a_key(client, app):
    for slug in CLOUD_SLUGS:
        setattr(app.settings, get_provider(slug).key_field, "sk-leak-me-1234")
    d = client.get("/api/settings").json()
    assert "sk-leak-me" not in repr(d)
    for k, v in d.items():
        if isinstance(v, str) and v and any(
                h in k.lower() for h in ("key", "token", "secret", "password")):
            assert v.startswith("***"), f"{k} leaked: {v!r}"


def test_models_endpoint_does_not_echo_keys(client, app):
    for slug in CLOUD_SLUGS:
        setattr(app.settings, get_provider(slug).key_field, "sk-leak-me-1234")
    assert "sk-leak-me" not in repr(client.get("/api/models").json())


# --------------------------------------------------------------------------- #
# API surface
# --------------------------------------------------------------------------- #


def test_models_endpoint_lists_every_provider(client):
    d = client.get("/api/models").json()
    slugs = {p["slug"] for p in d}
    for s in CLOUD_SLUGS + ["ollama", "llamacpp"]:
        assert s in slugs, f"{s} missing from /api/models"


def test_models_endpoint_shows_catalog_models_when_unconfigured(client):
    d = {p["slug"]: p for p in client.get("/api/models").json()}
    # An unkeyed provider still advertises what a key would unlock.
    assert d["openai"]["models"], "catalog models should be shown without a key"
    assert d["openai"]["configured"] is False


def test_providers_endpoint_returns_the_static_catalog(client):
    d = client.get("/api/providers").json()
    assert len(d) >= 13
    o = next(p for p in d if p["slug"] == "openai")
    assert o["kind"] == "openai" and o["models"]


def test_adding_a_key_registers_the_provider_without_restart(home, monkeypatch):
    """Pasting a key in the UI must take effect without a server restart."""
    for var in list(os.environ):
        if var.endswith("_API_KEY"):
            monkeypatch.delenv(var, raising=False)
    from fastapi.testclient import TestClient
    from spidy.api.server import create_app
    from spidy.app import get_app, reset_app
    # The API layer talks to the process singleton, so drive the real one.
    app = get_app(fresh_settings())
    c = TestClient(create_app())
    assert "openai" not in app.router.providers

    r = c.patch("/api/settings", json={"openai_api_key": "sk-runtime-123456"})
    assert r.json()["applied"] == ["openai_api_key"]
    assert "openai" in app.router.providers, "router did not pick up the new key"
    d = {p["slug"]: p for p in c.get("/api/models").json()}
    assert d["openai"]["configured"] is True
    assert "sk-runtime" not in repr(c.get("/api/settings").json())
    app.close(); reset_app()


def test_health_reports_cloud_policy(home, client):
    h = client.get("/api/health").json()
    assert "allow_cloud" in h and "offline_only" in h


# --------------------------------------------------------------------------- #
# probe honesty
# --------------------------------------------------------------------------- #


def test_bad_key_is_reported_as_auth_failure_not_reachable(home, monkeypatch):
    """A 401 is not an exception, so a naive probe calls a dead key 'reachable'.

    That is the worst possible failure for this screen: it shows a model list
    the user can pick from, and every pick then fails at call time.
    """
    import asyncio
    from spidy.app import Spidy, reset_app
    monkeypatch.setenv("GROQ_API_KEY", "gsk-definitely-not-valid")
    app = Spidy(fresh_settings())
    # The router caches probe results for 30s on a process-wide bus, so a
    # sibling test can otherwise decide this one's outcome.
    app.router._probe_cache.clear()
    usable, models, err = asyncio.run(app.router.providers["groq"].probe())
    assert usable is False
    assert models == []
    assert "auth" in err.lower() or "401" in err or "unreachable" in err.lower()
    app.close(); reset_app()


def test_unreachable_local_provider_says_why(home):
    import asyncio
    from spidy.app import Spidy, reset_app
    app = Spidy(fresh_settings())
    usable, models, err = asyncio.run(app.router.providers["ollama"].probe())
    assert usable is False and models == []
    assert err, "an unreachable provider must say why"
    app.close(); reset_app()


def test_api_suppresses_catalog_when_the_key_is_rejected(home, monkeypatch):
    """Showing the catalog for a rejected key lists models that can't be called."""
    import asyncio
    from spidy.app import get_app, reset_app
    from spidy.api.routes import list_models
    reset_app()
    app = get_app(fresh_settings())
    app.settings.groq_api_key = "gsk-bogus"
    d = {p["slug"]: p for p in asyncio.run(list_models())}
    assert d["groq"]["configured"] is True
    assert d["groq"]["reachable"] is False
    assert d["groq"]["models"] == [], "must not list models for a rejected key"
    assert d["groq"]["error"]
    reset_app()


def test_api_advertises_catalog_when_there_is_no_key(home):
    import asyncio
    from spidy.app import get_app, reset_app
    from spidy.api.routes import list_models
    reset_app()
    app = get_app(fresh_settings())
    app.settings.openai_api_key = ""
    d = {p["slug"]: p for p in asyncio.run(list_models())}
    assert d["openai"]["models"], "no key should still advertise the catalog"
    assert d["openai"]["models_from_catalog"] is True
    reset_app()
