"""Shared fixtures.

Every test runs against an isolated SPIDY_HOME so the suite never touches a
real database, and against a temp workspace so file tests can't escape.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


@pytest.fixture()
def home(tmp_path, monkeypatch):
    """An isolated SPIDY_HOME with its own database.

    Note: `reset_settings()` must run *after* every monkeypatch that touches an
    env var, because Settings snapshots the environment at construction. Fixtures
    that set env vars should call it themselves after the set.
    """
    h = tmp_path / "spidy_home"
    h.mkdir()
    monkeypatch.setenv("SPIDY_HOME", str(h))
    monkeypatch.setenv("SPIDY_WORKSPACE", str(tmp_path / "ws"))
    (tmp_path / "ws").mkdir()
    from spidy.core.config import get_settings, reset_settings
    reset_settings()
    yield h
    reset_settings()


def fresh_settings():
    """Build a Settings that reflects the *current* environment.

    Use this in tests that set env vars, because the global settings singleton
    is cached and would otherwise keep a pre-monkeypatch snapshot.
    """
    from spidy.core.config import Settings, reset_settings
    reset_settings()
    return Settings()


@pytest.fixture()
def workspace(home, tmp_path):
    ws = tmp_path / "ws"
    ws.mkdir(exist_ok=True)
    return ws


@pytest.fixture()
def sample_project(workspace):
    """A small but realistic project: source, a marker to grep, and a manifest."""
    (workspace / "main.py").write_text(
        "import os\n\n\n"
        "def add(a, b):\n    return a - b\n\n\n"
        "def load():\n    return os.environ.get('X', 'd')\n\n\n"
        "# TODO: add retries\n# FIXME: handle timeouts\n",
        encoding="utf-8",
    )
    (workspace / "data.csv").write_text(
        "name,score\nada,9\ngrace,8\nlinus,7\n", encoding="utf-8")
    (workspace / "README.md").write_text(
        "# Demo\nA sample project for tests.\n", encoding="utf-8")
    return workspace


@pytest.fixture()
def app(home, workspace):
    """A Spidy container wired to the isolated home and workspace."""
    from spidy.app import Spidy, reset_app
    reset_app()
    yield Spidy()
    reset_app()


@pytest.fixture()
def client(app):
    """FastAPI TestClient over the real app."""
    from fastapi.testclient import TestClient
    from spidy.api.server import create_app
    return TestClient(create_app())


@pytest.fixture()
def clean_env(monkeypatch):
    """Neutralise auth/rate-limit env so tests aren't order-dependent."""
    for k in ("SPIDY_MODE", "SPIDY_TOKENS", "SPIDY_SANDBOX"):
        monkeypatch.delenv(k, raising=False)
    yield
