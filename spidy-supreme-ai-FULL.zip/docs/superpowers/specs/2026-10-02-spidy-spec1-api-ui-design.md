# SPIDY Supreme AI — Spec 1: API Server + Premium UI

**Date:** 2026-10-02
**Status:** Approved for implementation
**Product positioning:** Cost-to-capability wedge (local-first, free) + autonomy moat.
Competes with Claude / GPT / Cursor on capability while costing $0 and running offline.

---

## 1. Goals

Ship a production-ready HTTP surface and a premium browser interface over the existing
SPIDY kernel. Nothing in the kernel changes except one seam: the sandbox executor.

**Success criteria**
- `uvicorn spidy.api.server:app` starts and serves the UI with no network access.
- A chat request streams live agent activity to the browser via SSE.
- A tool call is visible in the UI (args, output, duration, ok/failed) within 100ms of start.
- Works with **zero models running** (native brain floor).
- `SPIDY_MODE=server` adds auth + tenancy without a code change to handlers.

**Non-goals for this spec**
- Container sandbox implementation (interface only; `LocalSandbox` ships).
- Specialist agent *execution* (registry ships in spec 2; dispatched in spec 3).
- Docker/compose packaging (spec 5).

---

## 2. Architecture

```
Browser (no build step, vanilla JS)
   │  fetch + SSE
   ▼
spidy/api/server.py      FastAPI factory, lifespan, static mount
spidy/api/tenancy.py     tenant resolution — the ONLY mode branch
spidy/api/routes.py      REST + SSE
spidy/api/schemas.py     pydantic DTOs (decoupled from core schemas)
   │
   ▼
spidy/app.py :: Spidy     ← the kernel. API never reaches past this.
   run() registry db router retriever cache events
```

The API is a thin adapter. `Spidy.run()` is unchanged. A CLI, Discord bot, or IDE
plugin would reuse the same routes unchanged.

### 2.1 Tenancy — one branch, one place

`SPIDY_MODE=local` (default) → tenant id `"local"`, no auth, `LocalSandbox` only.
`SPIDY_MODE=server` → bearer token → tenant id, per-tenant rate limit, per-tenant
memory namespace, `ContainerSandbox` required for shell tools.

All mode branching lives in `tenancy.py` (one `TenantContext` resolver + one
`require_auth` dependency). Handlers read `ctx.tenant_id` and never test the mode.
This is deliberate: scattering `if mode ==` through handlers is what makes tenancy
additions expensive later.

Per-tenant isolation of long-lived rows is by a `tenant_id` column, defaulted to
`"local"` and back-filled on existing databases so upgrades are non-destructive.

### 2.2 Sandbox seam

```python
class Sandbox(Protocol):
    async def run(self, cmd: list[str], cwd: Path, limits: Limits) -> ExecResult: ...
```

`LocalSandbox` — `resource` rlimits + jail policy + cwd confinement. Default.
`ContainerSandbox` — Docker exec, no network, read-only root, memory/cpu caps. Spec 4.

`tools/shell.py` changes by exactly one call site: the executor dispatch. A
`SPIDY_SANDBOX` env var selects the implementation. Everything else is untouched.

> **Honest note:** local sandboxing is *advisory*. It stops accidents, not a
> determined attacker. It is sufficient for single-user local operation, which is
> the default mode. Server mode must refuse shell tools unless a container sandbox
> is configured. This is stated in the README rather than glossed over.

### 2.3 Event streaming

The kernel already emits ~15 event types through `EventBus`. SSE is an adapter:
subscribe → `data: {json}\n\n` → heartbeat every 15s → close on client disconnect.
No new event system is introduced. Live tool calls, plan steps, repair loops, and
token spend are all already emitted; the UI gets them free.

Replay: `?replay=<task_id>` replays persisted events from the `events` table before
switching to live, so a page refresh mid-task doesn't lose the trail.

---

## 3. API contract (binding — frontend and backend build in parallel against this)

All responses JSON. Errors: `{"error": {"code": "...", "message": "...", "detail": {...}}}`
with real HTTP status (400 validation, 401 auth, 403 sandbox/policy, 404 missing, 429 rate limit).

### REST

| Method | Path | Body / Query | Returns |
|---|---|---|---|
| GET | `/api/health` | — | `{status, version, mode, providers[], tools, models, db_ok, uptime_s}` |
| GET | `/api/tools` | `?tag=` | `[{name, description, risk_level, idempotent, tags, input_schema}]` |
| POST | `/api/chat` | `{message, session_id?, project?, stream?}` | `{task_id, session_id, status}` — starts a task |
| GET | `/api/tasks/{id}` | — | `{task_id, status, plan[], observations[], answer, files_changed, verification, token_usage, errors[], duration_ms}` |
| POST | `/api/tasks/{id}/cancel` | — | `{ok, task_id}` |
| POST | `/api/tasks/{id}/approve` | `{step_id, approved}` | `{ok}` — answers the approval gate |
| GET | `/api/tasks` | `?limit=50` | `[{task_id, request, status, created_at, duration_ms}]` |
| GET | `/api/sessions` | — | `[{session_id, title, created_at, message_count}]` |
| GET | `/api/sessions/{id}/messages` | — | `[{role, content, ts, tool_calls[]}]` |
| DELETE | `/api/sessions/{id}` | — | `{ok}` |
| GET | `/api/files` | `?path=&glob=&max=` | `[{path, size, mtime, kind}]` |
| GET | `/api/files/content` | `?path=` | `{path, content, language, truncated, lines}` |
| PUT | `/api/files/content` | `{path, content}` | `{ok, path, bytes}` |
| GET | `/api/projects` | — | `[{name, root, chunks, docs, last_indexed, cag_hits, cag_misses}]` |
| POST | `/api/projects/index` | `{root, force?}` | `{ok, docs, chunks, duration_ms}` |
| GET | `/api/memory` | `?q=&limit=` | `[{key, value, score, updated_at}]` |
| POST | `/api/memory` | `{key, value}` | `{ok}` |
| GET | `/api/settings` | — | full `Settings` as JSON (secrets redacted) |
| PATCH | `/api/settings` | partial settings | `{ok, applied[], rejected[]}` |
| GET | `/api/audit` | `?limit=100` | `[{ts, actor, action, target, decision, reason}]` |
| GET | `/api/events/stream` | `?task_id=&replay=` | **SSE** — see below |
| GET | `/api/models` | — | `[{name, provider, size_hint, available, role_fit[]}]` |

### SSE frame

```
event: <task.started|plan.ready|tool.started|tool.finished|step.failed|
       repair.started|token.spend|task.completed|task.failed|approval.required>
id: <seq>
data: {"task_id": "...", "ts": 1234.5, ...payload}
```

Heartbeat: `: keepalive` every 15s. Client reconnects with `Last-Event-ID`.

### Compatibility rules
- The UI treats unknown event types as no-ops and unknown fields as ignored.
- The UI degrades if a route 404s (feature-detect, don't crash).
- `settings` and `models` are read-only in the UI in v1 (PATCH is wired but the UI
  ships read-only to avoid a settings-editing rabbit hole in this spec).

---

## 4. Frontend

No build step, no CDN, no npm. One HTML file, one CSS file, one JS file. Hash routing.

| Screen | Contents |
|---|---|
| **Chat** | streaming answer, inline collapsible tool cards, approval buttons, input w/ ⌘-enter |
| **Timeline** | live 7-phase DAG, active step highlighted, repair loops visible, 150ms phase transitions |
| **Tools** | call log: args, output, duration, ok/failed, token cost; filter by tool/tag |
| **Files** | tree, read, edit, save, diff, history |
| **Projects** | indexed workspaces, RAG chunk counts, CAG hit rate, reindex button |
| **Settings** | model picker, provider health, mode, permissions — read-only in v1 |

**Design tokens**

```
--bg:#0a0a0b  --surface:#131316  --surface-2:#1b1b20  --border:#26262d
--text:#e8e8ed  --muted:#8a8a96
--accent:#7C5CFF  --accent-2:#22D3EE
--ok:#3ddc97  --warn:#ffb454  --err:#ff5c5c
radius 10px · 8px grid · ui-monospace for all code + tool output
```

Dark only. Density over whitespace — this is a tool, not a landing page.

**State model** — plain object store + targeted DOM patch. No framework. A chat
transcript is an append-only list; the timeline is a bounded array; the file tree is
a lazy list. Each is under 100 lines of update logic.

**Progressive enhancement** — every screen renders from REST alone; SSE only adds
live updates. If EventSource fails, the UI retries with backoff and the screen
still works.

---

## 5. Data flow (one request)

```
POST /api/chat
  → tenancy.resolve()        tenant_id
  → Spidy.run()              7-phase loop
      EventBus emits ────────┐
      DB persists each event │
                            ▼
                    SSE /api/events/stream ──► browser
GET /api/tasks/{id}  ◄── final state, for refresh/replay
```

---

## 6. Error handling

| Case | Behavior |
|---|---|
| Kernel raises | caught in runtime, `task.failed` emitted with traceback, task marked FAILED — API never 500s on a task failure |
| Tool fails | ToolResult.ok=False, observation recorded, repair loop runs — not an HTTP error |
| Auth missing/failed | 401 with `WWW-Authenticate` |
| Policy denies | 403 `policy_denied` with the reason string |
| Shell in server mode w/o container sandbox | 403 `sandbox_unavailable` — fail closed |
| Rate limit | 429 + `Retry-After` |
| Stream disconnect mid-task | task continues in kernel; UI catches up via `GET /api/tasks/{id}` |
| No model reachable | 200 — native brain answers, UI shows an "offline mode" badge |

That last row matters: **degraded is not broken.** The UI must communicate degraded
state honestly rather than looking broken.

---

## 7. Testing

- **API** — TestClient over every route: happy path, auth modes, 4xx paths, SSE
  connect/disconnect/replay.
- **Tenancy** — local vs server resolution, cross-tenant isolation assertions.
- **Regression** — existing 50-tool registry still constructs; `Spidy` still starts.
- **UI** — served and byte-checked; JS syntax-checked via `node --check`.
- **E2E** — one real task: POST /api/chat → assert `task.completed` frame arrives on
  SSE with a working native brain and no models.

---

## 8. Acceptance checklist

- [ ] `uvicorn spidy.api.server:app` starts, UI loads, fully offline
- [ ] POST /api/chat returns a task_id; SSE streams phases in order
- [ ] Tool cards render with args/output/duration
- [ ] Approval gate renders buttons and resumes the task on click
- [ ] All 6 screens render; nav is hash-routed and survives refresh
- [ ] `SPIDY_MODE=server` requires a token; without one, 401
- [ ] Shell tools fail closed in server mode with no container sandbox
- [ ] Zero models → task completes via native brain, offline badge shown
- [ ] `pytest` green; `node --check` clean; kernel regression intact

---

## 9. Known limits (stated, not hidden)

- Local sandbox is advisory — fine for single-user, not a security boundary.
- SSE is single-process. Multi-worker deployment needs a Redis pub/sub fanout (spec 5).
- No streaming token deltas from the native brain; SSE streams *events*, not tokens.
  With a real model, token deltas stream from the provider.
- Settings UI is read-only in v1; the PATCH route exists and is tested.
