"""Record SPIDY working: video + screenshots + transcripts.

Drives the real UI in a real browser against a real server, asking a spread of
questions and capturing what comes back. Video is recorded by the browser
itself (Playwright), so it is the actual UI in motion, not a reconstruction.

    python tools/demo.py http://127.0.0.1:8895 /workspace/demo_out
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8895"
OUT = Path(sys.argv[2] if len(sys.argv) > 2 else "/workspace/demo_out")
OUT.mkdir(parents=True, exist_ok=True)
VIDEO_DIR = OUT / "_video"

# Chosen to cover the range: file reads, content search, structure discovery,
# execution, and a question that needs generation (so the honest degradation
# is captured too, not just the successes).
QUERIES = [
    ("read-calculator",    "read src/calculator.py and tell me what functions it has"),
    ("search-todos",       "search for TODO comments across the project"),
    ("search-fixme",       "find all FIXME markers"),
    ("workspace",          "give me a map of the workspace"),
    ("list-files",         "list the files in this workspace"),
    ("file-stats",         "show me statistics for src/auth.py"),
    ("run-tests",          "run the tests and tell me what happens"),
    ("read-readme",        "read README.md and summarize the project"),
    ("git-status",         "show me the git status"),
    ("spec-list",          "which specialists would you assign to audit this project for security bugs"),
]


def shot(page, name: str) -> None:
    p = OUT / f"{name}.png"
    page.screenshot(path=str(p))
    print(f"    shot {p.name}")


def main() -> None:
    results: list[dict] = []
    console_errors: list[str] = []

    with sync_playwright() as pw:
        browser = pw.chromium.launch(args=["--force-device-scale-factor=2"])
        ctx = browser.new_context(
            viewport={"width": 1440, "height": 900},
            device_scale_factor=2,
            record_video_dir=str(VIDEO_DIR),
            record_video_size={"width": 1440, "height": 900},
        )
        page = ctx.new_page()
        page.on("pageerror", lambda e: console_errors.append(str(e)))
        page.on("console",
                lambda m: console_errors.append(m.text) if m.type == "error" else None)

        page.goto(BASE, wait_until="networkidle")
        page.wait_for_function("() => !!window.SPYDY", timeout=15000)
        time.sleep(1.5)
        print("  landed on the app")
        shot(page, "01-landing")

        # Sweep the screens so the video shows the whole product, not just chat.
        for i, name in enumerate(["models", "tools", "files", "projects"], start=2):
            page.goto(f"{BASE}/#/{name}", wait_until="domcontentloaded")
            page.wait_for_function("() => !!window.SPYDY", timeout=15000)
            time.sleep(1.4)
            shot(page, f"{i:02d}-{name}")
            page.goto(f"{BASE}/#/chat", wait_until="domcontentloaded")
            time.sleep(0.5)

        print("  running queries...")
        for n, (slug, q) in enumerate(QUERIES, start=6):
            page.fill("#composer-input", q)
            page.keyboard.press("Control+Enter")

            # Wait for the answer to actually arrive. Polling the button's
            # disabled state races the render — the button can still look
            # enabled a beat after send — so wait on the thing we care about.
            try:
                page.wait_for_function(
                    """() => {
                        const m = window.SPYDY && window.SPYDY.messages;
                        if (!m || !m.length) return false;
                        const last = m[m.length - 1];
                        return last && last.kind !== 'user'
                               && (last.body || '').trim().length > 0;
                    }""",
                    timeout=90_000)
            except Exception as exc:
                print(f"    ! {slug}: no answer within 90s ({type(exc).__name__})")
            time.sleep(1.0)

            answer = ""
            obs = 0
            try:
                blocks = page.query_selector_all(".msg.bot .msg-body")
                if blocks:
                    answer = blocks[-1].text_content()
                obs = len(page.query_selector_all(".tool-card"))
            except Exception:
                pass

            results.append({"slug": slug, "query": q, "answer": answer.strip(),
                            "tool_cards": obs})
            shot(page, f"{n:02d}-{slug}")
            print(f"    {slug:16s} {obs} tool card(s), {len(answer.strip())} chars")

        # Finish on the timeline so the video closes on the agent loop.
        page.goto(f"{BASE}/#/timeline", wait_until="domcontentloaded")
        time.sleep(1.6)
        shot(page, "90-timeline-final")

        ctx.close()          # flushes the video
        browser.close()

    # Playwright names videos by random id; normalise.
    vids = sorted(VIDEO_DIR.glob("*.webm"))
    final_video = OUT / "spidy-demo.webm"
    if vids:
        vids[0].rename(final_video)
        for v in vids[1:]:
            v.unlink()
    VIDEO_DIR.rmdir() if VIDEO_DIR.exists() and not any(VIDEO_DIR.iterdir()) else None

    (OUT / "transcript.json").write_text(
        json.dumps({"results": results, "console_errors": console_errors}, indent=2),
        encoding="utf-8")

    ok = sum(1 for r in results if r["answer"].strip())
    print(f"\n  {ok}/{len(results)} queries answered")
    print(f"  console errors: {len(console_errors)}")
    for e in dict.fromkeys(console_errors):
        print("   -", e)


if __name__ == "__main__":
    main()