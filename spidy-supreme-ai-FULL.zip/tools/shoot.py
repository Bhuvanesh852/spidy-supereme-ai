"""Screenshot the UI for visual verification.

    python tools/shoot.py http://127.0.0.1:8891 out/

Drives the real app: waits for the event stream, sends a task, and captures
each screen. Also fails loudly on console errors, which is the cheapest way
to catch a broken view that still "looks fine" as static HTML.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8891"
OUT = Path(sys.argv[2] if len(sys.argv) > 2 else "/workspace/shots")
OUT.mkdir(parents=True, exist_ok=True)

SCREENS = ["chat", "timeline", "tools", "files", "models", "projects", "settings"]


def main() -> None:
    errors: list[str] = []
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        page = b.new_page(viewport={"width": 1440, "height": 900},
                          device_scale_factor=2)
        page.on("console", lambda m: errors.append(f"console.{m.type}: {m.text}")
                if m.type == "error" else None)
        page.on("pageerror", lambda e: errors.append(f"pageerror: {e}"))

        page.goto(BASE, wait_until="networkidle")
        time.sleep(1.5)

        # Send a real task so chat/timeline/tools have content to render.
        page.fill("#composer-input", "read main.py and search for TODO comments")
        page.keyboard.press("Control+Enter")
        time.sleep(9)

        for name in SCREENS:
            page.goto(f"{BASE}/#/{name}", wait_until="domcontentloaded")
            time.sleep(1.2)
            out = OUT / f"{name}.png"
            page.screenshot(path=str(out), full_page=False)
            print(f"  {name:10s} -> {out}")

        b.close()

    if errors:
        print("\nBROWSER ERRORS:")
        for e in dict.fromkeys(errors):
            print("  -", e)
        raise SystemExit(1)
    print("\nNo console errors.")


if __name__ == "__main__":
    main()
