"""Billing calculator."""
from decimal import Decimal

TAX_RATE = Decimal("0.0825")


def calculate_subtotal(items):
    """Sum the prices of a list of {name, price} dicts."""
    return sum(Decimal(str(i["price"])) for i in items)


def calculate_tax(amount):
    # TODO: handle tax-exempt customers
    return (Decimal(str(amount)) * TAX_RATE).quantize(Decimal("0.01"))


def calculate_total(items):
    subtotal = calculate_subtotal(items)
    return subtotal + calculate_tax(subtotal)
