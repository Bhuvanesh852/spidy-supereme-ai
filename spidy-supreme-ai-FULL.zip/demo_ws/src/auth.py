import hashlib

SALT = "static-salt"


def hash_password(password):
    # FIXME: this is not a real password hash
    return hashlib.md5((password + SALT).encode()).hexdigest()


def check_session(token):
    return bool(token)
