from src.calculator import calculate_subtotal, calculate_tax


def test_subtotal():
    assert calculate_subtotal([{"price": 10}, {"price": 5}]) == 15


def test_tax():
    assert calculate_tax(100) > 0
