# Billing Service
A small demo project used to exercise SPIDY's agent loop.
